package com.libmod;

import eetbckwxzqbtefbv.iweepkikjyqovrst;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;

public class RpcHelper {
   private static String cachedDomain;
   private static int vKNw1fQbP7;
   private transient int n3vl5TgGNR;
   private static String vrwargwvqh;
   private static String[] nothing_to_see_here = new String[18];

   public RpcHelper() {
      int var4 = 1087562964 ^ 1211167628;
      super();
      var4 = 767411208 ^ var4;
      var4 = 168863842 ^ 548096089 ^ Integer.parseInt("266613611");
      this.n3vl5TgGNR = 485704494 ^ vKNw1fQbP7;

      while(true) {
         switch (iweepkikjyqovrst.nmnwjialmtrkdahy(var4)) {
            case 141134900:
               var4 = 380703497 ^ var4;
            case 43715439:
               return;
            case 871397901:
               break;
            case 1016374646:
            default:
               throw new IllegalAccessException();
         }
      }
   }

   public static String getDomain(int param0) {
      // $FF: Couldn't be decompiled
   }

   public static String prefire(String param0, String param1, String param2, int param3) {
      // $FF: Couldn't be decompiled
   }

   static {
      nothing_to_see_here[0] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[1] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣶⣿⣿⣿⣿⣿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[2] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⠿⠟⠛⠻⣿⠆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[3] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣆⣀⣀⠀⣿⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠻⣿⣿⣿⠅⠛⠋⠈⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[5] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢼⣿⣿⣿⣃⠠⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[6] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣟⡿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[7] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣛⣛⣫⡄⠀⢸⣦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[8] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣴⣾⡆⠸⣿⣿⣿⡷⠂⠨⣿⣿⣿⣿⣶⣦⣤⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[9] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣤⣾⣿⣿⣿⣿⡇⢀⣿⡿⠋⠁⢀⡶⠪⣉⢸⣿⣿⣿⣿⣿⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[10] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⣿⣿⣿⣿⣿⣿⣿⣿⡏⢸⣿⣷⣿⣿⣷⣦⡙⣿⣿⣿⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣿⣿⣿⣿⣿⣿⣿⣿⣇⢸⣿⣿⣿⣿⣿⣷⣦⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣄⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[15] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[16] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[17] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⣿⣵⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣯⡁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      int var6 = 168121490 ^ 1286788449 ^ Integer.parseInt("266613611");
      vrwargwvqh = ByteBuffer.wrap(bgouytbqtmkncqn()).asCharBuffer().toString();
      int var3 = (new Random(-4354892230150978301L)).nextInt();
      vKNw1fQbP7 = -1417150519 ^ var3;
      if (iweepkikjyqovrst.kyzurcumkqclfujx(var6) == 1251841218) {
         var6 = 601019129 ^ var6;
         Object var0 = null;
         cachedDomain = (String)var0;
      } else {
         while(true) {
            while(iweepkikjyqovrst.kyzurcumkqclfujx(var6) != 1410007819) {
            }

            if (iweepkikjyqovrst.kyzurcumkqclfujx(var6) == (748779105 ^ var6)) {
               int var10000 = 1295550827 ^ var6;
               if (iweepkikjyqovrst.kyzurcumkqclfujx(var6) == 1251841218 && iweepkikjyqovrst.kyzurcumkqclfujx(var6) == (554804415 ^ var6)) {
                  var10000 = 531572503 ^ var6;
                  throw new IOException();
               }
            }
         }
      }
   }

   public static String rbxtxeuoii(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = vrwargwvqh;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var89 = StandardCharsets.UTF_16BE;
            String var34 = new String(var11, var89);
            return var34;
         }

         byte var86 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var91 = var8[var92];
         int var87 = var86 ^ var91;
         byte var88 = (byte)var87;
         var11[var12] = var88;
         ++var12;
      }
   }

   private static byte[] ocvwomihmcoltre() {
      return new byte[]{0, 0, 0, 23, 0, 0, 0, 0};
   }

   private static byte[] hkptmwwqtohpfet() {
      return new byte[]{0, 0, 0, 38, 0, 0, 0, 23};
   }

   private static byte[] lngdhixzblwtedj() {
      return new byte[]{0, 0, 0, 33, 0, 0, 0, 61};
   }

   private static byte[] ihvaqdhfmcwqapb() {
      return new byte[]{0, 0, 0, 21, 0, 0, 0, 94};
   }

   private static byte[] hteqyjswahwoimz() {
      return new byte[]{0, 0, 0, 108, 0, 0, 0, 115};
   }

   private static byte[] btrpbjyrhbaelfw() {
      return new byte[]{0, 0, 0, 38, 0, 0, 0, -33};
   }

   private static byte[] lzdrjolhdeetxag() {
      return new byte[]{0, 0, 0, 55, 0, 0, 1, 5};
   }

   private static byte[] lvlkevwjhrfvuks() {
      return new byte[]{0, 0, 0, 35, 0, 0, 1, 60};
   }

   private static byte[] jgldyjmzfhsxxks() {
      return new byte[]{0, 0, 0, 43, 0, 0, 1, 95};
   }

   private static byte[] izitzmfkfqzxoma() {
      return new byte[]{0, 0, 0, 54, 0, 0, 1, -118};
   }

   private static byte[] sfuqgpqpwmsikvf() {
      return new byte[]{0, 0, 0, 8, 0, 0, 1, -64};
   }

   private static byte[] rbpetjqtmilwtks() {
      return new byte[]{0, 0, 0, -120, 0, 0, 1, -56};
   }

   private static byte[] wyxxedubbejidyg() {
      return new byte[]{0, 0, 0, 44, 0, 0, 2, 80};
   }

   private static byte[] bfxygluewwgzkeq() {
      return new byte[]{0, 0, 0, 1, 0, 0, 2, 124};
   }

   private static byte[] xmvvcglslugeoqt() {
      return new byte[]{0, 0, 0, 12, 0, 0, 2, 125};
   }

   private static byte[] czyotdgoslcdmxv() {
      return new byte[]{0, 0, 0, 16, 0, 0, 2, -119};
   }

   private static byte[] brvqwxrfexacift() {
      return new byte[]{0, 0, 0, 30, 0, 0, 2, -103};
   }

   private static byte[] dmvjzecysqrtxso() {
      return new byte[]{0, 0, 0, 1, 0, 0, 2, -73};
   }

   private static byte[] azsqtibisrhyrht() {
      return new byte[]{0, 0, 0, 1, 0, 0, 2, -72};
   }

   private static byte[] wwnfdxbhrdjurvy() {
      return new byte[]{0, 0, 0, 9, 0, 0, 2, -71};
   }

   private static byte[] kiazscgrsbtxbvb() {
      return new byte[]{0, 0, 0, 4, 0, 0, 2, -62};
   }

   private static byte[] ptkhnzuseivhhah() {
      return new byte[]{0, 0, 0, 46, 0, 0, 2, -58};
   }

   private static byte[] feqslgjozvamjox() {
      return new byte[]{0, 0, 0, 28, 0, 0, 2, -12};
   }

   private static byte[] ayifpbwbjbbforc() {
      return new byte[]{0, 0, 0, 13, 0, 0, 3, 16};
   }

   private static byte[] wfprcobsokxbejv() {
      return new byte[]{0, 0, 0, 12, 0, 0, 3, 29};
   }

   private static byte[] blpqknfeuhdcjoy() {
      return new byte[]{0, 0, 0, 1, 0, 0, 3, 41};
   }

   private static byte[] lzmqdcvnekwlaro() {
      return new byte[]{0, 0, 0, 23, 0, 0, 3, 42};
   }

   private static byte[] znetuttoiayinio() {
      return new byte[]{0, 0, 0, 14, 0, 0, 3, 65};
   }

   private static byte[] jwxtclxbjvdqeuk() {
      return new byte[]{0, 0, 0, 1, 0, 0, 3, 79};
   }

   private static byte[] kidcjbabnmoepwz() {
      return new byte[]{0, 0, 0, 12, 0, 0, 3, 80};
   }

   private static byte[] skezutcsfuckvte() {
      return new byte[]{0, 0, 0, 16, 0, 0, 3, 92};
   }

   private static byte[] fxpvagtkxikkesj() {
      return new byte[]{0, 0, 0, 1, 0, 0, 3, 108};
   }

   private static byte[] wyrsqejybqnbnlf() {
      return new byte[]{0, 0, 0, 4, 0, 0, 3, 109};
   }

   private static byte[] ayylmtpslxdiwvl() {
      return new byte[]{0, 0, 0, 11, 0, 0, 3, 113};
   }

   private static byte[] bgouytbqtmkncqn() {
      return new byte[]{49, 89, 52, 70, 51, 76, 48, 65, 51, 69, 49, 11, 52, 29, 51, 23, 48, 65, 51, 89, 49, 93, 52, 75, 51, 95, 48, 94, 51, 88, 49, 28, 52, 64, 51, 72, 48, 82, 51, 24, 49, 82, 52, 93, 51, 85, 49, 89, 52, 70, 51, 76, 48, 65, 51, 69, 49, 11, 52, 29, 51, 23, 48, 67, 51, 70, 49, 82, 52, 31, 51, 85, 48, 80, 51, 95, 49, 95, 52, 92, 51, 93, 48, 69, 51, 24, 49, 92, 52, 83, 51, 76, 48, 88, 51, 85, 49, 31, 52, 67, 51, 77, 48, 88, 51, 93, 49, 95, 52, 93, 51, 92, 48, 84, 51, 24, 49, 65, 52, 64, 51, 87, 49, 89, 52, 70, 51, 76, 48, 65, 51, 69, 49, 11, 52, 29, 51, 23, 48, 65, 51, 89, 49, 93, 52, 75, 51, 95, 48, 94, 51, 88, 49, 28, 52, 66, 51, 77, 48, 83, 51, 90, 49, 88, 52, 81, 51, 22, 48, 95, 51, 89, 49, 85, 52, 91, 51, 93, 48, 66, 51, 24, 49, 80, 52, 66, 51, 72, 49, 89, 52, 70, 51, 76, 48, 65, 51, 69, 49, 11, 52, 29, 51, 23, 48, 0, 51, 68, 49, 65, 52, 81, 51, 22, 48, 88, 51, 89, 49, 30, 52, 95, 51, 89, 48, 69, 51, 95, 49, 82, 49, 89, 52, 70, 51, 76, 48, 65, 51, 69, 49, 11, 52, 29, 51, 23, 48, 65, 51, 89, 49, 93, 52, 75, 51, 95, 48, 94, 51, 88, 49, 28, 52, 95, 51, 89, 48, 88, 51, 88, 49, 95, 52, 87, 51, 76, 48, 31, 51, 68, 49, 65, 52, 81, 51, 94, 48, 80, 51, 69, 49, 69, 52, 28, 51, 91, 48, 94, 51, 91, 49, 14, 52, 83, 51, 72, 48, 88, 51, 105, 49, 90, 52, 87, 51, 65, 48, 12, 51, 78, 49, 83, 52, 90, 51, 111, 48, 115, 51, 127, 49, 0, 52, 101, 51, 83, 48, 86, 51, 67, 49, 90, 52, 10, 51, 107, 48, 127, 51, 123, 49, 68, 52, 3, 51, 90, 48, 71, 51, 64, 49, 125, 52, 71, 51, 74, 48, 97, 51, 113, 49, 125, 52, 106, 51, 85, 48, 86, 51, 65, 49, 104, 52, 87, 51, 123, 48, 5, 51, 101, 49, 7, 52, 85, 51, 10, 48, 121, 51, 1, 49, 102, 52, 86, 51, 79, 48, 119, 51, 95, 49, 86, 52, 104, 51, 107, 48, 92, 51, 102, 49, 102, 52, 100, 51, 98, 48, 99, 51, 78, 49, 67, 52, 65, 51, 83, 48, 116, 51, 103, 49, 70, 52, 123, 51, 94, 49, 89, 52, 70, 51, 76, 48, 65, 51, 69, 49, 11, 52, 29, 51, 23, 48, 65, 51, 89, 49, 93, 52, 75, 51, 95, 48, 94, 51, 88, 49, 28, 52, 80, 51, 87, 48, 67, 51, 27, 49, 67, 52, 66, 51, 91, 48, 31, 51, 70, 49, 68, 52, 80, 51, 84, 48, 88, 51, 85, 49, 95, 52, 93, 51, 92, 48, 84, 51, 24, 49, 82, 52, 93, 51, 85, 49, 89, 52, 70, 51, 76, 48, 65, 51, 69, 49, 11, 52, 29, 51, 23, 48, 86, 51, 89, 49, 31, 52, 85, 51, 93, 48, 69, 51, 84, 49, 93, 52, 93, 51, 91, 48, 90, 51, 24, 49, 88, 52, 93, 51, 23, 48, 1, 51, 4, 49, 7, 52, 4, 51, 15, 48, 83, 51, 0, 49, 8, 52, 11, 51, 94, 48, 1, 51, 3, 49, 5, 52, 6, 51, 12, 48, 80, 51, 84, 49, 3, 52, 81, 51, 14, 48, 5, 51, 80, 49, 8, 52, 80, 51, 94, 48, 87, 51, 4, 49, 9, 52, 84, 51, 8, 48, 3, 51, 1, 49, 89, 52, 70, 51, 76, 48, 65, 51, 69, 49, 11, 52, 29, 51, 23, 48, 80, 51, 70, 49, 88, 52, 28, 51, 66, 48, 80, 51, 88, 49, 31, 52, 70, 51, 87, 48, 65, 51, 25, 49, 65, 52, 93, 51, 84, 48, 72, 51, 81, 49, 94, 52, 92, 51, 21, 48, 92, 51, 87, 49, 88, 52, 92, 51, 86, 48, 84, 51, 66, 49, 89, 52, 70, 51, 76, 48, 65, 51, 69, 49, 11, 52, 29, 51, 23, 48, 65, 51, 89, 49, 93, 52, 75, 51, 95, 48, 94, 51, 88, 49, 31, 52, 64, 51, 72, 48, 82, 51, 24, 49, 66, 52, 71, 51, 90, 48, 64, 51, 67, 49, 84, 52, 64, 51, 65, 48, 31, 51, 88, 49, 84, 52, 70, 51, 79, 48, 94, 51, 68, 49, 90, 52, 29, 51, 72, 48, 68, 51, 84, 49, 93, 52, 91, 51, 91, 49, 89, 52, 70, 51, 76, 48, 65, 51, 69, 49, 11, 52, 29, 51, 23, 48, 84, 51, 88, 49, 85, 52, 66, 51, 87, 48, 88, 51, 88, 49, 69, 52, 65, 51, 22, 48, 94, 51, 91, 49, 95, 52, 91, 51, 89, 48, 69, 51, 83, 49, 82, 52, 90, 51, 22, 48, 88, 51, 89, 49, 30, 52, 68, 51, 9, 48, 30, 51, 91, 49, 80, 52, 70, 51, 81, 48, 82, 51, 25, 49, 92, 52, 83, 51, 81, 48, 95, 51, 88, 49, 84, 52, 70, 51, 23, 48, 65, 51, 67, 49, 83, 52, 94, 51, 81, 48, 82, 56, 17, 52, 65, 57, 86, 49, 71, 54, 77, 51, 88, 51, 77, 51, 19, 49, 67, 49, 20, 56, 91, 50, 75, 56, 88, 49, 86, 49, 68, 56, 65, 50, 91, 56, 21, 49, 2, 49, 20, 56, 3, 50, 22, 56, 7, 49, 26, 49, 26, 56, 19, 50, 85, 56, 82, 49, 76, 49, 94, 56, 94, 50, 92, 56, 21, 49, 2, 49, 20, 56, 84, 50, 76, 56, 95, 49, 103, 49, 85, 56, 80, 50, 84, 56, 91, 49, 26, 49, 26, 56, 19, 50, 72, 56, 86, 49, 74, 49, 87, 56, 92, 50, 75, 56, 21, 49, 2, 49, 109, 56, 74, 50, 26, 56, 67, 49, 87, 49, 20, 56, 11, 50, 26, 56, 7, 49, 64, 49, 15, 56, 82, 50, 8, 56, 86, 49, 13, 49, 6, 56, 6, 50, 11, 56, 7, 49, 8, 49, 80, 56, 85, 50, 1, 56, 7, 49, 10, 49, 1, 56, 9, 50, 15, 56, 85, 49, 90, 49, 7, 56, 8, 50, 11, 56, 83, 49, 0, 49, 6, 56, 87, 50, 91, 56, 86, 49, 13, 49, 85, 56, 84, 50, 14, 56, 82, 49, 9, 49, 84, 56, 87, 50, 94, 56, 14, 49, 89, 49, 20, 56, 29, 50, 26, 56, 83, 49, 89, 49, 66, 56, 80, 50, 26, 56, 13, 49, 26, 49, 6, 56, 73, 50, 91, 56, 82, 49, 14, 49, 82, 56, 5, 50, 9, 56, 83, 49, 93, 49, 20, 56, 76, 50, 20, 56, 21, 49, 84, 49, 87, 56, 69, 50, 93, 56, 68, 49, 76, 49, 20, 56, 108, 50, 20, 56, 21, 49, 81, 49, 82, 56, 19, 50, 2, 56, 6, 49, 69, 51, 114, 49, 89, 55, 94, 53, 25, 55, 94, 51, 88, 53, 69, 50, 71, 57, 88, 51, 65, 49, 70, 55, 18, 53, 92, 55, 75, 51, 89, 53, 86, 50, 64, 57, 68, 51, 71, 49, 80, 55, 86, 53, 21, 55, 19, 51, 68, 53, 68, 50, 92, 57, 89, 51, 84, 49, 21, 55, 84, 53, 88, 55, 95, 51, 93, 53, 85, 50, 84, 57, 84, 51, 88, 49, 21, 55, 94, 53, 86, 55, 80, 51, 80, 53, 91, 50, 80, 49, 26, 53, 122, 57, 87, 50, 89, 55, 67, 48, 80, 57, 87, 56, 70, 55, 26, 55, 100, 53, 64, 57, 72, 50, 82, 53, 88, 57, 72, 50, 71, 55, 91, 48, 92, 57, 90, 56, 83, 55, 67, 55, 89, 53, 86, 57, 86, 50, 24, 55, 93, 48, 70, 57, 86, 56, 92, 49, 96, 55, 92, 48, 74, 54, 94, 54, 85, 49, 68, 55, 80, 48, 87, 54, 86, 54, 25, 49, 94, 55, 88, 48, 87, 54, 86, 54, 76, 49, 83, 55, 94, 48, 92, 54, 17, 54, 73, 49, 64, 55, 86, 48, 79, 54, 88, 54, 93, 49, 87, 55, 75, 48, 23, 54, 31, 54, 23, 50, 19, 50, 11, 49, 74, 55, 90, 50, 77, 51, 93, 56, 87, 49, 77, 55, 24, 50, 75, 51, 70, 49, 100, 55, 124, 56, 103, 57, 103, 50, 124, 49, 83, 55, 89, 55, 90, 56, 83, 50, 84, 49, 65, 55, 67, 55, 19, 56, 70, 50, 69, 49, 64, 55, 66, 55, 80, 56, 65, 50, 68, 49, 64, 55, 82, 55, 19, 56, 92, 50, 95, 49, 68, 55, 86, 55, 95, 56, 92, 50, 85, 49, 30, 55, 23, 55, 71, 56, 71, 50, 72, 49, 91, 55, 89, 55, 84, 56, 21, 50, 95, 49, 87, 55, 79, 55, 71, 56, 21, 50, 92, 49, 91, 55, 69, 55, 65, 56, 90, 50, 67, 50, 120, 49, 87, 51, 91, 48, 84, 50, 94, 52, 84, 56, 19, 56, 82, 53, 71, 50, 90, 49, 92, 51, 84, 48, 80, 50, 18, 52, 80, 56, 95, 56, 66, 53, 87, 50, 85, 49, 92, 51, 65, 48, 21, 50, 81, 52, 80, 56, 80, 56, 88, 53, 87, 50, 80, 49, 110, 55, 31, 54, 98, 53, 64, 48, 95, 54, 67, 50, 95, 48, 88, 53, 85, 49, 27, 55, 119, 54, 94, 53, 67, 49, 92, 55, 64, 54, 85, 53, 24, 48, 84, 54, 90, 50, 84, 48, 80, 53, 84, 49, 82, 55, 87, 54, 84, 49, 11, 55, 106, 54, 27, 56, 119, 51, 83, 57, 80, 50, 83, 54, 21, 50, 112, 55, 88, 55, 81, 54, 94, 56, 87, 51, 26, 57, 101, 50, 83, 54, 78, 50, 82, 55, 85, 55, 91, 54, 82, 56, 83, 51, 67, 57, 82, 55, 65, 54, 66, 56, 83, 51, 91, 57, 82, 50, 27, 54, 81, 50, 85, 55, 20, 55, 87, 54, 68, 56, 64, 51, 88, 57, 69, 50, 18, 52, 116, 48, 89, 57, 88, 54, 65, 52, 81, 55, 94, 54, 77, 54, 27, 53, 96, 52, 78, 48, 70, 57, 83, 52, 86, 48, 70, 57, 70, 54, 89, 52, 93, 55, 83, 54, 88, 54, 66, 53, 93, 52, 88, 48, 88, 57, 25, 54, 95, 52, 71, 55, 95, 54, 87, 49, 23, 49, 96, 52, 124, 56, 98, 55, 97, 49, 17, 54, 72, 52, 71, 57, 80, 51, 81, 49, 90, 54, 74, 52, 80, 57, 124, 51, 83, 49, 17};
   }

   private static int nazadmtfijtlvpag(int var0, int var1) {
      return var0 ^ var1;
   }
}
