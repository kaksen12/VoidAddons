package com.libmod;

import eetbckwxzqbtefbv.iweepkikjyqovrst;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Random;

public class LangProvider {
   private static String locale;
   private static int EHFTbarLJr;
   private transient int FGSh8jE2kS;
   private static String[] nothing_to_see_here = new String[15];

   public LangProvider() {
      int var4 = 1059738987 ^ 892301539;
      super();
      var4 = xyolscoqlligqowb(var4, 1243740573);
      var4 = 1869326119 ^ 597262001 ^ Integer.parseInt("215352707");
      this.FGSh8jE2kS = 360525203 ^ EHFTbarLJr;

      while(true) {
         switch (iweepkikjyqovrst.nmnwjialmtrkdahy(var4)) {
            case 205990476:
               var4 = 1346614611 ^ var4;
            case 1854815815:
               return;
            case 1234711478:
            default:
               throw new RuntimeException();
            case 1868358164:
         }
      }
   }

   public static String getLocale(int var0) {
      label70: {
         int var4 = 997091537 ^ 742506202 ^ 412869411;
         var4 = 973994163 ^ var4;
         String var1 = locale;
         if (var1 == null) {
            if (iweepkikjyqovrst.kyzurcumkqclfujx(var4) == -1378980647) {
               var4 ^= 1076731254;
               load(72145883);
               if (iweepkikjyqovrst.kyzurcumkqclfujx(var4) == -1398634645) {
                  var4 = 1899331275 ^ var4;
                  break label70;
               }
            }
         } else {
            var4 ^= 330090561;
            if (iweepkikjyqovrst.kyzurcumkqclfujx(var4) != 816328401) {
               if (iweepkikjyqovrst.kyzurcumkqclfujx(var4) == 816328401) {
                  label47:
                  while(true) {
                     switch (iweepkikjyqovrst.nmnwjialmtrkdahy(var4)) {
                        case 164142403:
                           var4 ^= 627454939;
                           break label47;
                        case 614852553:
                           break;
                        case 1597702608:
                        case 2085610319:
                        default:
                           break label47;
                     }
                  }
               }
            } else {
               label64:
               while(true) {
                  switch (iweepkikjyqovrst.nmnwjialmtrkdahy(var4)) {
                     case 164142403:
                        var4 = 582233084 ^ var4;
                        break label70;
                     case 255173796:
                        break;
                     case 913188438:
                     default:
                        break label64;
                     case 1230308892:
                        break label70;
                  }
               }
            }
         }

         while(true) {
            while(iweepkikjyqovrst.kyzurcumkqclfujx(var4) != -1378980647) {
            }

            if (iweepkikjyqovrst.kyzurcumkqclfujx(var4) == (1665993232 ^ var4)) {
               int var10000 = 1861396034 ^ var4;
               if (iweepkikjyqovrst.kyzurcumkqclfujx(var4) == 816328401 && iweepkikjyqovrst.kyzurcumkqclfujx(var4) == (1690910734 ^ var4)) {
                  var10000 = 736090821 ^ var4;
                  if (iweepkikjyqovrst.kyzurcumkqclfujx(var4) == 463056904 && iweepkikjyqovrst.kyzurcumkqclfujx(var4) == (166052079 ^ var4)) {
                     var10000 = 1476655878 ^ var4;
                     if (iweepkikjyqovrst.kyzurcumkqclfujx(var4) == -1398634645 && iweepkikjyqovrst.kyzurcumkqclfujx(var4) == (131226535 ^ var4)) {
                        var10000 = 1367780880 ^ var4;
                        if (iweepkikjyqovrst.kyzurcumkqclfujx(var4) == 621375792 && iweepkikjyqovrst.kyzurcumkqclfujx(var4) == (380179032 ^ var4)) {
                           var10000 = 523739360 ^ var4;
                           throw new RuntimeException();
                        }
                     }
                  }
               }
            }
         }
      }

      String var2 = locale;
      return var2;
   }

   private static void load(int param0) {
      // $FF: Couldn't be decompiled
   }

   static {
      nothing_to_see_here[0] = "⢀⡴⠑⡄⠀⠀⠀⠀⠀⠀⠀⣀⣀⣤⣤⣤⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[1] = "⠸⡇⠀⠿⡀⠀⠀⠀⣀⡴⢿⣿⣿⣿⣿⣿⣿⣿⣷⣦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[2] = "⠀⠀⠀⠀⠑⢄⣠⠾⠁⣀⣄⡈⠙⣿⣿⣿⣿⣿⣿⣿⣿⣆⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[3] = "⠀⠀⠀⠀⢀⡀⠁⠀⠀⠈⠙⠛⠂⠈⣿⣿⣿⣿⣿⠿⡿⢿⣆⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[4] = "⠀⠀⠀⢀⡾⣁⣀⠀⠴⠂⠙⣗⡀⠀⢻⣿⣿⠭⢤⣴⣦⣤⣹⠀⠀⠀⢀⢴⣶⣆";
      nothing_to_see_here[5] = "⠀⠀⢀⣾⣿⣿⣿⣷⣮⣽⣾⣿⣥⣴⣿⣿⡿⢂⠔⢚⡿⢿⣿⣦⣴⣾⠁⠸⣼⡿";
      nothing_to_see_here[6] = "⠀⢀⡞⠁⠙⠻⠿⠟⠉⠀⠛⢹⣿⣿⣿⣿⣿⣌⢤⣼⣿⣾⣿⡟⠉⠀⠀⠀⠀⠀";
      nothing_to_see_here[7] = "⠀⣾⣷⣶⠇⠀⠀⣤⣄⣀⡀⠈⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[8] = "⠀⠉⠈⠉⠀⠀⢦⡈⢻⣿⣿⣿⣶⣶⣶⣶⣤⣽⡹⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[9] = "⠀⠀⠀⠀⠀⠀⠀⠉⠲⣽⡻⢿⣿⣿⣿⣿⣿⣿⣷⣜⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[10] = "⠀⠀⠀⠀⠀⠀⠀⠀⢸⣿⣿⣷⣶⣮⣭⣽⣿⣿⣿⣿⣿⣿⣿⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[11] = "⠀⠀⠀⠀⠀⠀⣀⣀⣈⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[12] = "⠀⠀⠀⠀⠀⠀⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[13] = "⠀⠀⠀⠀⠀⠀⠀⠹⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠟⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀";
      nothing_to_see_here[14] = "⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠛⠻⠿⠿⠿⠿⠛⠉              ";
      int var6 = 1391852491 ^ 1687556753 ^ Integer.parseInt("215352707");
      int var3 = (new Random(3783680209632064145L)).nextInt();
      EHFTbarLJr = 22727207 ^ var3;
      if (iweepkikjyqovrst.kyzurcumkqclfujx(var6) == -709925175) {
         var6 = 1816164740 ^ var6;
         Object var0 = null;
         locale = (String)var0;
      } else {
         while(true) {
            while(iweepkikjyqovrst.kyzurcumkqclfujx(var6) != -1213420822) {
            }

            if (iweepkikjyqovrst.kyzurcumkqclfujx(var6) == (82004509 ^ var6)) {
               int var10000 = 57714196 ^ var6;
               if (iweepkikjyqovrst.kyzurcumkqclfujx(var6) == -709925175 && iweepkikjyqovrst.kyzurcumkqclfujx(var6) == (1240335162 ^ var6)) {
                  var10000 = 873101853 ^ var6;
                  throw new RuntimeException();
               }
            }
         }
      }
   }

   public static String msotaknqmr(byte[] var0, byte[] var1, int var2) {
      String var11 = Integer.toString(var2);
      byte[] var12 = var11.getBytes();
      byte[] var9 = var12;
      byte var13 = 0;
      int var10 = var13;

      while(true) {
         int var18 = var0.length;
         if (var10 >= var18) {
            Charset var6 = StandardCharsets.UTF_16;
            String var15 = new String(var0, var6);
            return var15;
         }

         byte var21 = var0[var10];
         int var34 = var9.length;
         int var31 = var10 % var34;
         byte var28 = var9[var31];
         int var22 = var21 ^ var28;
         byte var23 = (byte)var22;
         var0[var10] = var23;
         byte var24 = var0[var10];
         int var36 = var1.length;
         int var33 = var10 % var36;
         byte var30 = var1[var33];
         int var25 = var24 ^ var30;
         byte var26 = (byte)var25;
         var0[var10] = var26;
         ++var10;
      }
   }

   private static byte[] gjomfgjwdrmpwjd() {
      return new byte[]{9, 50, 73, 77, 112, 28, 115, 9, 3, 18, 75, 53, 10, 33, 35, 73, 88, 92, 116, 69, 49, 82, 70, 6, 122, 19, 79, 7, 108, 123, 17, 89, 124, 39, 97, 92, 22, 110, 37, 56, 5, 46, 4, 33, 35, 109, 62, 61, 117, 52, 80, 51, 74, 57, 91, 1, 101, 34, 78, 15, 85, 110, 80};
   }

   private static byte[] misjncvuflceaqr() {
      return new byte[0];
   }

   private static byte[] otuwbvpzdpxylja() {
      return new byte[0];
   }

   private static byte[] tymoywspsmcorqi() {
      return new byte[]{-58, -6, 112, 86, 65, 64, 75, 90, 48, 72, 122, 101, 51, 59, 18, 29, 96, 15, 71, 5};
   }

   private static byte[] nxenysiejqjtxvw() {
      return new byte[]{-58, -1, 124, 17, 67, 67, 74, 82, 48, 71, 122, 107, 63, 116};
   }

   private static byte[] qnmemuzkbivjydb() {
      return new byte[0];
   }

   private static int xyolscoqlligqowb(int var0, int var1) {
      return var0 ^ var1;
   }
}
