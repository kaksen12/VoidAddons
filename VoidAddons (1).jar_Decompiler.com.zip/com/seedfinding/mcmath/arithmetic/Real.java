package com.seedfinding.mcmath.arithmetic;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;

public class Real extends Number implements Comparable<Real> {
   public static final Real ZERO = of((double)0.0F);
   public static final Real HALF = of((double)0.5F);
   public static final Real ONE = of((double)1.0F);
   public static final Real TWO = of((double)2.0F);
   protected BigDecimal value;

   protected Real(BigDecimal value) {
      this.value = value;
   }

   public static Real of(BigDecimal value) {
      return new Real(value);
   }

   public static Real of(BigInteger value) {
      return of((new BigDecimal(value)).setScale(10, RoundingMode.HALF_UP));
   }

   public static Real of(double value) {
      return of(BigDecimal.valueOf(value).setScale(10, RoundingMode.HALF_UP));
   }

   public static Real of(long value) {
      return of(BigDecimal.valueOf(value).setScale(10, RoundingMode.HALF_UP));
   }

   public BigDecimal getValue() {
      return this.value;
   }

   public int getScale() {
      return this.getValue().scale();
   }

   private Real setScale(int scale) {
      return this.setScale(scale, RoundingMode.HALF_UP);
   }

   public Real setScale(int scale, RoundingMode rounding) {
      return of(this.getValue().setScale(scale, rounding));
   }

   public Real strip() {
      return of(this.getValue().stripTrailingZeros());
   }

   public Real abs() {
      return of(this.getValue().abs());
   }

   public Real negate() {
      return of(this.getValue().negate());
   }

   public Real invert() {
      return of(BigDecimal.ONE.divide(this.getValue(), this.getValue().scale(), RoundingMode.HALF_UP));
   }

   public int signum() {
      return this.getValue().signum();
   }

   public Real min(Real other) {
      return this.compareTo(other) <= 0 ? this : other;
   }

   public Real max(Real other) {
      return this.compareTo(other) >= 0 ? this : other;
   }

   public Real add(Real addend) {
      return this.add(addend.getValue());
   }

   public Real add(Rational addend) {
      return this.add(addend.toBigDecimal(this.getScale(), RoundingMode.HALF_UP));
   }

   public Real add(BigDecimal addend) {
      return of(this.getValue().add(addend));
   }

   public Real add(BigInteger addend) {
      return this.add(new BigDecimal(addend));
   }

   public Real add(double addend) {
      return this.add(BigDecimal.valueOf(addend));
   }

   public Real add(long addend) {
      return this.add(BigDecimal.valueOf(addend));
   }

   public Real subtract(Real subtrahend) {
      return this.subtract(subtrahend.getValue());
   }

   public Real subtract(Rational subtrahend) {
      return this.subtract(subtrahend.toBigDecimal(this.getScale(), RoundingMode.HALF_UP));
   }

   public Real subtract(BigDecimal subtrahend) {
      return of(this.getValue().subtract(subtrahend));
   }

   public Real subtract(BigInteger subtrahend) {
      return this.subtract(new BigDecimal(subtrahend));
   }

   public Real subtract(double subtrahend) {
      return this.subtract(BigDecimal.valueOf(subtrahend));
   }

   public Real subtract(long subtrahend) {
      return this.subtract(BigDecimal.valueOf(subtrahend));
   }

   public Real multiply(Real multiplier) {
      return this.multiply(multiplier.getValue());
   }

   public Real multiply(Rational multiplier) {
      return this.multiply(multiplier.toBigDecimal(this.getScale(), RoundingMode.HALF_UP));
   }

   public Real multiply(BigDecimal multiplier) {
      return of(this.getValue().multiply(multiplier));
   }

   public Real multiply(BigInteger multiplier) {
      return this.multiply(new BigDecimal(multiplier));
   }

   public Real multiply(double multiplier) {
      return this.multiply(BigDecimal.valueOf(multiplier));
   }

   public Real multiply(long multiplier) {
      return this.multiply(BigDecimal.valueOf(multiplier));
   }

   public Real divide(Real divisor) {
      return this.divide(divisor.getValue());
   }

   public Real divide(Rational divisor) {
      return this.divide(divisor.toBigDecimal(this.getScale(), RoundingMode.HALF_UP));
   }

   public Real divide(BigDecimal divisor) {
      return of(this.getValue().divide(divisor, RoundingMode.HALF_UP));
   }

   public Real divide(BigInteger divisor) {
      return this.divide(new BigDecimal(divisor));
   }

   public Real divide(double divisor) {
      return this.divide(BigDecimal.valueOf(divisor));
   }

   public Real divide(long divisor) {
      return this.divide(BigDecimal.valueOf(divisor));
   }

   public Real pow(Rational exponent) {
      return this.pow(exponent.getNumerator()).nthRoot(exponent.getDenominator());
   }

   public Real pow(BigInteger exponent) {
      return this.pow(exponent.intValueExact());
   }

   public Real pow(int exponent) {
      return of(this.getValue().pow(exponent));
   }

   public Real nthRoot(BigInteger n) {
      return this.nthRoot(n.intValue());
   }

   public Real nthRoot(int n) {
      if (n <= 0) {
         throw new IllegalArgumentException("Root must be positive");
      } else if (this.compareTo(ZERO) < 0) {
         throw new IllegalArgumentException("Root of negative number");
      } else if (this.equals(ZERO)) {
         return ZERO;
      } else if (n == 1) {
         return this;
      } else {
         Real xPrev = this;
         Real x = this.divide((long)n);
         Real a = of((long)(n - 1));

         for(Real p = of(BigDecimal.ONE.movePointLeft(this.getScale())); x.subtract(xPrev).abs().compareTo(p) > 0; x = a.multiply(x).add(this.divide(x.pow(n - 1))).divide((long)n)) {
            xPrev = x;
         }

         return x.setScale(this.getScale(), RoundingMode.HALF_UP);
      }
   }

   public Real sqrt() {
      return this.nthRoot(2);
   }

   public Real cbrt() {
      return this.nthRoot(3);
   }

   public Real floor() {
      return this.setScale(0, RoundingMode.FLOOR);
   }

   public Real ceil() {
      return this.setScale(0, RoundingMode.CEILING);
   }

   public Real round() {
      return this.setScale(0, RoundingMode.HALF_UP);
   }

   public int intValue() {
      return this.getValue().intValue();
   }

   public long longValue() {
      return this.getValue().longValue();
   }

   public float floatValue() {
      return this.getValue().floatValue();
   }

   public double doubleValue() {
      return this.getValue().doubleValue();
   }

   public BigInteger toBigInteger() {
      return this.getValue().toBigInteger();
   }

   public BigDecimal toBigDecimal() {
      return this.getValue();
   }

   public Rational toRational() {
      return Rational.of(this.getValue());
   }

   public int compareTo(Real other) {
      return this.getValue().compareTo(other.getValue());
   }

   public int hashCode() {
      return this.getValue().hashCode();
   }

   public boolean equals(Object other) {
      return this.getValue().equals(other);
   }

   public String toString() {
      return this.getValue().stripTrailingZeros().toString();
   }
}
