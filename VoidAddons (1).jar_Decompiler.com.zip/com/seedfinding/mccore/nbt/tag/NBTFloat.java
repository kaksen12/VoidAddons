package com.seedfinding.mccore.nbt.tag;

import com.seedfinding.mccore.net.ByteBuffer;
import java.io.IOException;
import java.nio.ByteOrder;

public class NBTFloat extends NBTTag<Float> {
   public static final NBTFloat NULL = new NBTFloat() {
      public void readPayload(ByteBuffer buffer) {
         throw new NullPointerException();
      }

      public void writePayload(ByteBuffer buffer) {
         throw new NullPointerException();
      }
   };

   public NBTFloat() {
      this(0.0F);
   }

   public NBTFloat(float value) {
      super(value);
   }

   public void readPayload(ByteBuffer buffer) throws IOException {
      this.setValue(buffer.readFloat(ByteOrder.BIG_ENDIAN));
   }

   public void writePayload(ByteBuffer buffer) throws IOException {
      buffer.writeFloat((Float)this.getValue(), ByteOrder.BIG_ENDIAN);
   }
}
