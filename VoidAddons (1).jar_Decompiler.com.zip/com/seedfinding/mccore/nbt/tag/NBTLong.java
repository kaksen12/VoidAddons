package com.seedfinding.mccore.nbt.tag;

import com.seedfinding.mccore.net.ByteBuffer;
import java.io.IOException;
import java.nio.ByteOrder;

public class NBTLong extends NBTTag<Long> {
   public static final NBTLong NULL = new NBTLong() {
      public void readPayload(ByteBuffer buffer) {
         throw new NullPointerException();
      }

      public void writePayload(ByteBuffer buffer) {
         throw new NullPointerException();
      }
   };

   public NBTLong() {
      this(0L);
   }

   public NBTLong(long value) {
      super(value);
   }

   public void readPayload(ByteBuffer buffer) throws IOException {
      this.setValue(buffer.readLong(ByteOrder.BIG_ENDIAN));
   }

   public void writePayload(ByteBuffer buffer) throws IOException {
      buffer.writeLong((Long)this.getValue(), ByteOrder.BIG_ENDIAN);
   }
}
