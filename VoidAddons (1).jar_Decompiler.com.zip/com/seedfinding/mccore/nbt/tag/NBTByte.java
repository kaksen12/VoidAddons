package com.seedfinding.mccore.nbt.tag;

import com.seedfinding.mccore.net.ByteBuffer;
import java.io.IOException;

public class NBTByte extends NBTTag<Byte> {
   public static final NBTByte NULL = new NBTByte() {
      public void readPayload(ByteBuffer buffer) {
         throw new NullPointerException();
      }

      public void writePayload(ByteBuffer buffer) {
         throw new NullPointerException();
      }
   };

   public NBTByte() {
      this((byte)0);
   }

   public NBTByte(byte value) {
      super(value);
   }

   public void readPayload(ByteBuffer buffer) throws IOException {
      this.setValue(buffer.readByte());
   }

   public void writePayload(ByteBuffer buffer) throws IOException {
      buffer.writeByte((Byte)this.getValue());
   }
}
