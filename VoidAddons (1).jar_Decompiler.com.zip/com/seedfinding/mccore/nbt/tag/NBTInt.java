package com.seedfinding.mccore.nbt.tag;

import com.seedfinding.mccore.net.ByteBuffer;
import java.io.IOException;
import java.nio.ByteOrder;

public class NBTInt extends NBTTag<Integer> {
   public static final NBTInt NULL = new NBTInt() {
      public void readPayload(ByteBuffer buffer) {
         throw new NullPointerException();
      }

      public void writePayload(ByteBuffer buffer) {
         throw new NullPointerException();
      }
   };

   public NBTInt() {
      this(0);
   }

   public NBTInt(int value) {
      super(value);
   }

   public void readPayload(ByteBuffer buffer) throws IOException {
      this.setValue(buffer.readInt(ByteOrder.BIG_ENDIAN));
   }

   public void writePayload(ByteBuffer buffer) throws IOException {
      buffer.writeInt((Integer)this.getValue(), ByteOrder.BIG_ENDIAN);
   }
}
