package com.seedfinding.mccore.nbt.tag;

import com.seedfinding.mccore.net.ByteBuffer;
import java.io.IOException;

public class NBTEnd extends NBTTag<Void> {
   public static final NBTEnd INSTANCE = new NBTEnd();

   public NBTEnd() {
      super((Object)null);
   }

   public void read(ByteBuffer buffer) {
   }

   public void write(ByteBuffer buffer) throws IOException {
      buffer.writeByte(this.getType());
   }

   public void readPayload(ByteBuffer buffer) {
   }

   public void writePayload(ByteBuffer buffer) {
   }
}
