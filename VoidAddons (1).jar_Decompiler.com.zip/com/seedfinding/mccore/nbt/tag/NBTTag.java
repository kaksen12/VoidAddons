package com.seedfinding.mccore.nbt.tag;

import com.seedfinding.mccore.nbt.NBTType;
import com.seedfinding.mccore.net.ByteBuffer;
import com.seedfinding.mccore.net.IByteSerializable;
import java.io.IOException;
import java.nio.ByteOrder;
import java.util.Objects;

public abstract class NBTTag<T> implements IByteSerializable {
   private String name = "";
   private T value;

   public NBTTag(T value) {
      this.setValue(value);
   }

   public static NBTTag<?> create(ByteBuffer buffer) throws IOException {
      NBTTag<?> tag = NBTType.createEmpty(buffer.readByte());
      tag.read(buffer);
      return tag;
   }

   public final String getName() {
      return this.name;
   }

   public T getValue() {
      return this.value;
   }

   public NBTTag<?> setValue(T value) {
      this.value = value;
      return this;
   }

   public final byte getType() {
      return NBTType.getTypeOf(this.getClass());
   }

   public void read(ByteBuffer buffer) throws IOException {
      this.name = buffer.readASCII(ByteOrder.BIG_ENDIAN);
      this.readPayload(buffer);
   }

   public void write(ByteBuffer buffer) throws IOException {
      if (this.getType() < 0) {
         throw new RuntimeException("Serializing unregistered tag " + this.getClass());
      } else {
         this.writePayload(buffer.writeByte(this.getType()).writeASCII(this.name, ByteOrder.BIG_ENDIAN));
      }
   }

   public abstract void readPayload(ByteBuffer var1) throws IOException;

   public abstract void writePayload(ByteBuffer var1) throws IOException;

   public boolean equals(Object other) {
      if (this == other) {
         return true;
      } else if (!(other instanceof NBTTag)) {
         return false;
      } else {
         NBTTag<?> that = (NBTTag)other;
         return this.getType() == that.getType() && this.getValue().equals(that.getValue());
      }
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.getName(), this.getValue()});
   }

   public String toString() {
      return this.value.toString();
   }
}
