package com.seedfinding.mccore.nbt.tag;

import com.seedfinding.mccore.net.ByteBuffer;
import java.io.IOException;
import java.nio.ByteOrder;

public class NBTString extends NBTTag<String> {
   public static final NBTString NULL = new NBTString() {
      public void readPayload(ByteBuffer buffer) {
         throw new NullPointerException();
      }

      public void writePayload(ByteBuffer buffer) {
         throw new NullPointerException();
      }
   };

   public NBTString() {
      this("");
   }

   public NBTString(String value) {
      super(value);
   }

   public void readPayload(ByteBuffer buffer) throws IOException {
      this.setValue(buffer.readASCII(ByteOrder.BIG_ENDIAN));
   }

   public void writePayload(ByteBuffer buffer) throws IOException {
      buffer.writeASCII((String)this.getValue(), ByteOrder.BIG_ENDIAN);
   }
}
