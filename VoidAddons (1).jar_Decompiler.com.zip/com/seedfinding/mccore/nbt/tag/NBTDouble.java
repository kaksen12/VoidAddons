package com.seedfinding.mccore.nbt.tag;

import com.seedfinding.mccore.net.ByteBuffer;
import java.io.IOException;
import java.nio.ByteOrder;

public class NBTDouble extends NBTTag<Double> {
   public static final NBTDouble NULL = new NBTDouble() {
      public void readPayload(ByteBuffer buffer) {
         throw new NullPointerException();
      }

      public void writePayload(ByteBuffer buffer) {
         throw new NullPointerException();
      }
   };

   public NBTDouble() {
      this((double)0.0F);
   }

   public NBTDouble(double value) {
      super(value);
   }

   public void readPayload(ByteBuffer buffer) throws IOException {
      this.setValue(buffer.readDouble(ByteOrder.BIG_ENDIAN));
   }

   public void writePayload(ByteBuffer buffer) throws IOException {
      buffer.writeDouble((Double)this.getValue(), ByteOrder.BIG_ENDIAN);
   }
}
