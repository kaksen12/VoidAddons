package com.seedfinding.mccore.gen;

import com.seedfinding.mccore.block.Blocks;
import com.seedfinding.mccore.block.Tile;
import com.seedfinding.mccore.util.data.Identifier;
import com.seedfinding.mccore.util.math.Vec3i;
import com.seedfinding.mccore.util.pos.BPos;
import com.seedfinding.mcseed.rand.JRand;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StructurePiece {
   private final PieceInfo info;
   private BPos position;
   private StructurePlacement placement;

   public StructurePiece(PieceInfo info) {
      this.info = info;
   }

   public PieceInfo getInfo() {
      return this.info;
   }

   public void generate(JRand rand) {
      for(Tile jigsaw : this.getJigsaws(rand)) {
         Vec3i facing = JigsawHelper.getFacing(jigsaw.getBlockState()).getVector();
         BPos nextPieceStart = jigsaw.getPos().add(facing.getX(), facing.getY(), facing.getZ());
         new Identifier(jigsaw.getBlockEntity().getString("pool"));
         this.placement.box.contains(nextPieceStart);
      }

   }

   public List<Tile> getJigsaws(JRand rand) {
      int paletteId = rand.nextInt(this.info.getPalettes().size());
      Stream var10000 = this.info.getTiles().stream().sorted(PieceInfo.TILE_SORTER).filter((tile) -> tile.getBlockState(paletteId).getBlock().getId() == Blocks.JIGSAW.getId()).map((tile) -> tile.copy(paletteId));
      StructurePlacement var10001 = this.placement;
      Objects.requireNonNull(var10001);
      List<Tile> tiles = (List)var10000.map(var10001::transformAndSet).peek((tile) -> tile.setPos(tile.getPos().add(this.position))).filter((tile) -> this.placement.box.contains(tile.getPos())).peek((tile) -> JigsawHelper.rotate(tile.getBlockState(), this.placement.rotation)).collect(Collectors.toList());
      rand.shuffle(tiles);
      return tiles;
   }
}
