package com.seedfinding.mcfeature.structure;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mcbiome.source.BiomeSource;
import com.seedfinding.mccore.state.Dimension;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mccore.version.VersionMap;

public class Mansion extends TriangularStructure<Mansion> {
   public static final VersionMap<RegionStructure.Config> CONFIGS;

   public Mansion(MCVersion version) {
      this(CONFIGS.getAsOf(version), version);
   }

   public Mansion(RegionStructure.Config config, MCVersion version) {
      super(config, version);
   }

   public static String name() {
      return "mansion";
   }

   public boolean canSpawn(int chunkX, int chunkZ, BiomeSource source) {
      return !super.canSpawn(chunkX, chunkZ, source) ? false : source.iterateUniqueBiomes((chunkX << 4) + 9, (chunkZ << 4) + 9, 32, this::isValidBiome);
   }

   public Dimension getValidDimension() {
      return Dimension.OVERWORLD;
   }

   public boolean isValidBiome(Biome biome) {
      return biome == Biomes.DARK_FOREST || biome == Biomes.DARK_FOREST_HILLS;
   }

   static {
      CONFIGS = (new VersionMap<RegionStructure.Config>()).add(MCVersion.v1_11, new RegionStructure.Config(80, 20, 10387319));
   }
}
