package com.seedfinding.mcfeature.structure.generator.piece.stronghold;

import com.seedfinding.mccore.util.block.BlockBox;
import com.seedfinding.mccore.util.block.BlockDirection;
import com.seedfinding.mccore.util.pos.BPos;
import com.seedfinding.mcfeature.structure.Stronghold;
import com.seedfinding.mcfeature.structure.generator.structure.StrongholdGenerator;
import com.seedfinding.mcseed.rand.JRand;
import java.util.List;

public class Corridor extends Stronghold.Piece {
   private final boolean leftExitExists;
   private final boolean rightExitExists;

   public Corridor(int pieceId, JRand rand, BlockBox boundingBox, BlockDirection facing) {
      super(pieceId);
      this.setOrientation(facing);
      rand.nextInt(5);
      this.boundingBox = boundingBox;
      this.leftExitExists = rand.nextInt(2) == 0;
      this.rightExitExists = rand.nextInt(2) == 0;
   }

   public static Corridor createPiece(List<Stronghold.Piece> pieces, JRand rand, int x, int y, int z, BlockDirection facing, int pieceId) {
      BlockBox box = BlockBox.rotated(x, y, z, -1, -1, 0, 5, 5, 7, facing.getRotation());
      return Stronghold.Piece.isHighEnough(box) && Stronghold.Piece.getNextIntersectingPiece(pieces, box) == null ? new Corridor(pieceId, rand, box, facing) : null;
   }

   public void populatePieces(StrongholdGenerator gen, Start start, List<Stronghold.Piece> pieces, JRand rand) {
      this.generateSmallDoorChildrenForward(gen, start, pieces, rand, 1, 1);
      if (this.leftExitExists) {
         this.generateSmallDoorChildrenLeft(gen, start, pieces, rand, 1, 2);
      }

      if (this.rightExitExists) {
         this.generateSmallDoorChildRight(gen, start, pieces, rand, 1, 2);
      }

   }

   public boolean process(JRand rand, BPos pos) {
      this.skipWithRandomized(rand, 0, 0, 0, 4, 4, 6, true);
      this.skipWithChance(rand, 0.1F);
      this.skipWithChance(rand, 0.1F);
      this.skipWithChance(rand, 0.1F);
      this.skipWithChance(rand, 0.1F);
      return true;
   }
}
