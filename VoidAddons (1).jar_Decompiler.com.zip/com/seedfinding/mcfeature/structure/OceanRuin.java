package com.seedfinding.mcfeature.structure;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mccore.state.Dimension;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mccore.version.VersionMap;

public class OceanRuin extends UniformStructure<OceanRuin> {
   public static final VersionMap<RegionStructure.Config> CONFIGS;

   public OceanRuin(MCVersion version) {
      this(CONFIGS.getAsOf(version), version);
   }

   public OceanRuin(RegionStructure.Config config, MCVersion version) {
      super(config, version);
   }

   public static String name() {
      return "ocean_ruin";
   }

   public Dimension getValidDimension() {
      return Dimension.OVERWORLD;
   }

   public boolean isValidBiome(Biome biome) {
      return biome.getCategory() == Biome.Category.OCEAN;
   }

   static {
      CONFIGS = (new VersionMap<RegionStructure.Config>()).add(MCVersion.v1_13, new RegionStructure.Config(16, 8, 14357621)).add(MCVersion.v1_16, new RegionStructure.Config(20, 8, 14357621));
   }
}
