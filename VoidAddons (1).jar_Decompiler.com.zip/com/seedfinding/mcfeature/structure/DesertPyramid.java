package com.seedfinding.mcfeature.structure;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mccore.state.Dimension;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mccore.version.VersionMap;
import com.seedfinding.mcfeature.loot.ILoot;
import com.seedfinding.mcfeature.structure.generator.Generator;
import com.seedfinding.mcfeature.structure.generator.structure.DesertPyramidGenerator;

public class DesertPyramid extends OldStructure<DesertPyramid> implements ILoot {
   public static final VersionMap<OldStructure.Config> CONFIGS;

   public DesertPyramid(MCVersion version) {
      this(CONFIGS.getAsOf(version), version);
   }

   public DesertPyramid(RegionStructure.Config config, MCVersion version) {
      super(config, version);
   }

   public static String name() {
      return "desert_pyramid";
   }

   public Dimension getValidDimension() {
      return Dimension.OVERWORLD;
   }

   public boolean isValidBiome(Biome biome) {
      return biome == Biomes.DESERT || biome == Biomes.DESERT_HILLS;
   }

   public int getDecorationSalt() {
      return this.getVersion().isNewerOrEqualTo(MCVersion.v1_16) ? '鱃' : 30002;
   }

   public boolean isCorrectGenerator(Generator generator) {
      return generator instanceof DesertPyramidGenerator;
   }

   public ILoot.SpecificCalls getSpecificCalls() {
      return null;
   }

   public boolean shouldAdvanceInChunks() {
      return false;
   }

   static {
      CONFIGS = (new VersionMap<OldStructure.Config>()).add(MCVersion.v1_8, new OldStructure.Config(14357617));
   }
}
