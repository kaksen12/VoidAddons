package com.seedfinding.mcfeature.loot;

import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcfeature.loot.function.LootFunction;
import com.seedfinding.mcfeature.loot.item.Item;
import com.seedfinding.mcfeature.loot.item.ItemStack;
import com.seedfinding.mcfeature.loot.roll.UniformRoll;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class LootTable extends LootGenerator {
   public final LootPool[] lootPools;
   private boolean hasVersionApplied;
   private Integer luck;

   public LootTable(LootPool... lootPools) {
      this(Arrays.asList(lootPools), (Collection)null);
   }

   public LootTable(Collection<LootPool> lootPools, Collection<Function<MCVersion, LootFunction>> lootFunctions) {
      this.hasVersionApplied = false;
      this.luck = null;
      this.lootPools = (LootPool[])lootPools.toArray(new LootPool[0]);
      this.apply((Collection)lootFunctions);
   }

   public LootTable apply(MCVersion version) {
      return this.apply(version, 1);
   }

   public LootTable apply(MCVersion version, int luck) {
      for(LootPool lootPool : this.lootPools) {
         lootPool.apply(version).processWeights(luck, (LootContext)null);
      }

      this.hasVersionApplied = true;
      this.luck = luck;
      return this;
   }

   public LootTable apply(MCVersion version, int luck, LootContext lootContext) {
      for(LootPool lootPool : this.lootPools) {
         lootPool.apply(version).processWeights(luck, lootContext);
      }

      this.hasVersionApplied = true;
      this.luck = luck;
      return this;
   }

   private LootTable apply(int luck) {
      if (!this.hasVersionApplied) {
         System.err.println("Version was not applied, we default to latest " + MCVersion.latest());
         return this.apply(MCVersion.latest(), luck);
      } else {
         for(LootPool lootPool : this.lootPools) {
            lootPool.processWeights(luck, (LootContext)null);
         }

         this.luck = luck;
         return this;
      }
   }

   public static LinkedList<ItemStack> shuffleItems(LootContext context, LinkedList<ItemStack> items) {
      List<Integer> container = (List)IntStream.range(0, 27).boxed().collect(Collectors.toList());
      context.shuffle(container);
      List<ItemStack> list = new ArrayList();
      Iterator<ItemStack> iterator = items.iterator();
      int size = container.size();

      while(iterator.hasNext()) {
         ItemStack itemstack = (ItemStack)iterator.next();
         if (itemstack.isEmpty()) {
            iterator.remove();
         } else if (itemstack.getCount() > 1) {
            list.add(itemstack);
            iterator.remove();
         }
      }

      while(size - items.size() - list.size() > 0 && !list.isEmpty()) {
         ItemStack itemstack2 = (ItemStack)list.remove((new UniformRoll(0.0F, (float)(list.size() - 1))).getCount(context));
         int half = itemstack2.getCount() / 2;
         int i = (new UniformRoll(1.0F, (float)half)).getCount(context);
         ItemStack itemstack1 = itemstack2.split(i);
         if (itemstack2.getCount() > 1 && context.nextBoolean()) {
            list.add(itemstack2);
         } else {
            items.add(itemstack2);
         }

         if (itemstack1.getCount() > 1 && context.nextBoolean()) {
            list.add(itemstack1);
         } else {
            items.add(itemstack1);
         }
      }

      items.addAll(list);
      context.shuffle(items);
      HashMap<Integer, ItemStack> positions = new HashMap();
      int len = container.size();

      for(ItemStack itemstack : items) {
         if (container.isEmpty()) {
            return items;
         }

         if (itemstack.isEmpty()) {
            positions.put((Integer)container.remove(container.size() - 1), ItemStack.EMPTY);
         } else {
            positions.put((Integer)container.remove(container.size() - 1), itemstack);
         }
      }

      LinkedList<ItemStack> result = new LinkedList();

      for(int i = 0; i < len; ++i) {
         result.add((ItemStack)positions.getOrDefault(i, ItemStack.EMPTY));
      }

      return result;
   }

   public void generate(LootContext context, Consumer<ItemStack> stackConsumer) {
      if (!this.hasVersionApplied) {
         this.apply(context.getVersion(), context.getLuck(), context);
      } else if (this.luck == null || this.luck != context.getLuck()) {
         this.apply(context.getLuck());
      }

      stackConsumer = LootFunction.stack(stackConsumer, this.combinedLootFunction, context);

      for(LootPool lootPool : this.lootPools) {
         lootPool.generate(context, stackConsumer);
      }

   }

   public LinkedList<ItemStack> generateIndexed(LootContext context) {
      LinkedList<ItemStack> itemStacks = new LinkedList();
      Objects.requireNonNull(itemStacks);
      this.generate(context, itemStacks::add);
      return shuffleItems(context, itemStacks);
   }

   public List<ItemStack> generate(LootContext context) {
      Map<Item, Integer> itemCounts = new HashMap();
      this.generate(context, (stack) -> {
         int oldCount = (Integer)itemCounts.getOrDefault(stack.getItem(), 0);
         itemCounts.put(stack.getItem(), oldCount + stack.getCount());
      });
      return (List)itemCounts.entrySet().stream().map((e) -> new ItemStack((Item)e.getKey(), (Integer)e.getValue())).collect(Collectors.toList());
   }
}
