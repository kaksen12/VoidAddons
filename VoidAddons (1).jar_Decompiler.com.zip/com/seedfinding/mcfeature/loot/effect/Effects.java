package com.seedfinding.mcfeature.loot.effect;

import com.seedfinding.mccore.util.data.Pair;
import com.seedfinding.mcfeature.loot.effect.attribute.AttributeModifier;
import com.seedfinding.mcfeature.loot.effect.attribute.Attributes;
import java.util.HashMap;
import java.util.LinkedHashMap;

public class Effects {
   public static final HashMap<Pair<Integer, String>, Effect> EFFECTS = new LinkedHashMap();
   public static final Effect MOVEMENT_SPEED;
   public static final Effect MOVEMENT_SLOWDOWN;
   public static final Effect DIG_SPEED;
   public static final Effect DIG_SLOWDOWN;
   public static final Effect DAMAGE_BOOST;
   public static final Effect HEAL;
   public static final Effect HARM;
   public static final Effect JUMP;
   public static final Effect CONFUSION;
   public static final Effect REGENERATION;
   public static final Effect DAMAGE_RESISTANCE;
   public static final Effect FIRE_RESISTANCE;
   public static final Effect WATER_BREATHING;
   public static final Effect INVISIBILITY;
   public static final Effect BLINDNESS;
   public static final Effect NIGHT_VISION;
   public static final Effect HUNGER;
   public static final Effect WEAKNESS;
   public static final Effect POISON;
   public static final Effect WITHER;
   public static final Effect HEALTH_BOOST;
   public static final Effect ABSORPTION;
   public static final Effect SATURATION;
   public static final Effect GLOWING;
   public static final Effect LEVITATION;
   public static final Effect LUCK;
   public static final Effect UNLUCK;
   public static final Effect SLOW_FALLING;
   public static final Effect CONDUIT_POWER;
   public static final Effect DOLPHINS_GRACE;
   public static final Effect BAD_OMEN;

   private static Effect register(int id, String name, Effect effect) {
      EFFECTS.put(new Pair(id, name), effect);
      return effect;
   }

   public static HashMap<Pair<Integer, String>, Effect> getEffects() {
      return EFFECTS;
   }

   static {
      MOVEMENT_SPEED = register(1, "speed", (new Effect(Effect.EffectType.BENEFICIAL, 8171462)).addAttributeModifier(Attributes.MOVEMENT_SPEED, "91AEAA56-376B-4498-935B-2F7F68070635", (double)0.2F, AttributeModifier.Operation.MULTIPLY_TOTAL));
      MOVEMENT_SLOWDOWN = register(2, "slowness", (new Effect(Effect.EffectType.HARMFUL, 5926017)).addAttributeModifier(Attributes.MOVEMENT_SPEED, "7107DE5E-7CE8-4030-940E-514C1F160890", (double)-0.15F, AttributeModifier.Operation.MULTIPLY_TOTAL));
      DIG_SPEED = register(3, "haste", (new Effect(Effect.EffectType.BENEFICIAL, 14270531)).addAttributeModifier(Attributes.ATTACK_SPEED, "AF8B6E3F-3328-4C0A-AA36-5BA2BB9DBEF3", (double)0.1F, AttributeModifier.Operation.MULTIPLY_TOTAL));
      DIG_SLOWDOWN = register(4, "mining_fatigue", (new Effect(Effect.EffectType.HARMFUL, 4866583)).addAttributeModifier(Attributes.ATTACK_SPEED, "55FCED67-E92A-486E-9800-B47F202C4386", (double)-0.1F, AttributeModifier.Operation.MULTIPLY_TOTAL));
      DAMAGE_BOOST = register(5, "strength", (new Effect.AttackDamageEffect(Effect.EffectType.BENEFICIAL, 9643043, (double)3.0F)).addAttributeModifier(Attributes.ATTACK_DAMAGE, "648D7064-6A60-4F59-8ABE-C2C23A6DD7A9", (double)0.0F, AttributeModifier.Operation.ADDITION));
      HEAL = register(6, "instant_health", new Effect.InstantEffect(Effect.EffectType.BENEFICIAL, 16262179));
      HARM = register(7, "instant_damage", new Effect.InstantEffect(Effect.EffectType.HARMFUL, 4393481));
      JUMP = register(8, "jump_boost", new Effect(Effect.EffectType.BENEFICIAL, 2293580));
      CONFUSION = register(9, "nausea", new Effect(Effect.EffectType.HARMFUL, 5578058));
      REGENERATION = register(10, "regeneration", new Effect(Effect.EffectType.BENEFICIAL, 13458603));
      DAMAGE_RESISTANCE = register(11, "resistance", new Effect(Effect.EffectType.BENEFICIAL, 10044730));
      FIRE_RESISTANCE = register(12, "fire_resistance", new Effect(Effect.EffectType.BENEFICIAL, 14981690));
      WATER_BREATHING = register(13, "water_breathing", new Effect(Effect.EffectType.BENEFICIAL, 3035801));
      INVISIBILITY = register(14, "invisibility", new Effect(Effect.EffectType.BENEFICIAL, 8356754));
      BLINDNESS = register(15, "blindness", new Effect(Effect.EffectType.HARMFUL, 2039587));
      NIGHT_VISION = register(16, "night_vision", new Effect(Effect.EffectType.BENEFICIAL, 2039713));
      HUNGER = register(17, "hunger", new Effect(Effect.EffectType.HARMFUL, 5797459));
      WEAKNESS = register(18, "weakness", (new Effect.AttackDamageEffect(Effect.EffectType.HARMFUL, 4738376, (double)-4.0F)).addAttributeModifier(Attributes.ATTACK_DAMAGE, "22653B89-116E-49DC-9B6B-9971489B5BE5", (double)0.0F, AttributeModifier.Operation.ADDITION));
      POISON = register(19, "poison", new Effect(Effect.EffectType.HARMFUL, 5149489));
      WITHER = register(20, "wither", new Effect(Effect.EffectType.HARMFUL, 3484199));
      HEALTH_BOOST = register(21, "health_boost", (new Effect.HealthBoostEffect(Effect.EffectType.BENEFICIAL, 16284963)).addAttributeModifier(Attributes.MAX_HEALTH, "5D6F0BA2-1186-46AC-B896-C61C5CEE99CC", (double)4.0F, AttributeModifier.Operation.ADDITION));
      ABSORPTION = register(22, "absorption", new Effect.AbsorptionEffect(Effect.EffectType.BENEFICIAL, 2445989));
      SATURATION = register(23, "saturation", new Effect.InstantEffect(Effect.EffectType.BENEFICIAL, 16262179));
      GLOWING = register(24, "glowing", new Effect(Effect.EffectType.NEUTRAL, 9740385));
      LEVITATION = register(25, "levitation", new Effect(Effect.EffectType.HARMFUL, 13565951));
      LUCK = register(26, "luck", (new Effect(Effect.EffectType.BENEFICIAL, 3381504)).addAttributeModifier(Attributes.LUCK, "03C3C89D-7037-4B42-869F-B146BCB64D2E", (double)1.0F, AttributeModifier.Operation.ADDITION));
      UNLUCK = register(27, "unluck", (new Effect(Effect.EffectType.HARMFUL, 12624973)).addAttributeModifier(Attributes.LUCK, "CC5AF142-2BD2-4215-B636-2605AED11727", (double)-1.0F, AttributeModifier.Operation.ADDITION));
      SLOW_FALLING = register(28, "slow_falling", new Effect(Effect.EffectType.BENEFICIAL, 16773073));
      CONDUIT_POWER = register(29, "conduit_power", new Effect(Effect.EffectType.BENEFICIAL, 1950417));
      DOLPHINS_GRACE = register(30, "dolphins_grace", new Effect(Effect.EffectType.BENEFICIAL, 8954814));
      BAD_OMEN = register(31, "bad_omen", new Effect(Effect.EffectType.NEUTRAL, 745784));
   }
}
