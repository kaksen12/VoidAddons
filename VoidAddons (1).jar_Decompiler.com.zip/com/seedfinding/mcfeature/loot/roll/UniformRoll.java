package com.seedfinding.mcfeature.loot.roll;

import com.seedfinding.mcfeature.loot.LootContext;
import com.seedfinding.mcnoise.utils.MathHelper;

public class UniformRoll extends LootRoll {
   public final int min;
   public final int max;

   public UniformRoll(float value) {
      this(value, value);
   }

   public UniformRoll(float min, float max) {
      this.min = MathHelper.floor((double)min);
      this.max = MathHelper.floor((double)max);
   }

   public int getCount(LootContext context) {
      return this.min >= this.max ? this.min : context.nextInt(this.max - this.min + 1) + this.min;
   }

   public float getFloat(LootContext context) {
      return this.min >= this.max ? (float)this.min : context.nextFloat() * (float)(this.max - this.min) + (float)this.min;
   }
}
