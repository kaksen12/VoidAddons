package com.seedfinding.mcfeature.decorator.ore.overworld;

import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mccore.block.Blocks;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mccore.version.VersionMap;
import com.seedfinding.mcfeature.decorator.ore.HeightProvider;
import com.seedfinding.mcfeature.decorator.ore.OreDecorator;
import com.seedfinding.mcfeature.decorator.ore.SphereOreDecorator;

public class ClayDisk extends SphereOreDecorator<OreDecorator.Config, OreDecorator.Data<ClayDisk>> {
   public static final VersionMap<OreDecorator.Config> CONFIGS;

   public ClayDisk(MCVersion version) {
      super(CONFIGS.getAsOf(version), version);
   }

   public String getName() {
      return name();
   }

   public static String name() {
      return "clay_disk";
   }

   static {
      CONFIGS = (new VersionMap<OreDecorator.Config>()).add(MCVersion.v1_13, (new OreDecorator.Config(12, 4, 2, 1, HeightProvider.spreadRange(2, 1), Blocks.CLAY, DIRT_CLAY)).add(11, 4, Biomes.SWAMP, Biomes.SWAMP_HILLS)).add(MCVersion.v1_16, (new OreDecorator.Config(12, 6, 2, 1, HeightProvider.spreadRange(2, 1), Blocks.CLAY, DIRT_CLAY)).add(11, 6, Biomes.SWAMP, Biomes.SWAMP_HILLS)).add(MCVersion.v1_17, (new OreDecorator.Config(15, 6, 2, 1, HeightProvider.spreadRange(2, 1), Blocks.CLAY, DIRT_CLAY)).add(14, 6, Biomes.SWAMP, Biomes.SWAMP_HILLS));
   }
}
