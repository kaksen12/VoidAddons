package com.seedfinding.mcfeature.decorator.ore.overworld;

import com.seedfinding.mccore.block.Blocks;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mccore.version.VersionMap;
import com.seedfinding.mcfeature.decorator.ore.HeightProvider;
import com.seedfinding.mcfeature.decorator.ore.OreDecorator;
import com.seedfinding.mcfeature.decorator.ore.RegularOreDecorator;

public class LapisOre extends RegularOreDecorator<OreDecorator.Config, OreDecorator.Data<LapisOre>> {
   public static final VersionMap<OreDecorator.Config> CONFIGS;

   public LapisOre(MCVersion version) {
      super(CONFIGS.getAsOf(version), version);
   }

   public String getName() {
      return name();
   }

   public static String name() {
      return "lapis_ore";
   }

   static {
      CONFIGS = (new VersionMap<OreDecorator.Config>()).add(MCVersion.v1_13, new OreDecorator.Config(10, 4, 7, 1, HeightProvider.depthAverage(16, 16), Blocks.LAPIS_ORE, BASE_STONE_OVERWORLD)).add(MCVersion.v1_16, new OreDecorator.Config(10, 6, 7, 1, HeightProvider.depthAverage(16, 16), Blocks.LAPIS_ORE, BASE_STONE_OVERWORLD)).add(MCVersion.v1_17, new OreDecorator.Config(12, 6, 7, 1, HeightProvider.triangleRange(0, 30), Blocks.LAPIS_ORE, BASE_STONE_OVERWORLD));
   }
}
