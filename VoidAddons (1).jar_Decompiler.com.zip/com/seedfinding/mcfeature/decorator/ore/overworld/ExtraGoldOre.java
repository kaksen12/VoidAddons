package com.seedfinding.mcfeature.decorator.ore.overworld;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.Biomes;
import com.seedfinding.mccore.block.Blocks;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mccore.version.VersionMap;
import com.seedfinding.mcfeature.decorator.ore.HeightProvider;
import com.seedfinding.mcfeature.decorator.ore.OreDecorator;
import com.seedfinding.mcfeature.decorator.ore.RegularOreDecorator;

public class ExtraGoldOre extends RegularOreDecorator<OreDecorator.Config, OreDecorator.Data<ExtraGoldOre>> {
   public static final VersionMap<OreDecorator.Config> CONFIGS;

   public ExtraGoldOre(MCVersion version) {
      super(CONFIGS.getAsOf(version), version);
   }

   public String getName() {
      return name();
   }

   public static String name() {
      return "extra_gold_ore";
   }

   public boolean isValidBiome(Biome biome) {
      return biome == Biomes.BADLANDS || biome == Biomes.WOODED_BADLANDS_PLATEAU || biome == Biomes.BADLANDS_PLATEAU || biome == Biomes.ERODED_BADLANDS || biome == Biomes.MODIFIED_WOODED_BADLANDS_PLATEAU || biome == Biomes.MODIFIED_BADLANDS_PLATEAU;
   }

   static {
      CONFIGS = (new VersionMap<OreDecorator.Config>()).add(MCVersion.v1_13, new OreDecorator.Config(11, 4, 9, 20, HeightProvider.range(32, 32, 80), Blocks.GOLD_ORE, BASE_STONE_OVERWORLD)).add(MCVersion.v1_16, new OreDecorator.Config(11, 6, 9, 20, HeightProvider.range(32, 32, 80), Blocks.GOLD_ORE, BASE_STONE_OVERWORLD)).add(MCVersion.v1_17, new OreDecorator.Config(14, 6, 9, 20, HeightProvider.uniformRange(32, 79), Blocks.GOLD_ORE, BASE_STONE_OVERWORLD));
   }
}
