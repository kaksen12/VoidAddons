package com.seedfinding.mcterrain.terrain;

import com.seedfinding.mcbiome.source.BiomeSource;
import com.seedfinding.mccore.block.Block;
import com.seedfinding.mccore.block.Blocks;
import com.seedfinding.mccore.state.Dimension;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcterrain.utils.NoiseSettings;

public class NetherTerrainGenerator extends SurfaceGenerator {
   private final double[] fallOffTable = this.computeFallOffTable();

   public NetherTerrainGenerator(BiomeSource biomeSource) {
      super(biomeSource, 128, 1, 2, biomeSource.getVersion().isNewerOrEqualTo(MCVersion.v1_16) ? NoiseSettings.create((double)1.0F, (double)3.0F, (double)80.0F, (double)60.0F).addTopSlide(120, 3, 0).addBottomSlide(320, 4, -1) : NoiseSettings.create((double)1.0F, (double)3.0F, (double)80.0F, (double)60.0F).addTopSlide(-10, 3, 0).addBottomSlide(-30, 1, 0), (double)0.0F, 0.019921875, false);
   }

   public int getSeaLevel() {
      return 32;
   }

   public Block getDefaultBlock() {
      return Blocks.NETHERRACK;
   }

   public Dimension getDimension() {
      return Dimension.NETHER;
   }

   public Block getDefaultFluid() {
      return Blocks.LAVA;
   }

   public int getBedrockRoofPosition() {
      return 0;
   }

   public int getBedrockFloorPosition() {
      return 0;
   }

   protected double computeNoiseFalloff(double depth, double scale, int y) {
      return this.getVersion().isNewerOrEqualTo(MCVersion.v1_16) ? super.computeNoiseFalloff(depth, scale, y) : this.fallOffTable[y];
   }

   private double[] computeFallOffTable() {
      double[] column = new double[this.noiseSizeY()];

      for(int y = 0; y < this.noiseSizeY(); ++y) {
         column[y] = Math.cos((double)y * Math.PI * (double)6.0F / (double)this.noiseSizeY()) * (double)2.0F;
         double fallOff = (double)y;
         if (y > this.noiseSizeY() / 2) {
            fallOff = (double)(this.noiseSizeY() - 1 - y);
         }

         if (fallOff < (double)4.0F) {
            fallOff = (double)4.0F - fallOff;
            column[y] -= fallOff * fallOff * fallOff * (double)10.0F;
         }
      }

      return column;
   }

   protected double[] getDepthAndScale(int x, int z) {
      return this.version.isNewerOrEqualTo(MCVersion.v1_16) ? super.getDepthAndScale(x, z) : new double[]{(double)0.0F, (double)0.0F};
   }
}
