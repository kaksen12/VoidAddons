package com.seedfinding.mcterrain.terrain;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.source.BiomeSource;
import com.seedfinding.mccore.block.Block;
import com.seedfinding.mccore.block.Blocks;
import com.seedfinding.mccore.rand.ChunkRand;
import com.seedfinding.mccore.state.Dimension;
import com.seedfinding.mccore.util.block.BlockBox;
import com.seedfinding.mccore.util.data.Pair;
import com.seedfinding.mccore.util.data.Triplet;
import com.seedfinding.mccore.util.pos.BPos;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcnoise.noise.NoiseSampler;
import com.seedfinding.mcnoise.perlin.OctavePerlinNoiseSampler;
import com.seedfinding.mcnoise.perlin.PerlinNoiseSampler;
import com.seedfinding.mcnoise.simplex.OctaveSimplexNoiseSampler;
import com.seedfinding.mcnoise.utils.MathHelper;
import com.seedfinding.mcseed.lcg.LCG;
import com.seedfinding.mcterrain.TerrainGenerator;
import com.seedfinding.mcterrain.utils.NoiseSettings;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.IntStream;

public abstract class SurfaceGenerator extends TerrainGenerator {
   protected static final float[] BIOME_WEIGHT_TABLE = new float[25];
   protected static final float[] BEARD_KERNEL = new float[13824];
   protected final OctavePerlinNoiseSampler depthNoise;
   protected final ChunkRand random;
   private final int chunkHeight;
   private final int chunkWidth;
   private final int noiseSizeX;
   private final int noiseSizeY;
   private final int noiseSizeZ;
   private final NoiseSettings noiseSettings;
   private final OctavePerlinNoiseSampler minLimitPerlinNoise;
   private final OctavePerlinNoiseSampler maxLimitPerlinNoise;
   private final OctavePerlinNoiseSampler mainPerlinNoise;
   private final NoiseSampler surfaceDepthNoise;
   private final OctavePerlinNoiseSampler scaleNoise;
   private final double densityFactor;
   private final double densityOffset;
   private final Map<Long, double[]> noiseColumnCache = new HashMap();
   private final Map<Long, Block[]> columnCache = new HashMap();
   private final Map<Long, Block[]> jigsawColumnCache = new HashMap();
   private final Map<Long, Block[]> biomeColumnCache = new HashMap();
   private final Map<Long, Block[]> biomeJigsawColumnCache = new HashMap();
   private final Map<Long, Long> chunkSeeds = new HashMap();
   private final Map<Long, Long> jigsawChunkSeeds = new HashMap();
   private final int worldHeight;
   private static final LCG SCALE_ADVANCE;
   private static final LCG SURFACE_ADVANCE;

   public SurfaceGenerator(BiomeSource biomeSource, int worldHeight, int horizontalNoiseResolution, int verticalNoiseResolution, NoiseSettings noiseSettings, double densityFactor, double densityOffset, boolean useSimplexNoise) {
      super(biomeSource);
      this.worldHeight = worldHeight;
      this.chunkHeight = verticalNoiseResolution * 4;
      this.chunkWidth = horizontalNoiseResolution * 4;
      this.noiseSettings = noiseSettings;
      this.noiseSizeX = 16 / this.chunkWidth;
      this.noiseSizeY = worldHeight / this.chunkHeight;
      this.noiseSizeZ = 16 / this.chunkWidth;
      this.densityFactor = densityFactor;
      this.densityOffset = densityOffset;
      this.random = new ChunkRand(biomeSource.getWorldSeed());
      if (this.version.isOlderThan(MCVersion.v1_15)) {
         this.minLimitPerlinNoise = new OctavePerlinNoiseSampler(this.random, 16);
         this.maxLimitPerlinNoise = new OctavePerlinNoiseSampler(this.random, 16);
         this.mainPerlinNoise = new OctavePerlinNoiseSampler(this.random, 8);
      } else {
         this.minLimitPerlinNoise = new OctavePerlinNoiseSampler(this.random, IntStream.rangeClosed(-15, 0));
         this.maxLimitPerlinNoise = new OctavePerlinNoiseSampler(this.random, IntStream.rangeClosed(-15, 0));
         this.mainPerlinNoise = new OctavePerlinNoiseSampler(this.random, IntStream.rangeClosed(-7, 0));
      }

      if (this.version.isOlderOrEqualTo(MCVersion.v1_13_2) && this.getDimension() == Dimension.END) {
         this.surfaceDepthNoise = null;
      } else {
         if (this.version.isOlderOrEqualTo(MCVersion.v1_13_2) && this.getDimension() == Dimension.NETHER) {
            this.random.advance(SURFACE_ADVANCE);
         }

         if (this.version.isOlderThan(MCVersion.v1_15)) {
            this.surfaceDepthNoise = (NoiseSampler)(useSimplexNoise ? new OctaveSimplexNoiseSampler(this.random, 4) : new OctavePerlinNoiseSampler(this.random, 4));
         } else {
            this.surfaceDepthNoise = (NoiseSampler)(useSimplexNoise ? new OctaveSimplexNoiseSampler(this.random, IntStream.rangeClosed(-3, 0)) : new OctavePerlinNoiseSampler(this.random, IntStream.rangeClosed(-3, 0)));
         }
      }

      if (this.version.isOlderOrEqualTo(MCVersion.v1_13_2)) {
         this.scaleNoise = new OctavePerlinNoiseSampler(this.random, 10);
      } else {
         this.scaleNoise = null;
         this.random.advance(SCALE_ADVANCE);
      }

      if (this.version.isOlderThan(MCVersion.v1_15)) {
         this.depthNoise = new OctavePerlinNoiseSampler(this.random, 16);
      } else {
         this.depthNoise = new OctavePerlinNoiseSampler(this.random, IntStream.rangeClosed(-15, 0));
      }

   }

   public int getMinWorldHeight() {
      return 0;
   }

   public int getMaxWorldHeight() {
      return this.getWorldHeight() - this.getMinWorldHeight();
   }

   public int getWorldHeight() {
      return this.worldHeight;
   }

   public abstract Block getDefaultBlock();

   public abstract Block getDefaultFluid();

   public abstract int getBedrockRoofPosition();

   public abstract int getBedrockFloorPosition();

   public int noiseSizeY() {
      return this.noiseSizeY + 1;
   }

   public double getMaxNoiseY() {
      return (double)this.noiseSizeY() - (double)4.0F;
   }

   public double getMinNoiseY() {
      return (double)0.0F;
   }

   private double sampleNoise(int x, int y, int z) {
      double xzScale = 684.412 * this.noiseSettings.samplingSettings.xzScale;
      double yScale = 684.412 * this.noiseSettings.samplingSettings.yScale;
      double xzStep = xzScale / this.noiseSettings.samplingSettings.xzFactor;
      double yStep = yScale / this.noiseSettings.samplingSettings.yFactor;
      double minNoise = (double)0.0F;
      double maxNoise = (double)0.0F;
      double mainNoise = (double)0.0F;
      double persistence = (double)1.0F;

      for(int octave = 0; octave < 16; ++octave) {
         double cellX = MathHelper.maintainPrecision((double)x * xzScale * persistence);
         double cellY = MathHelper.maintainPrecision((double)y * yScale * persistence);
         double cellZ = MathHelper.maintainPrecision((double)z * xzScale * persistence);
         double sy = yScale * persistence;
         minNoise += this.minLimitPerlinNoise.getOctave(octave).sample(cellX, cellY, cellZ, sy, (double)y * sy) / persistence;
         maxNoise += this.maxLimitPerlinNoise.getOctave(octave).sample(cellX, cellY, cellZ, sy, (double)y * sy) / persistence;
         if (octave < 8) {
            mainNoise += this.mainPerlinNoise.getOctave(octave).sample(MathHelper.maintainPrecision((double)x * xzStep * persistence), MathHelper.maintainPrecision((double)y * yStep * persistence), MathHelper.maintainPrecision((double)z * xzStep * persistence), yStep * persistence, (double)y * yStep * persistence) / persistence;
         }

         persistence /= (double)2.0F;
      }

      return com.seedfinding.mcterrain.utils.MathHelper.clampedLerp(minNoise / (double)512.0F, maxNoise / (double)512.0F, (mainNoise / (double)10.0F + (double)1.0F) / (double)2.0F);
   }

   private static double[] sampleNoiseOnYLevel(OctavePerlinNoiseSampler sampler, int ySize, int x, int z, double noiseScaleX, double noiseScaleY, double noiseScaleZ) {
      double[] yArray = new double[ySize];
      double persistence = (double)1.0F;

      for(int octave = 0; octave < sampler.getCount(); ++octave) {
         double xScale = noiseScaleX * persistence;
         double yScale = noiseScaleY * persistence;
         double zScale = noiseScaleZ * persistence;
         int cx = x >> 4;
         int cz = z >> 4;
         int fx = x & 15;
         int fz = z & 15;
         double X = (double)(cx << 4) * xScale;
         double Z = (double)(cz << 4) * zScale;
         long intX = MathHelper.lfloor(X);
         long intZ = MathHelper.lfloor(Z);
         X -= (double)intX;
         Z -= (double)intZ;
         intX %= 16777216L;
         intZ %= 16777216L;
         X += (double)intX;
         Z += (double)intZ;
         PerlinNoiseSampler noiseSampler = sampler.getOctave(octave);
         int oldOffset = -1;
         double x1x2 = (double)0.0F;
         double x3x4 = (double)0.0F;
         double x5x6 = (double)0.0F;
         double x7x8 = (double)0.0F;

         for(int currentY = 0; currentY < ySize; ++currentY) {
            double fy = (double)currentY * yScale;
            int currentOffset = (int)(noiseSampler.originY + fy) & 255;
            Triplet<int[], double[], double[]> args = noiseSampler.getArgs(X + (double)fx * xScale, fy, Z + (double)fz * zScale, (double)0.0F, (double)0.0F);
            if (currentY == 0 || currentOffset != oldOffset) {
               oldOffset = currentOffset;
               double[] perms = noiseSampler.samplePermutations(args.getFirst(), args.getSecond());
               double fadeLocalX = ((double[])args.getThird())[0];
               x1x2 = MathHelper.lerp(fadeLocalX, perms[0], perms[1]);
               x3x4 = MathHelper.lerp(fadeLocalX, perms[2], perms[3]);
               x5x6 = MathHelper.lerp(fadeLocalX, perms[4], perms[5]);
               x7x8 = MathHelper.lerp(fadeLocalX, perms[6], perms[7]);
            }

            double fadeLocalY = ((double[])args.getThird())[1];
            double fadeLocalZ = ((double[])args.getThird())[2];
            double noise = MathHelper.lerp2(fadeLocalY, fadeLocalZ, x1x2, x3x4, x5x6, x7x8);
            yArray[currentY] += noise / persistence;
         }

         persistence /= (double)2.0F;
      }

      return yArray;
   }

   protected void sampleNoiseColumnOld(double[] buffer, int x, int z, double depth, double scale) {
      double xzScale = 684.412 * this.noiseSettings.samplingSettings.xzScale;
      double yScale = 684.412 * this.noiseSettings.samplingSettings.yScale;
      double xzStep = xzScale / this.noiseSettings.samplingSettings.xzFactor;
      double yStep = yScale / this.noiseSettings.samplingSettings.yFactor;
      if (this.getDimension() == Dimension.OVERWORLD) {
         xzStep = (double)((float)xzStep);
         yStep = (double)((float)yStep);
      }

      double[] minNoiseYLevels = sampleNoiseOnYLevel(this.minLimitPerlinNoise, this.noiseSizeY(), x, z, xzScale, yScale, xzScale);
      double[] maxNoiseYLevels = sampleNoiseOnYLevel(this.maxLimitPerlinNoise, this.noiseSizeY(), x, z, xzScale, yScale, xzScale);
      double[] mainNoiseYLevels = sampleNoiseOnYLevel(this.mainPerlinNoise, this.noiseSizeY(), x, z, xzStep, yStep, xzStep);
      int sizeY = (int)this.getMaxNoiseY();

      for(int y = 0; y < this.noiseSizeY(); ++y) {
         double fallOff = this.computeNoiseFalloff(depth, scale, y);
         double minNoise = minNoiseYLevels[y] / (double)512.0F;
         double maxNoise = maxNoiseYLevels[y] / (double)512.0F;
         double mainNoise = mainNoiseYLevels[y];
         mainNoise = (mainNoise / (double)10.0F + (double)1.0F) / (double)2.0F;
         double noise = com.seedfinding.mcterrain.utils.MathHelper.clampedLerp(minNoise, maxNoise, mainNoise) - fallOff;
         if (y > sizeY) {
            double offset = (double)((float)(y - sizeY) / (float)this.noiseSettings.topSlideSettings.size);
            if (this.getDimension() == Dimension.END) {
               offset = com.seedfinding.mcterrain.utils.MathHelper.clamp(offset, (double)0.0F, (double)1.0F);
            }

            noise = noise * ((double)1.0F - offset) + (double)this.noiseSettings.topSlideSettings.target * offset;
         }

         if ((double)y < this.getMinNoiseY()) {
            if (this.getDimension() == Dimension.NETHER) {
               double offset = (this.getMinNoiseY() - (double)y) / (double)4.0F;
               offset = com.seedfinding.mcterrain.utils.MathHelper.clamp(offset, (double)0.0F, (double)1.0F);
               noise = noise * ((double)1.0F - offset) - (double)10.0F * offset;
            } else if (this.getDimension() == Dimension.END) {
               double offset = (double)((float)((int)this.getMinNoiseY() - y) / ((float)this.getMinNoiseY() - 1.0F));
               noise = noise * ((double)1.0F - offset) - (double)30.0F * offset;
            }
         }

         buffer[y] = noise;
      }

   }

   protected void sampleNoiseColumn(double[] buffer, int x, int z) {
      double[] ds = this.getDepthAndScale(x, z);
      double depth = ds[0];
      double scale = ds[1];
      if (this.version.isOlderOrEqualTo(MCVersion.v1_13_2)) {
         this.sampleNoiseColumnOld(buffer, x, z, depth, scale);
      } else {
         double sizeY = this.getMaxNoiseY();
         double minY = this.getMinNoiseY();
         double randomOffset = this.biomeSource.getDimension() == Dimension.OVERWORLD ? this.sampleNoise(x, z) : (double)0.0F;

         for(int y = 0; y < this.noiseSizeY(); ++y) {
            double noise = this.sampleNoise(x, y, z);
            if (this.version.isNewerOrEqualTo(MCVersion.v1_16)) {
               double fallOff = (double)1.0F - (double)y * (double)2.0F / (double)this.noiseSizeY + randomOffset;
               fallOff = fallOff * this.densityFactor + this.densityOffset;
               fallOff = (fallOff + depth) * scale;
               noise = fallOff > (double)0.0F ? noise + fallOff * (double)4.0F : noise + fallOff;
               if ((double)this.noiseSettings.topSlideSettings.size > (double)0.0F) {
                  noise = com.seedfinding.mcterrain.utils.MathHelper.clampedLerp((double)this.noiseSettings.topSlideSettings.target, noise, ((double)(this.noiseSizeY - y) - (double)this.noiseSettings.topSlideSettings.offset) / (double)this.noiseSettings.topSlideSettings.size);
               }

               if ((double)this.noiseSettings.bottomSlideSettings.size > (double)0.0F) {
                  noise = com.seedfinding.mcterrain.utils.MathHelper.clampedLerp((double)this.noiseSettings.bottomSlideSettings.target, noise, ((double)y - (double)this.noiseSettings.bottomSlideSettings.offset) / (double)this.noiseSettings.bottomSlideSettings.size);
               }
            } else {
               noise -= this.computeNoiseFalloff(depth, scale, y);
               if ((double)y > sizeY) {
                  noise = com.seedfinding.mcterrain.utils.MathHelper.clampedLerp(noise, (double)this.noiseSettings.topSlideSettings.target, ((double)y - sizeY - (double)this.noiseSettings.topSlideSettings.offset) / (double)this.noiseSettings.topSlideSettings.size);
               } else if ((double)y < minY) {
                  noise = com.seedfinding.mcterrain.utils.MathHelper.clampedLerp(noise, (double)this.noiseSettings.bottomSlideSettings.target, (minY - (double)y) / (minY - (double)1.0F));
               }
            }

            buffer[y] = noise;
         }

      }
   }

   protected double[] sampleNoiseColumn(int x, int z) {
      long key = ((long)x & 4294967295L) << 32 | (long)z & 4294967295L;
      if (this.noiseColumnCache.containsKey(key)) {
         return (double[])this.noiseColumnCache.get(key);
      } else {
         double[] ds = new double[this.noiseSizeY + 1];
         this.sampleNoiseColumn(ds, x, z);
         this.noiseColumnCache.put(key, ds);
         return ds;
      }
   }

   public Block[] getColumnAt(int x, int z) {
      return (Block[])this.columnCache.computeIfAbsent(this.getKey(x, z), (k) -> {
         assert this.getWorldHeight() == this.noiseSizeY * this.chunkHeight;

         Block[] buffer = new Block[this.getWorldHeight()];
         int y = this.generateColumn(buffer, x, z, (Predicate)null, (List)null, (List)null);

         assert y == 0;

         return buffer;
      });
   }

   public Block[] getColumnAt(int x, int z, List<Pair<Supplier<Integer>, BlockBox>> jigsawBoxes, List<BPos> jigsawJunction) {
      return jigsawBoxes != null && jigsawJunction != null ? (Block[])this.jigsawColumnCache.computeIfAbsent(this.getKey(x, z), (k) -> {
         assert this.getWorldHeight() == this.noiseSizeY * this.chunkHeight;

         Block[] buffer = new Block[this.getWorldHeight()];
         int y = this.generateColumn(buffer, x, z, (Predicate)null, jigsawBoxes, jigsawJunction);

         assert y == 0;

         return buffer;
      }) : null;
   }

   public Block[] getBiomeColumnAt(int x, int z) {
      long key = this.getKey(x, z);
      if (this.biomeColumnCache.containsKey(key)) {
         return (Block[])this.biomeColumnCache.get(key);
      } else {
         Block[] blocks = this.generateBiomeColumnBefore(x, z, this::getColumnAt, this.biomeColumnCache, this.chunkSeeds);
         this.biomeColumnCache.put(key, blocks);
         return blocks;
      }
   }

   public Block[] getBiomeColumnAt(int x, int z, List<Pair<Supplier<Integer>, BlockBox>> jigsawBoxes, List<BPos> jigsawJunction) {
      if (jigsawBoxes != null && jigsawJunction != null) {
         long key = this.getKey(x, z);
         if (this.biomeJigsawColumnCache.containsKey(key)) {
            return (Block[])this.biomeJigsawColumnCache.get(key);
         } else {
            Block[] blocks = this.generateBiomeColumnBefore(x, z, (posX, posZ) -> this.getColumnAt(posX, posZ, jigsawBoxes, jigsawJunction), this.biomeJigsawColumnCache, this.jigsawChunkSeeds);
            this.biomeJigsawColumnCache.put(key, blocks);
            return blocks;
         }
      } else {
         return null;
      }
   }

   public Block[] getBedrockColumnAt(int x, int z) {
      this.applyBedrock(x, z, this::getBiomeColumnAt, this.biomeColumnCache, this.chunkSeeds);
      return (Block[])this.biomeColumnCache.get(this.getKey(x, z));
   }

   public Block[] getBedrockColumnAt(int x, int z, List<Pair<Supplier<Integer>, BlockBox>> jigsawBoxes, List<BPos> jigsawJunction) {
      this.applyBedrock(x, z, this::getBiomeColumnAt, this.jigsawColumnCache, this.jigsawChunkSeeds);
      return (Block[])this.jigsawColumnCache.get(this.getKey(x, z));
   }

   public void applyBedrock(int x, int z, BiFunction<Integer, Integer, Block[]> columnProvider, Map<Long, Block[]> cacheProvider, Map<Long, Long> seedProvider) {
      int chunkX = x >> 4;
      int chunkZ = z >> 4;
      int maxChunkX = (chunkX << 4) + 15;
      int maxChunkZ = (chunkZ << 4) + 15;
      this.getBiomeColumnAt(maxChunkX, maxChunkZ);
      Long seed = (Long)seedProvider.get(this.getKey(maxChunkX, maxChunkZ));
      if (seed != null) {
         ChunkRand rand = new ChunkRand(seed, false);
         int maxFloorBedrock = this.getBedrockFloorPosition();
         int maxRoofBedrock = this.worldHeight - 1 - this.getBedrockRoofPosition();
         boolean roofOk = maxRoofBedrock + 4 >= 0 && maxRoofBedrock < this.worldHeight;
         boolean floorOk = maxFloorBedrock + 4 >= 0 && maxFloorBedrock < this.worldHeight;
         if (roofOk || floorOk) {
            for(int X = 0; X < 16; ++X) {
               for(int Z = 0; Z < 16; ++Z) {
                  Block[] buffer = (Block[])columnProvider.apply(chunkX + X, chunkZ + Z);
                  if (roofOk) {
                     for(int y = 0; y < 5; ++y) {
                        if (y <= rand.nextInt(5)) {
                           buffer[maxRoofBedrock - y] = Blocks.BEDROCK;
                        }
                     }
                  }

                  if (floorOk) {
                     for(int y = 4; y >= 0; --y) {
                        if (y <= rand.nextInt(5)) {
                           buffer[maxFloorBedrock + y] = Blocks.BEDROCK;
                        }
                     }
                  }

                  cacheProvider.put(this.getKey(chunkX + X, chunkZ + Z), buffer);
               }
            }
         }

      }
   }

   private long getKey(int x, int z) {
      return ((long)x & 4294967295L) << 32 | (long)z & 4294967295L;
   }

   public Optional<Block> getBlockAt(int x, int y, int z) {
      return y >= this.getMinWorldHeight() && y <= this.getMaxWorldHeight() - 1 ? Optional.of(this.getColumnAt(x, z)[y]) : Optional.empty();
   }

   private void replaceBiomeBlocks(Block[] buffer, int x, int z, ChunkRand rand) {
      int y = (int)com.seedfinding.mcterrain.utils.MathHelper.clamp((double)this.getHeightOnGround(x, z), (double)this.getMinWorldHeight(), (double)(this.getMaxWorldHeight() - 1));
      double noise = this.surfaceDepthNoise.sample((double)x * (double)0.0625F, (double)z * (double)0.0625F, (double)0.0625F, (double)(x & 15) * (double)0.0625F) * (double)15.0F;
      Biome biome = this.biomeSource.getBiome(x, y, z);
      biome.getSurfaceBuilder().applyToColumn(this.getBiomeSource(), rand, buffer, biome, x, z, y, 0, noise, this.getSeaLevel(), this.getDefaultBlock(), this.getDefaultFluid());
   }

   public Block[] generateBiomeColumnBefore(int x, int z, BiFunction<Integer, Integer, Block[]> columnProvider, Map<Long, Block[]> cacheProvider, Map<Long, Long> seedProvider) {
      int chunkX = x >> 4;
      int chunkZ = z >> 4;
      ChunkRand rand = new ChunkRand();
      rand.setTerrainSeed(chunkX, chunkZ, this.getVersion());
      int minChunkX = chunkX << 4;
      int minChunkZ = chunkZ << 4;

      for(int X = 0; X < 16; ++X) {
         for(int Z = 0; Z < 16; ++Z) {
            int posX = minChunkX + X;
            int posZ = minChunkZ + Z;
            long key = this.getKey(posX, posZ);
            Long seed = (Long)seedProvider.get(key);
            if (seed == null) {
               assert !cacheProvider.containsKey(key);

               Block[] buffer = (Block[])columnProvider.apply(x, z);
               this.replaceBiomeBlocks(buffer, x, z, rand);
               cacheProvider.put(key, buffer);
               seedProvider.put(key, rand.getSeed());
            } else {
               rand.setSeed(seed, false);
            }

            if (posX == x && posZ == z) {
               return (Block[])cacheProvider.get(key);
            }
         }
      }

      return (Block[])cacheProvider.get(this.getKey(x, z));
   }

   public double applyJigsawToNoise(double noise, BPos bPos, List<Pair<Supplier<Integer>, BlockBox>> jigsawBoxes, List<BPos> jigsawJunction) {
      noise = com.seedfinding.mcterrain.utils.MathHelper.clamp(noise / (double)200.0F, (double)-1.0F, (double)1.0F);
      noise = noise / (double)2.0F - noise * noise * noise / (double)24.0F;

      for(Pair<Supplier<Integer>, BlockBox> jigsawBox : jigsawBoxes) {
         BlockBox box = jigsawBox.getSecond();
         int localX = Math.max(0, Math.max(box.minX - bPos.getX(), bPos.getX() - box.maxX));
         int localY = bPos.getY() - (box.minY + (jigsawBox.getFirst() != null ? (Integer)((Supplier)jigsawBox.getFirst()).get() : 0));
         int localZ = Math.max(0, Math.max(box.minZ - bPos.getZ(), bPos.getZ() - box.maxZ));
         noise += getContribution(localX, localY, localZ) * 0.8;
      }

      for(BPos junction : jigsawJunction) {
         int localX = bPos.getX() - junction.getX();
         int localY = bPos.getY() - junction.getY();
         int localZ = bPos.getZ() - junction.getZ();
         noise += getContribution(localX, localY, localZ) * 0.4;
      }

      return noise;
   }

   public int generateColumn(Block[] buffer, int x, int z, Predicate<Block> blockPredicate, List<Pair<Supplier<Integer>, BlockBox>> jigsawBoxes, List<BPos> jigsawJunction) {
      int cellX = Math.floorDiv(x, this.chunkWidth);
      int cellZ = Math.floorDiv(z, this.chunkWidth);
      int posX = Math.floorMod(x, this.chunkWidth);
      int posZ = Math.floorMod(z, this.chunkWidth);
      double percentX = (double)posX / (double)this.chunkWidth;
      double percentZ = (double)posZ / (double)this.chunkWidth;
      double[][] ds = new double[][]{this.sampleNoiseColumn(cellX, cellZ), this.sampleNoiseColumn(cellX, cellZ + 1), this.sampleNoiseColumn(cellX + 1, cellZ), this.sampleNoiseColumn(cellX + 1, cellZ + 1)};

      for(int cellY = this.noiseSizeY - 1; cellY >= 0; --cellY) {
         double xyz = ds[0][cellY];
         double xyz1 = ds[1][cellY];
         double x1yz = ds[2][cellY];
         double x1yz1 = ds[3][cellY];
         double xy1z = ds[0][cellY + 1];
         double xy1z1 = ds[1][cellY + 1];
         double x1y1z = ds[2][cellY + 1];
         double x1y1z1 = ds[3][cellY + 1];

         for(int posY = this.chunkHeight - 1; posY >= 0; --posY) {
            double percentY = (double)posY / (double)this.chunkHeight;
            double noise = MathHelper.lerp3(percentY, percentX, percentZ, xyz, xy1z, x1yz, x1y1z, xyz1, xy1z1, x1yz1, x1y1z1);
            int y = cellY * this.chunkHeight + posY;
            if (jigsawBoxes != null && jigsawJunction != null) {
               noise = this.applyJigsawToNoise(noise, new BPos(x, y, z), jigsawBoxes, jigsawJunction);
            }

            Block block = this.getBlockFromNoise(noise, y);
            if (buffer != null) {
               buffer[y] = block;
            }

            if (blockPredicate != null && blockPredicate.test(block)) {
               return y + 1;
            }
         }
      }

      return 0;
   }

   public int getHeightOnGround(int x, int z) {
      return this.generateColumn((Block[])null, x, z, (block) -> block == this.getDefaultBlock(), (List)null, (List)null);
   }

   public int getFirstHeightInColumn(int x, int z, Predicate<Block> predicate) {
      return this.generateColumn((Block[])null, x, z, predicate, (List)null, (List)null);
   }

   protected double[] getDepthAndScale(int x, int z) {
      double[] depthAndScale = new double[2];
      int sampleRange = 2;
      float weightedScale = 0.0F;
      float weightedDepth = 0.0F;
      float totalWeight = 0.0F;
      Biome biome = this.biomeSource.getBiomeForNoiseGen(x, this.getSeaLevel(), z);
      float depthAtCenter = biome.getDepth();

      for(int rx = -sampleRange; rx <= sampleRange; ++rx) {
         for(int rz = -sampleRange; rz <= sampleRange; ++rz) {
            biome = this.biomeSource.getBiomeForNoiseGen(x + rx, this.getSeaLevel(), z + rz);
            float depth = biome.getDepth();
            float scale = biome.getScale();
            if (this.amplified && depth > 0.0F) {
               depth = 1.0F + depth * 2.0F;
               scale = 1.0F + scale * 4.0F;
            }

            float weight = BIOME_WEIGHT_TABLE[rx + 2 + (rz + 2) * 5] / (depth + 2.0F);
            if (biome.getDepth() > depthAtCenter) {
               weight /= 2.0F;
            }

            weightedScale += scale * weight;
            weightedDepth += depth * weight;
            totalWeight += weight;
         }
      }

      weightedScale /= totalWeight;
      weightedDepth /= totalWeight;
      weightedScale = weightedScale * 0.9F + 0.1F;
      weightedDepth = (weightedDepth * 4.0F - 1.0F) / 8.0F;
      if (this.biomeSource.getVersion().isNewerOrEqualTo(MCVersion.v1_16)) {
         depthAndScale[0] = (double)weightedDepth * (double)17.0F / (double)64.0F;
         depthAndScale[1] = (double)96.0F / (double)weightedScale;
      } else {
         double noise = this.sampleNoise(x, z);
         depthAndScale[0] = (double)weightedDepth + noise;
         if (this.version.isOlderOrEqualTo(MCVersion.v1_13_2)) {
            depthAndScale[0] = (double)weightedDepth + noise * 0.2;
         }

         depthAndScale[1] = (double)weightedScale;
      }

      return depthAndScale;
   }

   private double sampleNoise(int x, int z) {
      double noise = this.depthNoise.sample((double)(x * 200), (double)10.0F, (double)(z * 200), (double)1.0F, (double)0.0F, true);
      if (this.version.isOlderThan(MCVersion.v1_16)) {
         if (this.version.isNewerOrEqualTo(MCVersion.v1_15)) {
            noise *= (double)65535.0F;
         }

         noise /= (double)8000.0F;
      }

      noise = noise < (double)0.0F ? -noise * 0.3 : noise;
      if (this.version.isNewerOrEqualTo(MCVersion.v1_16)) {
         noise = noise * (double)3.0F * (double)65535.0F / (double)8000.0F - (double)2.0F;
         return noise < (double)0.0F ? (double)17.0F * noise / (double)28.0F / (double)64.0F : Math.min(noise, (double)1.0F) * (double)17.0F / (double)40.0F / (double)64.0F;
      } else {
         noise = noise * (double)3.0F - (double)2.0F;
         if (this.version.isOlderOrEqualTo(MCVersion.v1_13_2)) {
            if (noise < (double)0.0F) {
               noise /= (double)2.0F;
               if (noise < (double)-1.0F) {
                  noise = (double)-1.0F;
               }

               noise /= 1.4;
               noise /= (double)2.0F;
            } else {
               if (noise > (double)1.0F) {
                  noise = (double)1.0F;
               }

               noise /= (double)8.0F;
            }

            return noise;
         } else {
            return noise < (double)0.0F ? noise / (double)28.0F : Math.min(noise, (double)1.0F) / (double)40.0F;
         }
      }
   }

   protected double computeNoiseFalloff(double depth, double scale, int y) {
      double fallOff = ((double)y - ((double)8.5F + depth * (double)8.5F / (double)8.0F * (double)4.0F)) * (double)12.0F * (double)128.0F / (double)256.0F / scale;
      if (fallOff < (double)0.0F) {
         fallOff *= (double)4.0F;
      }

      return fallOff;
   }

   public Block getBlockFromNoise(double noise, int y) {
      Block block;
      if (noise > (double)0.0F) {
         block = this.getDefaultBlock();
      } else if (y < this.getSeaLevel()) {
         block = this.getDefaultFluid();
      } else {
         block = Blocks.AIR;
      }

      return block;
   }

   private static double getContribution(int x, int y, int z) {
      int offX = x + 12;
      int offY = y + 12;
      int offZ = z + 12;
      if (offX >= 0 && offX < 24) {
         if (offY >= 0 && offY < 24) {
            return offZ >= 0 && offZ < 24 ? (double)BEARD_KERNEL[offZ * 24 * 24 + offX * 24 + offY] : (double)0.0F;
         } else {
            return (double)0.0F;
         }
      } else {
         return (double)0.0F;
      }
   }

   private static double computeContribution(int x, int y, int z) {
      double d0 = (double)(x * x + z * z);
      double d1 = (double)y + (double)0.5F;
      double d2 = d1 * d1;
      double d3 = Math.pow(Math.E, -(d2 / (double)16.0F + d0 / (double)16.0F));
      double d4 = -d1 * com.seedfinding.mcterrain.utils.MathHelper.fastInvSqrt(d2 / (double)2.0F + d0 / (double)2.0F) / (double)2.0F;
      return d4 * d3;
   }

   static {
      for(int rx = -2; rx <= 2; ++rx) {
         for(int rz = -2; rz <= 2; ++rz) {
            float f = 10.0F / com.seedfinding.mcterrain.utils.MathHelper.sqrt((float)(rx * rx + rz * rz) + 0.2F);
            BIOME_WEIGHT_TABLE[rx + 2 + (rz + 2) * 5] = f;
         }
      }

      for(int i = 0; i < 24; ++i) {
         for(int j = 0; j < 24; ++j) {
            for(int k = 0; k < 24; ++k) {
               BEARD_KERNEL[i * 24 * 24 + j * 24 + k] = (float)computeContribution(j - 12, k - 12, i - 12);
            }
         }
      }

      SCALE_ADVANCE = LCG.JAVA.combine(2620L);
      SURFACE_ADVANCE = LCG.JAVA.combine(1048L);
   }
}
