package com.seedfinding.mcterrain.terrain;

import com.seedfinding.mcbiome.source.BiomeSource;
import com.seedfinding.mcbiome.source.EndBiomeSource;
import com.seedfinding.mccore.block.Block;
import com.seedfinding.mccore.block.Blocks;
import com.seedfinding.mccore.state.Dimension;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcterrain.utils.NoiseSettings;

public class EndTerrainGenerator extends SurfaceGenerator {
   public EndTerrainGenerator(BiomeSource biomeSource) {
      super(biomeSource, 128, 2, 1, biomeSource.getVersion().isNewerOrEqualTo(MCVersion.v1_16) ? NoiseSettings.create((double)2.0F, (double)1.0F, (double)80.0F, (double)160.0F).addTopSlide(-3000, 64, -46).addBottomSlide(-30, 7, 1) : NoiseSettings.create((double)2.0F, (double)1.0F, (double)80.0F, (double)160.0F).addTopSlide(-3000, 64, 0).addBottomSlide(-30, 1, 0), (double)0.0F, (double)0.0F, true);
   }

   public Block getDefaultBlock() {
      return Blocks.END_STONE;
   }

   public Block getDefaultFluid() {
      return Blocks.AIR;
   }

   public int getBedrockRoofPosition() {
      return -10;
   }

   public int getBedrockFloorPosition() {
      return -10;
   }

   public Dimension getDimension() {
      return Dimension.END;
   }

   protected double[] getDepthAndScale(int x, int z) {
      double height = (double)((EndBiomeSource)this.biomeSource).height.getNoiseValueAt(x, z);
      if (this.getVersion().isNewerOrEqualTo(MCVersion.v1_16)) {
         double[] depthAndScale = new double[2];
         depthAndScale[0] = height - (double)8.0F;
         depthAndScale[1] = depthAndScale[0] > (double)0.0F ? (double)0.25F : (double)1.0F;
         return depthAndScale;
      } else {
         return new double[]{height, (double)0.0F};
      }
   }

   protected double computeNoiseFalloff(double depth, double scale, int y) {
      return this.getVersion().isNewerOrEqualTo(MCVersion.v1_16) ? super.computeNoiseFalloff(depth, scale, y) : this.getMinNoiseY() - depth;
   }

   public double getMaxNoiseY() {
      return this.getVersion().isNewerOrEqualTo(MCVersion.v1_16) ? super.getMaxNoiseY() : (double)((int)super.getMaxNoiseY() / 2);
   }

   public double getMinNoiseY() {
      return this.getVersion().isNewerOrEqualTo(MCVersion.v1_16) ? super.getMinNoiseY() : (double)8.0F;
   }

   public int getSeaLevel() {
      return 0;
   }
}
