package com.seedfinding.mcterrain.terrain;

import com.seedfinding.mcbiome.source.BiomeSource;
import com.seedfinding.mccore.block.Block;
import com.seedfinding.mccore.block.Blocks;
import com.seedfinding.mccore.state.Dimension;
import com.seedfinding.mcterrain.utils.NoiseSettings;

public class OverworldTerrainGenerator extends SurfaceGenerator {
   public OverworldTerrainGenerator(BiomeSource biomeSource) {
      super(biomeSource, 256, 1, 2, NoiseSettings.create(0.9999999814507745, 0.9999999814507745, (double)80.0F, (double)160.0F).addTopSlide(-10, 3, 0).addBottomSlide(-30, 0, 0), (double)1.0F, (double)-0.46875F, true);
   }

   public Dimension getDimension() {
      return Dimension.OVERWORLD;
   }

   public Block getDefaultBlock() {
      return Blocks.STONE;
   }

   public Block getDefaultFluid() {
      return Blocks.WATER;
   }

   public int getBedrockRoofPosition() {
      return -10;
   }

   public int getBedrockFloorPosition() {
      return 0;
   }
}
