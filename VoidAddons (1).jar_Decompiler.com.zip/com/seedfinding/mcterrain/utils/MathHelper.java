package com.seedfinding.mcterrain.utils;

public class MathHelper {
   public static double clampedLerp(double first, double second, double delta) {
      if (delta < (double)0.0F) {
         return first;
      } else {
         return delta > (double)1.0F ? second : com.seedfinding.mcnoise.utils.MathHelper.lerp(delta, first, second);
      }
   }

   public static float sqrt(float f) {
      return (float)Math.sqrt((double)f);
   }

   public static double clamp(double value, double min, double max) {
      return value < min ? min : Math.min(value, max);
   }

   public static double fastInvSqrt(double d) {
      double half = (double)0.5F * d;
      long bits = Double.doubleToRawLongBits(d);
      bits = 6910469410427058090L - (bits >> 1);
      d = Double.longBitsToDouble(bits);
      return d * ((double)1.5F - half * d * d);
   }
}
