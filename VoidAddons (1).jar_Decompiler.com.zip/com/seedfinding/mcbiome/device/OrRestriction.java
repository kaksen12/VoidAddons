package com.seedfinding.mcbiome.device;

import com.seedfinding.mcbiome.source.LayeredBiomeSource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class OrRestriction extends Restriction {
   private final Restriction[] restrictions;

   protected OrRestriction(int x, int z, Restriction... restrictions) {
      super("OR", x, z);
      this.restrictions = restrictions;
   }

   public static Restriction.Factory<OrRestriction> of(Restriction.Factory<?>... restrictions) {
      return (version, x, z) -> new OrRestriction(x, z, (Restriction[])Arrays.stream(restrictions).map((f) -> f.create(version, x, z)).toArray((x$0) -> new Restriction[x$0]));
   }

   public List<Integer> getBitPoints() {
      Set<Integer> points = new HashSet();

      for(Restriction restriction : this.restrictions) {
         points.addAll(restriction.getBitPoints());
      }

      return new ArrayList(points);
   }

   public boolean testSeed(long seed, long bits) {
      for(Restriction restriction : this.restrictions) {
         if (restriction.testSeed(seed, bits)) {
            return true;
         }
      }

      return false;
   }

   public boolean testSource(LayeredBiomeSource source) {
      for(Restriction restriction : this.restrictions) {
         if (restriction.testSource(source)) {
            return true;
         }
      }

      return false;
   }
}
