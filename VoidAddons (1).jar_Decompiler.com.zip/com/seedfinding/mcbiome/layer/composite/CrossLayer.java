package com.seedfinding.mcbiome.layer.composite;

import com.seedfinding.mcbiome.layer.IntBiomeLayer;
import com.seedfinding.mccore.version.MCVersion;

public abstract class CrossLayer extends IntBiomeLayer {
   public CrossLayer(MCVersion version, long worldSeed, long salt, IntBiomeLayer parent) {
      super(version, worldSeed, salt, parent);
   }

   public int sample(int x, int y, int z) {
      this.setSeed(x, z);
      return this.sample(((IntBiomeLayer)this.getParent(IntBiomeLayer.class)).get(x, y, z - 1), ((IntBiomeLayer)this.getParent(IntBiomeLayer.class)).get(x + 1, y, z), ((IntBiomeLayer)this.getParent(IntBiomeLayer.class)).get(x, y, z + 1), ((IntBiomeLayer)this.getParent(IntBiomeLayer.class)).get(x - 1, y, z), ((IntBiomeLayer)this.getParent(IntBiomeLayer.class)).get(x, y, z));
   }

   public abstract int sample(int var1, int var2, int var3, int var4, int var5);
}
