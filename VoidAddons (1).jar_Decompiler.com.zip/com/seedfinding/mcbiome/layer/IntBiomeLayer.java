package com.seedfinding.mcbiome.layer;

import com.seedfinding.mcbiome.layer.cache.IntLayerCache;
import com.seedfinding.mcbiome.layer.composite.VoronoiLayer;
import com.seedfinding.mcbiome.layer.scale.ScaleLayer;
import com.seedfinding.mccore.version.MCVersion;

public abstract class IntBiomeLayer extends BiomeLayer {
   private final IntLayerCache layerCache = new IntLayerCache(1024);

   public IntBiomeLayer(MCVersion version, BiomeLayer... parents) {
      super(version, parents);
   }

   public IntBiomeLayer(MCVersion version) {
      super(version);
   }

   public IntBiomeLayer(MCVersion version, long worldSeed, long salt, BiomeLayer... parents) {
      super(version, worldSeed, salt, parents);
   }

   public IntBiomeLayer(MCVersion version, long worldSeed, long salt) {
      super(version, worldSeed, salt);
   }

   public int get(int x, int y, int z) {
      return this.layerCache.get(x, y, z, this::sample);
   }

   public abstract int sample(int var1, int var2, int var3);

   public void _sample(int x, int z, int xSize, int zSize) throws UnsupportedOperationException {
      if (this.getParents() == null) {
         throw new UnsupportedOperationException("Error, in our model, this should not happen (we use a null parent array)");
      } else {
         BiomeLayer[] var5 = this.getParents();
         int var6 = var5.length;
         byte var7 = 0;
         if (var7 < var6) {
            BiomeLayer biomeLayer = var5[var7];
            int shift = 0;
            if (this instanceof ScaleLayer) {
               shift = 1;
            } else if (this instanceof VoronoiLayer) {
               shift = 2;
            }

            if (biomeLayer == null) {
               for(int offX = 0; offX < xSize; ++offX) {
                  for(int offZ = 0; offZ < zSize; ++offZ) {
                     this.layerCache.forceStoreAndGet(x + offX, 0, z + offZ, this::sample);
                  }
               }

            } else {
               ((IntBiomeLayer)biomeLayer)._sample((x >> shift) - 1, (z >> shift) - 1, xSize + 2, zSize + 2);

               for(int offX = 0; offX < xSize; ++offX) {
                  for(int offZ = 0; offZ < zSize; ++offZ) {
                     this.layerCache.get(x + offX, 0, z + offZ, this::sample);
                  }
               }

            }
         }
      }
   }

   public int[] sample(int x, int y, int z, int xSize, int ySize, int zSize) {
      try {
         this._sample(x, z, xSize, zSize);
      } catch (UnsupportedOperationException e) {
         e.printStackTrace();
      }

      int[] ids = new int[xSize * zSize];

      for(int offX = 0; offX < xSize; ++offX) {
         for(int offZ = 0; offZ < zSize; ++offZ) {
            ids[offX * zSize + offZ] = this.layerCache.get(x + offX, 0, z + offZ, this::sample);
         }
      }

      return ids;
   }
}
