package com.seedfinding.mcbiome.biome.surface.builder;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.surface.SurfaceConfig;
import com.seedfinding.mcbiome.source.BiomeSource;
import com.seedfinding.mccore.block.Block;
import com.seedfinding.mccore.rand.ChunkRand;
import com.seedfinding.mccore.util.data.Quad;
import com.seedfinding.mcnoise.simplex.OctaveSimplexNoiseSampler;

public class ErodedBadlandsSurfaceBuilder extends BadlandsSurfaceBuilder {
   private double yPikes = (double)0.0F;

   public ErodedBadlandsSurfaceBuilder(SurfaceConfig surfaceConfig) {
      super(surfaceConfig);
   }

   public Block[] applyToColumn(BiomeSource source, ChunkRand rand, Block[] column, Biome biome, int x, int z, int maxY, int minY, double noise, int seaLevel, Block defaultBlock, Block defaultFluid) {
      Quad<Block[], OctaveSimplexNoiseSampler, OctaveSimplexNoiseSampler, OctaveSimplexNoiseSampler> badlandsSurface = source.getStaticNoiseSource().getBadlandsSurface();
      double yElevation = Math.min(Math.abs(noise), ((OctaveSimplexNoiseSampler)badlandsSurface.getSecond()).sample((double)x * (double)0.25F, (double)z * (double)0.25F, false) * (double)15.0F);
      if (yElevation > (double)0.0F) {
         double d3 = Math.abs(((OctaveSimplexNoiseSampler)badlandsSurface.getThird()).sample((double)x * (double)0.001953125F, (double)z * (double)0.001953125F, false));
         this.yPikes = yElevation * yElevation * (double)2.5F;
         double d4 = Math.ceil(d3 * (double)50.0F) + (double)14.0F;
         if (this.yPikes > d4) {
            this.yPikes = d4;
         }

         this.yPikes += (double)64.0F;
      }

      return super.applyToColumn(source, rand, column, biome, x, z, Math.max(maxY, (int)this.yPikes + 1), minY, noise, seaLevel, defaultBlock, defaultFluid);
   }

   protected Block getBaseBlock(int y, Block[] column, BiomeSource source, Block defaultBlock) {
      Block block = column[y];
      if (Block.IS_AIR.test(source.getVersion(), block) && y < (int)this.yPikes) {
         block = defaultBlock;
      }

      return block;
   }

   protected boolean shouldBypass() {
      return true;
   }
}
