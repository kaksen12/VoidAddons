package com.seedfinding.mcbiome.biome.surface.builder;

import com.seedfinding.mcbiome.biome.Biome;
import com.seedfinding.mcbiome.biome.surface.SurfaceConfig;
import com.seedfinding.mcbiome.source.BiomeSource;
import com.seedfinding.mccore.block.Block;
import com.seedfinding.mccore.rand.ChunkRand;

public class GravellyMountainSurfaceBuilder extends DefaultSurfaceBuilder {
   public GravellyMountainSurfaceBuilder(SurfaceConfig surfaceConfig) {
      super(surfaceConfig);
   }

   public Block[] applyToColumn(BiomeSource source, ChunkRand rand, Block[] column, Biome biome, int x, int z, int maxY, int minY, double noise, int seaLevel, Block defaultBlock, Block defaultFluid) {
      if (!(noise < (double)-1.0F) && !(noise > (double)2.0F)) {
         if (noise > (double)1.0F) {
            this.setSurfaceConfig(SurfaceConfig.CONFIG_STONE);
         } else {
            this.setSurfaceConfig(SurfaceConfig.CONFIG_GRASS);
         }
      } else {
         this.setSurfaceConfig(SurfaceConfig.CONFIG_GRAVEL);
      }

      return super.applyToColumn(source, rand, column, biome, x, z, maxY, minY, noise, seaLevel, defaultBlock, defaultFluid);
   }
}
