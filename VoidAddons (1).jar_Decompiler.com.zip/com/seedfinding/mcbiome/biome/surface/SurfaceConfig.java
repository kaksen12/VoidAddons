package com.seedfinding.mcbiome.biome.surface;

import com.seedfinding.mccore.block.Block;
import com.seedfinding.mccore.block.Blocks;

public class SurfaceConfig {
   public static final SurfaceConfig CONFIG_PODZOL;
   public static final SurfaceConfig CONFIG_GRAVEL;
   public static final SurfaceConfig CONFIG_GRASS;
   public static final SurfaceConfig CONFIG_STONE;
   public static final SurfaceConfig CONFIG_COARSE_DIRT;
   public static final SurfaceConfig CONFIG_DESERT;
   public static final SurfaceConfig CONFIG_OCEAN_SAND;
   public static final SurfaceConfig CONFIG_FULL_SAND;
   public static final SurfaceConfig CONFIG_BADLANDS;
   public static final SurfaceConfig CONFIG_MYCELIUM;
   public static final SurfaceConfig CONFIG_HELL;
   public static final SurfaceConfig CONFIG_SOUL_SAND_VALLEY;
   public static final SurfaceConfig CONFIG_THE_END;
   public static final SurfaceConfig CONFIG_CRIMSON_FOREST;
   public static final SurfaceConfig CONFIG_WARPED_FOREST;
   public static final SurfaceConfig CONFIG_BASALT_DELTAS;
   public static final SurfaceConfig CONFIG_ICE_SPIKES;
   private final Block topBlock;
   private final Block underBlock;
   private final Block underwaterBlock;

   public SurfaceConfig(Block topBlock, Block underBlock, Block underwaterBlock) {
      this.topBlock = topBlock;
      this.underBlock = underBlock;
      this.underwaterBlock = underwaterBlock;
   }

   public Block getTopBlock() {
      return this.topBlock;
   }

   public Block getUnderBlock() {
      return this.underBlock;
   }

   public Block getUnderwaterBlock() {
      return this.underwaterBlock;
   }

   public String toString() {
      return "SurfaceConfig{topBlock=" + this.topBlock + ", underBlock=" + this.underBlock + ", underwaterBlock=" + this.underwaterBlock + '}';
   }

   static {
      CONFIG_PODZOL = new SurfaceConfig(Blocks.PODZOL, Blocks.DIRT, Blocks.GRAVEL);
      CONFIG_GRAVEL = new SurfaceConfig(Blocks.GRAVEL, Blocks.GRAVEL, Blocks.GRAVEL);
      CONFIG_GRASS = new SurfaceConfig(Blocks.GRASS_BLOCK, Blocks.DIRT, Blocks.GRAVEL);
      CONFIG_STONE = new SurfaceConfig(Blocks.STONE, Blocks.STONE, Blocks.GRAVEL);
      CONFIG_COARSE_DIRT = new SurfaceConfig(Blocks.COARSE_DIRT, Blocks.DIRT, Blocks.GRAVEL);
      CONFIG_DESERT = new SurfaceConfig(Blocks.SAND, Blocks.SAND, Blocks.GRAVEL);
      CONFIG_OCEAN_SAND = new SurfaceConfig(Blocks.GRASS_BLOCK, Blocks.DIRT, Blocks.SAND);
      CONFIG_FULL_SAND = new SurfaceConfig(Blocks.SAND, Blocks.SAND, Blocks.SAND);
      CONFIG_BADLANDS = new SurfaceConfig(Blocks.RED_SAND, Blocks.WHITE_TERRACOTTA, Blocks.GRAVEL);
      CONFIG_MYCELIUM = new SurfaceConfig(Blocks.MYCELIUM, Blocks.DIRT, Blocks.GRAVEL);
      CONFIG_HELL = new SurfaceConfig(Blocks.NETHERRACK, Blocks.NETHERRACK, Blocks.NETHERRACK);
      CONFIG_SOUL_SAND_VALLEY = new SurfaceConfig(Blocks.SOUL_SAND, Blocks.SOUL_SAND, Blocks.SOUL_SAND);
      CONFIG_THE_END = new SurfaceConfig(Blocks.END_STONE, Blocks.END_STONE, Blocks.END_STONE);
      CONFIG_CRIMSON_FOREST = new SurfaceConfig(Blocks.CRIMSON_NYLIUM, Blocks.NETHERRACK, Blocks.NETHER_WART_BLOCK);
      CONFIG_WARPED_FOREST = new SurfaceConfig(Blocks.WARPED_NYLIUM, Blocks.NETHERRACK, Blocks.WARPED_WART_BLOCK);
      CONFIG_BASALT_DELTAS = new SurfaceConfig(Blocks.BLACKSTONE, Blocks.BASALT, Blocks.MAGMA_BLOCK);
      CONFIG_ICE_SPIKES = new SurfaceConfig(Blocks.SNOW_BLOCK, Blocks.DIRT, Blocks.GRAVEL);
   }
}
