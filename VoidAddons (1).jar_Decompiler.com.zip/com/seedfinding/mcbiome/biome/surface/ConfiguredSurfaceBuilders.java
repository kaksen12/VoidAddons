package com.seedfinding.mcbiome.biome.surface;

import com.seedfinding.mcbiome.biome.surface.builder.SurfaceBuilder;
import java.util.HashMap;

public class ConfiguredSurfaceBuilders {
   public static final HashMap<String, SurfaceBuilder> CONFIGURED_SURFACE_BUILDERS = new HashMap();
   public static final SurfaceBuilder BADLANDS;
   public static final SurfaceBuilder BASALT_DELTAS;
   public static final SurfaceBuilder CRIMSON_FOREST;
   public static final SurfaceBuilder DESERT;
   public static final SurfaceBuilder END;
   public static final SurfaceBuilder ERODED_BADLANDS;
   public static final SurfaceBuilder FROZEN_OCEAN;
   public static final SurfaceBuilder FULL_SAND;
   public static final SurfaceBuilder GIANT_TREE_TAIGA;
   public static final SurfaceBuilder GRASS;
   public static final SurfaceBuilder GRAVELLY_MOUNTAIN;
   public static final SurfaceBuilder ICE_SPIKES;
   public static final SurfaceBuilder MOUNTAIN;
   public static final SurfaceBuilder MYCELIUM;
   public static final SurfaceBuilder NETHER;
   public static final SurfaceBuilder NOPE;
   public static final SurfaceBuilder OCEAN_SAND;
   public static final SurfaceBuilder SHATTERED_SAVANNA;
   public static final SurfaceBuilder SOUL_SAND_VALLEY;
   public static final SurfaceBuilder STONE;
   public static final SurfaceBuilder SWAMP;
   public static final SurfaceBuilder WARPED_FOREST;
   public static final SurfaceBuilder WOODED_BADLANDS;

   public static SurfaceBuilder register(String name, SurfaceBuilder surfaceBuilder) {
      CONFIGURED_SURFACE_BUILDERS.put(name, surfaceBuilder);
      return surfaceBuilder;
   }

   static {
      BADLANDS = register("badlands", (SurfaceBuilder)SurfaceBuilders.BADLANDS.apply(SurfaceConfig.CONFIG_BADLANDS));
      BASALT_DELTAS = register("basalt_deltas", (SurfaceBuilder)SurfaceBuilders.BASALT_DELTAS.apply(SurfaceConfig.CONFIG_BASALT_DELTAS));
      CRIMSON_FOREST = register("crimson_forest", (SurfaceBuilder)SurfaceBuilders.NETHER_FOREST.apply(SurfaceConfig.CONFIG_CRIMSON_FOREST));
      DESERT = register("desert", (SurfaceBuilder)SurfaceBuilders.DEFAULT.apply(SurfaceConfig.CONFIG_DESERT));
      END = register("end", (SurfaceBuilder)SurfaceBuilders.DEFAULT.apply(SurfaceConfig.CONFIG_THE_END));
      ERODED_BADLANDS = register("eroded_badlands", (SurfaceBuilder)SurfaceBuilders.ERODED_BADLANDS.apply(SurfaceConfig.CONFIG_BADLANDS));
      FROZEN_OCEAN = register("frozen_ocean", (SurfaceBuilder)SurfaceBuilders.FROZEN_OCEAN.apply(SurfaceConfig.CONFIG_GRASS));
      FULL_SAND = register("full_sand", (SurfaceBuilder)SurfaceBuilders.DEFAULT.apply(SurfaceConfig.CONFIG_FULL_SAND));
      GIANT_TREE_TAIGA = register("giant_tree_taiga", (SurfaceBuilder)SurfaceBuilders.GIANT_TREE_TAIGA.apply(SurfaceConfig.CONFIG_GRASS));
      GRASS = register("grass", (SurfaceBuilder)SurfaceBuilders.DEFAULT.apply(SurfaceConfig.CONFIG_GRASS));
      GRAVELLY_MOUNTAIN = register("gravelly_mountain", (SurfaceBuilder)SurfaceBuilders.GRAVELLY_MOUNTAIN.apply(SurfaceConfig.CONFIG_GRASS));
      ICE_SPIKES = register("ice_spikes", (SurfaceBuilder)SurfaceBuilders.DEFAULT.apply(SurfaceConfig.CONFIG_ICE_SPIKES));
      MOUNTAIN = register("mountain", (SurfaceBuilder)SurfaceBuilders.MOUNTAIN.apply(SurfaceConfig.CONFIG_GRASS));
      MYCELIUM = register("mycelium", (SurfaceBuilder)SurfaceBuilders.DEFAULT.apply(SurfaceConfig.CONFIG_MYCELIUM));
      NETHER = register("nether", (SurfaceBuilder)SurfaceBuilders.NETHER.apply(SurfaceConfig.CONFIG_HELL));
      NOPE = register("nope", (SurfaceBuilder)SurfaceBuilders.NOPE.apply(SurfaceConfig.CONFIG_STONE));
      OCEAN_SAND = register("ocean_sand", (SurfaceBuilder)SurfaceBuilders.DEFAULT.apply(SurfaceConfig.CONFIG_OCEAN_SAND));
      SHATTERED_SAVANNA = register("shattered_savanna", (SurfaceBuilder)SurfaceBuilders.SHATTERED_SAVANNA.apply(SurfaceConfig.CONFIG_GRASS));
      SOUL_SAND_VALLEY = register("soul_sand_valley", (SurfaceBuilder)SurfaceBuilders.SOUL_SAND_VALLEY.apply(SurfaceConfig.CONFIG_SOUL_SAND_VALLEY));
      STONE = register("stone", (SurfaceBuilder)SurfaceBuilders.DEFAULT.apply(SurfaceConfig.CONFIG_STONE));
      SWAMP = register("swamp", (SurfaceBuilder)SurfaceBuilders.SWAMP.apply(SurfaceConfig.CONFIG_GRASS));
      WARPED_FOREST = register("warped_forest", (SurfaceBuilder)SurfaceBuilders.NETHER_FOREST.apply(SurfaceConfig.CONFIG_WARPED_FOREST));
      WOODED_BADLANDS = register("wooded_badlands", (SurfaceBuilder)SurfaceBuilders.WOODED_BADLANDS.apply(SurfaceConfig.CONFIG_BADLANDS));
   }
}
