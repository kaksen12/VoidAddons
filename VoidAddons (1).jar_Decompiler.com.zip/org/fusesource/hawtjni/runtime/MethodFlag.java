package org.fusesource.hawtjni.runtime;

public enum MethodFlag {
   METHOD_SKIP,
   DYNAMIC,
   CONSTANT_GETTER,
   CAST,
   JNI,
   ADDRESS,
   CPP_METHOD,
   CPP_NEW,
   CPP_DELETE,
   CS_NEW,
   CS_OBJECT,
   SETTER,
   GETTER,
   ADDER,
   POINTER_RETURN,
   CONSTANT_INITIALIZER;

   // $FF: synthetic method
   private static MethodFlag[] $values() {
      return new MethodFlag[]{METHOD_SKIP, DYNAMIC, CONSTANT_GETTER, CAST, JNI, ADDRESS, CPP_METHOD, CPP_NEW, CPP_DELETE, CS_NEW, CS_OBJECT, SETTER, GETTER, ADDER, POINTER_RETURN, CONSTANT_INITIALIZER};
   }
}
