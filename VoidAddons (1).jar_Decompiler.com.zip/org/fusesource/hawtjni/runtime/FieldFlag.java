package org.fusesource.hawtjni.runtime;

public enum FieldFlag {
   FIELD_SKIP,
   CONSTANT,
   POINTER_FIELD,
   SHARED_PTR,
   GETTER_NONMEMBER,
   SETTER_NONMEMBER;

   // $FF: synthetic method
   private static FieldFlag[] $values() {
      return new FieldFlag[]{FIELD_SKIP, CONSTANT, POINTER_FIELD, SHARED_PTR, GETTER_NONMEMBER, SETTER_NONMEMBER};
   }
}
