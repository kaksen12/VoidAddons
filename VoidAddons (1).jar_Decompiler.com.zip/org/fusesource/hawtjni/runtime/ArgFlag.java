package org.fusesource.hawtjni.runtime;

public enum ArgFlag {
   NO_IN,
   NO_OUT,
   CRITICAL,
   INIT,
   POINTER_ARG,
   BY_VALUE,
   UNICODE,
   SENTINEL,
   CS_OBJECT;

   // $FF: synthetic method
   private static ArgFlag[] $values() {
      return new ArgFlag[]{NO_IN, NO_OUT, CRITICAL, INIT, POINTER_ARG, BY_VALUE, UNICODE, SENTINEL, CS_OBJECT};
   }
}
