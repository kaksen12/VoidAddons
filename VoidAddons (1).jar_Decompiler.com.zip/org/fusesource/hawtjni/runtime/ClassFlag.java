package org.fusesource.hawtjni.runtime;

public enum ClassFlag {
   CLASS_SKIP,
   CPP,
   STRUCT,
   TYPEDEF,
   ZERO_OUT;

   // $FF: synthetic method
   private static ClassFlag[] $values() {
      return new ClassFlag[]{CLASS_SKIP, CPP, STRUCT, TYPEDEF, ZERO_OUT};
   }
}
