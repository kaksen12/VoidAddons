package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.events.StopUsingItemEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import net.minecraft.class_634;
import net.minecraft.class_746;
import net.minecraft.class_2848.class_2849;

public class ArrowDmg extends Module {
   private final SettingGroup sgGeneral;
   public final Setting<Double> strength;
   public final Setting<Boolean> tridents;

   public ArrowDmg() {
      super(MeteorRejectsAddon.CATEGORY, "arrow-damage", "Massively increases arrow damage, but reduces accuracy and consume more hunger. Does not work with crossbows and is patched on Paper servers.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.strength = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("strength")).description("More strength = higher damage.")).defaultValue((double)5.0F).min(0.1).sliderMax((double)25.0F).build());
      this.tridents = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("tridents")).description("When enabled, tridents fly much further. Doesn't seem to affect damage or Riptide. WARNING: You can easily lose your trident by enabling this option!")).defaultValue(false)).build());
   }

   @EventHandler
   private void onStopUsingItem(StopUsingItemEvent event) {
      if (this.isValidItem(event.itemStack.method_7909())) {
         class_746 p = this.mc.field_1724;
         p.field_3944.method_52787(new class_2848(p, class_2849.field_12981));
         double x = p.method_23317();
         double y = p.method_23318();
         double z = p.method_23321();
         double adjustedStrength = (Double)this.strength.get() / (double)10.0F * Math.sqrt((double)500.0F);
         class_243 lookVec = p.method_5828(1.0F).method_1021(adjustedStrength);

         for(int i = 0; i < 4; ++i) {
            this.sendPos(x, y, z, true);
         }

         this.sendPos(x - lookVec.field_1352, y, z - lookVec.field_1350, true);
         this.sendPos(x, y, z, false);
      }
   }

   private void sendPos(double x, double y, double z, boolean onGround) {
      class_634 clientPacketListener = this.mc.field_1724.field_3944;
      clientPacketListener.method_52787(new class_2828.class_2829(x, y, z, onGround, this.mc.field_1724.field_5976));
   }

   private boolean isValidItem(class_1792 item) {
      return (Boolean)this.tridents.get() && item == class_1802.field_8547 || item == class_1802.field_8102;
   }
}
