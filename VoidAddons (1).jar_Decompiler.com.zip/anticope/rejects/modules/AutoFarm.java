package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.utils.WorldUtils;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import meteordevelopment.meteorclient.events.entity.player.BreakBlockEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.world.BlockIterator;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2282;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2344;
import net.minecraft.class_2350;
import net.minecraft.class_2420;
import net.minecraft.class_2421;
import net.minecraft.class_243;
import net.minecraft.class_2473;
import net.minecraft.class_2492;
import net.minecraft.class_2513;
import net.minecraft.class_2680;
import net.minecraft.class_3486;
import net.minecraft.class_3830;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5800;
import net.minecraft.class_8237;

public class AutoFarm extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgTill;
   private final SettingGroup sgHarvest;
   private final SettingGroup sgPlant;
   private final SettingGroup sgBonemeal;
   private final Map<class_2338, class_1792> replantMap;
   private final Setting<Integer> range;
   private final Setting<Integer> bpt;
   private final Setting<Boolean> rotate;
   private final Setting<Boolean> till;
   private final Setting<Boolean> moist;
   private final Setting<Boolean> harvest;
   private final Setting<List<class_2248>> harvestBlocks;
   private final Setting<Boolean> plant;
   private final Setting<List<class_1792>> plantItems;
   private final Setting<Boolean> onlyReplant;
   private final Setting<Boolean> bonemeal;
   private final Setting<List<class_2248>> bonemealBlocks;
   private final Pool<class_2338.class_2339> blockPosPool;
   private final List<class_2338.class_2339> blocks;
   int actions;

   public AutoFarm() {
      super(MeteorRejectsAddon.CATEGORY, "auto-farm", "All-in-one farm utility.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgTill = this.settings.createGroup("Till");
      this.sgHarvest = this.settings.createGroup("Harvest");
      this.sgPlant = this.settings.createGroup("Plant");
      this.sgBonemeal = this.settings.createGroup("Bonemeal");
      this.replantMap = new HashMap();
      this.range = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("range")).description("Auto farm range.")).defaultValue(4)).min(1).build());
      this.bpt = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("blocks-per-tick")).description("Amount of operations that can be applied in one tick.")).min(1).defaultValue(1)).build());
      this.rotate = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("rotate")).description("Whether or not to rotate towards block.")).defaultValue(true)).build());
      this.till = this.sgTill.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("till")).description("Turn nearby dirt into farmland.")).defaultValue(true)).build());
      this.moist = this.sgTill.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("moist")).description("Only till moist blocks.")).defaultValue(true)).build());
      this.harvest = this.sgHarvest.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("harvest")).description("Harvest crops.")).defaultValue(true)).build());
      this.harvestBlocks = this.sgHarvest.add(((BlockListSetting.Builder)((BlockListSetting.Builder)(new BlockListSetting.Builder()).name("harvest-blocks")).description("Which crops to harvest.")).defaultValue(new class_2248[0]).filter(this::harvestFilter).build());
      this.plant = this.sgPlant.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("plant")).description("Plant crops.")).defaultValue(true)).build());
      this.plantItems = this.sgPlant.add(((ItemListSetting.Builder)((ItemListSetting.Builder)(new ItemListSetting.Builder()).name("plant-items")).description("Which crops to plant.")).defaultValue(new class_1792[0]).filter(this::plantFilter).build());
      this.onlyReplant = this.sgPlant.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("only-replant")).description("Only replant planted crops.")).defaultValue(true)).onChanged((b) -> this.replantMap.clear())).build());
      this.bonemeal = this.sgBonemeal.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("bonemeal")).description("Bonemeal crops.")).defaultValue(true)).build());
      this.bonemealBlocks = this.sgBonemeal.add(((BlockListSetting.Builder)((BlockListSetting.Builder)(new BlockListSetting.Builder()).name("bonemeal-blocks")).description("Which crops to bonemeal.")).defaultValue(new class_2248[0]).filter(this::bonemealFilter).build());
      this.blockPosPool = new Pool(class_2338.class_2339::new);
      this.blocks = new ArrayList();
      this.actions = 0;
   }

   public void onDeactivate() {
      this.replantMap.clear();
   }

   @EventHandler
   private void onBreakBlock(BreakBlockEvent event) {
      class_2680 state = this.mc.field_1687.method_8320(event.blockPos);
      class_2248 block = state.method_26204();
      if ((Boolean)this.onlyReplant.get()) {
         class_1792 item = null;
         if (block == class_2246.field_10293) {
            item = class_1802.field_8317;
         } else if (block == class_2246.field_10609) {
            item = class_1802.field_8179;
         } else if (block == class_2246.field_10247) {
            item = class_1802.field_8567;
         } else if (block == class_2246.field_10341) {
            item = class_1802.field_8309;
         } else if (block == class_2246.field_9974) {
            item = class_1802.field_8790;
         } else if (block == class_2246.field_43228) {
            item = class_1802.field_43195;
         } else if (block == class_2246.field_42734) {
            item = class_1802.field_42711;
         }

         if (item != null) {
            this.replantMap.put(event.blockPos, item);
         }
      }

   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      this.actions = 0;
      BlockIterator.register((Integer)this.range.get(), (Integer)this.range.get(), (pos, state) -> {
         if (this.mc.field_1724.method_33571().method_1022(class_243.method_24953(pos)) <= (double)(Integer)this.range.get()) {
            this.blocks.add(((class_2338.class_2339)this.blockPosPool.get()).method_10101(pos));
         }

      });
      BlockIterator.after(() -> {
         this.blocks.sort(Comparator.comparingDouble((value) -> this.mc.field_1724.method_33571().method_1022(class_243.method_24953(value))));

         for(class_2338 pos : this.blocks) {
            class_2680 state = this.mc.field_1687.method_8320(pos);
            class_2248 block = state.method_26204();
            if (this.till(pos, block) || this.harvest(pos, state, block) || this.plant(pos, block) || this.bonemeal(pos, state, block)) {
               ++this.actions;
            }

            if (this.actions >= (Integer)this.bpt.get()) {
               break;
            }
         }

         for(class_2338.class_2339 blockPos : this.blocks) {
            this.blockPosPool.free(blockPos);
         }

         this.blocks.clear();
      });
   }

   private boolean till(class_2338 pos, class_2248 block) {
      if (!(Boolean)this.till.get()) {
         return false;
      } else {
         boolean moist = !(Boolean)this.moist.get() || this.isWaterNearby(this.mc.field_1687, pos);
         boolean tillable = block == class_2246.field_10219 || block == class_2246.field_10194 || block == class_2246.field_10566 || block == class_2246.field_10253 || block == class_2246.field_28685;
         if (moist && tillable && this.mc.field_1687.method_8320(pos.method_10084()).method_26215()) {
            FindItemResult hoe = InvUtils.findInHotbar((itemStack) -> itemStack.method_7909() instanceof class_1794);
            return WorldUtils.interact(pos, hoe, (Boolean)this.rotate.get());
         } else {
            return false;
         }
      }
   }

   private boolean harvest(class_2338 pos, class_2680 state, class_2248 block) {
      if (!(Boolean)this.harvest.get()) {
         return false;
      } else if (!((List)this.harvestBlocks.get()).contains(block)) {
         return false;
      } else if (!this.isMature(state, block)) {
         return false;
      } else {
         if (block instanceof class_3830) {
            this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, new class_3965(Utils.vec3d(pos), class_2350.field_11036, pos, false));
         } else {
            BlockUtils.breakBlock(pos, true);
         }

         return true;
      }
   }

   private boolean plant(class_2338 pos, class_2248 block) {
      if (!(Boolean)this.plant.get()) {
         return false;
      } else if (!this.mc.field_1687.method_22347(pos.method_10084())) {
         return false;
      } else {
         FindItemResult findItemResult = null;
         if ((Boolean)this.onlyReplant.get()) {
            for(class_2338 replantPos : this.replantMap.keySet()) {
               if (replantPos.equals(pos.method_10084())) {
                  findItemResult = InvUtils.find(new class_1792[]{(class_1792)this.replantMap.get(replantPos)});
                  this.replantMap.remove(replantPos);
                  break;
               }
            }
         } else if (block instanceof class_2344) {
            findItemResult = InvUtils.find((itemStack) -> {
               class_1792 item = itemStack.method_7909();
               return item != class_1802.field_8790 && ((List)this.plantItems.get()).contains(item);
            });
         } else if (block instanceof class_2492) {
            findItemResult = InvUtils.find((itemStack) -> {
               class_1792 item = itemStack.method_7909();
               return item == class_1802.field_8790 && ((List)this.plantItems.get()).contains(class_1802.field_8790);
            });
         }

         if (findItemResult != null && findItemResult.found()) {
            BlockUtils.place(pos.method_10084(), findItemResult, (Boolean)this.rotate.get(), -100, false);
            return true;
         } else {
            return false;
         }
      }
   }

   private boolean bonemeal(class_2338 pos, class_2680 state, class_2248 block) {
      if (!(Boolean)this.bonemeal.get()) {
         return false;
      } else if (!((List)this.bonemealBlocks.get()).contains(block)) {
         return false;
      } else if (this.isMature(state, block)) {
         return false;
      } else {
         FindItemResult bonemeal = InvUtils.findInHotbar(new class_1792[]{class_1802.field_8324});
         return WorldUtils.interact(pos, bonemeal, (Boolean)this.rotate.get());
      }
   }

   private boolean isWaterNearby(class_4538 world, class_2338 pos) {
      for(class_2338 blockPos : class_2338.method_10097(pos.method_10069(-4, 0, -4), pos.method_10069(4, 1, 4))) {
         if (world.method_8316(blockPos).method_15767(class_3486.field_15517)) {
            return true;
         }
      }

      return false;
   }

   private boolean isMature(class_2680 state, class_2248 block) {
      if (block instanceof class_2302 cropBlock) {
         return cropBlock.method_9825(state);
      } else if (block instanceof class_2282 cocoaBlock) {
         return (Integer)state.method_11654(class_2282.field_10779) >= 2;
      } else if (block instanceof class_2513) {
         return (Integer)state.method_11654(class_2513.field_11584) == 7;
      } else if (block instanceof class_3830) {
         class_3830 sweetBerryBushBlock = (class_3830)block;
         return (Integer)state.method_11654(class_3830.field_17000) >= 2;
      } else if (block instanceof class_2421) {
         class_2421 netherWartBlock = (class_2421)block;
         return (Integer)state.method_11654(class_2421.field_11306) >= 3;
      } else if (block instanceof class_8237) {
         class_8237 pitcherCropBlock = (class_8237)block;
         return (Integer)state.method_11654(class_8237.field_43239) >= 4;
      } else {
         return !(block instanceof class_2473);
      }
   }

   private boolean bonemealFilter(class_2248 block) {
      return block instanceof class_2302 || block instanceof class_2513 || block instanceof class_2420 || block instanceof class_5800 || block instanceof class_2473 || block == class_2246.field_10302 || block == class_2246.field_16999 || block == class_2246.field_43228 || block == class_2246.field_42734;
   }

   private boolean harvestFilter(class_2248 block) {
      return block instanceof class_2302 || block == class_2246.field_46282 || block == class_2246.field_46283 || block == class_2246.field_9974 || block == class_2246.field_16999 || block == class_2246.field_10302 || block == class_2246.field_43228 || block == class_2246.field_42734;
   }

   private boolean plantFilter(class_1792 item) {
      return item == class_1802.field_8317 || item == class_1802.field_8179 || item == class_1802.field_8567 || item == class_1802.field_8309 || item == class_1802.field_46249 || item == class_1802.field_46250 || item == class_1802.field_8790 || item == class_1802.field_43195 || item == class_1802.field_42711;
   }
}
