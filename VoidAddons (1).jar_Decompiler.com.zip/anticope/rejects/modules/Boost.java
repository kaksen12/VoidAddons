package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.Objects;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;

public class Boost extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Double> strength;
   private final Setting<Boolean> autoBoost;
   private final Setting<Integer> interval;
   private int timer;

   public Boost() {
      super(MeteorRejectsAddon.CATEGORY, "boost", "Works like a dash move.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.strength = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("strength")).description("Strength to yeet you with.")).defaultValue((double)4.0F).sliderMax((double)10.0F).build());
      this.autoBoost = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("auto-boost")).description("Automatically boosts you.")).defaultValue(false)).build());
      SettingGroup var10001 = this.sgGeneral;
      IntSetting.Builder var10002 = (IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("interval")).description("Boost interval in ticks.");
      Setting var10003 = this.autoBoost;
      Objects.requireNonNull(var10003);
      this.interval = var10001.add(((IntSetting.Builder)((IntSetting.Builder)var10002.visible(var10003::get)).defaultValue(20)).sliderMax(120).build());
      this.timer = 0;
   }

   public void onActivate() {
      this.timer = (Integer)this.interval.get();
      if (!(Boolean)this.autoBoost.get()) {
         if (this.mc.field_1724 != null) {
            this.boost();
         }

         this.toggle();
      }

   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      if ((Boolean)this.autoBoost.get()) {
         if (this.timer < 1) {
            this.boost();
            this.timer = (Integer)this.interval.get();
         } else {
            --this.timer;
         }

      }
   }

   private void boost() {
      class_243 v = this.mc.field_1724.method_5663().method_1021((Double)this.strength.get());
      this.mc.field_1724.method_5762(v.method_10216(), v.method_10214(), v.method_10215());
   }
}
