package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1923;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2626;
import net.minecraft.class_2637;
import net.minecraft.class_2672;
import net.minecraft.class_2818;
import net.minecraft.class_3610;
import net.minecraft.class_2902.class_2903;

public class NewChunks extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgRender;
   private final Setting<Boolean> remove;
   public final Setting<Integer> renderHeight;
   private final Setting<ShapeMode> shapeMode;
   private final Setting<SettingColor> newChunksSideColor;
   private final Setting<SettingColor> oldChunksSideColor;
   private final Setting<SettingColor> newChunksLineColor;
   private final Setting<SettingColor> oldChunksLineColor;
   private final Set<class_1923> newChunks;
   private final Set<class_1923> oldChunks;
   private static final class_2350[] searchDirs;
   private final Executor taskExecutor;

   public NewChunks() {
      super(MeteorRejectsAddon.CATEGORY, "new-chunks", "Detects completely new chunks using certain traits of them");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgRender = this.settings.createGroup("Render");
      this.remove = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("remove")).description("Removes the cached chunks when disabling the module.")).defaultValue(true)).build());
      this.renderHeight = this.sgRender.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("render-height")).description("The height at which new chunks will be rendered")).defaultValue(0)).min(-64).sliderRange(-64, 319).build());
      this.shapeMode = this.sgRender.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
      this.newChunksSideColor = this.sgRender.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("new-chunks-side-color")).description("Color of the chunks that are (most likely) completely new.")).defaultValue(new SettingColor(255, 0, 0, 75)).visible(() -> this.shapeMode.get() == ShapeMode.Sides || this.shapeMode.get() == ShapeMode.Both)).build());
      this.oldChunksSideColor = this.sgRender.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("old-chunks-side-color")).description("Color of the chunks that have (most likely) been loaded before.")).defaultValue(new SettingColor(0, 255, 0, 75)).visible(() -> this.shapeMode.get() == ShapeMode.Sides || this.shapeMode.get() == ShapeMode.Both)).build());
      this.newChunksLineColor = this.sgRender.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("new-chunks-line-color")).description("Color of the chunks that are (most likely) completely new.")).defaultValue(new SettingColor(255, 0, 0, 255)).visible(() -> this.shapeMode.get() == ShapeMode.Lines || this.shapeMode.get() == ShapeMode.Both)).build());
      this.oldChunksLineColor = this.sgRender.add(((ColorSetting.Builder)((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("old-chunks-line-color")).description("Color of the chunks that have (most likely) been loaded before.")).defaultValue(new SettingColor(0, 255, 0, 255)).visible(() -> this.shapeMode.get() == ShapeMode.Lines || this.shapeMode.get() == ShapeMode.Both)).build());
      this.newChunks = Collections.synchronizedSet(new HashSet());
      this.oldChunks = Collections.synchronizedSet(new HashSet());
      this.taskExecutor = Executors.newSingleThreadExecutor();
   }

   public void onDeactivate() {
      if ((Boolean)this.remove.get()) {
         this.newChunks.clear();
         this.oldChunks.clear();
      }

      super.onDeactivate();
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (((SettingColor)this.newChunksLineColor.get()).a > 5 || ((SettingColor)this.newChunksSideColor.get()).a > 5) {
         synchronized(this.newChunks) {
            for(class_1923 c : this.newChunks) {
               if (this.mc.method_1560().method_24515().method_19771(c.method_8323(), (double)1024.0F)) {
                  this.render(new class_238(class_243.method_24954(c.method_8323()), class_243.method_24954(c.method_8323().method_10069(16, (Integer)this.renderHeight.get(), 16))), (Color)this.newChunksSideColor.get(), (Color)this.newChunksLineColor.get(), (ShapeMode)this.shapeMode.get(), event);
               }
            }
         }
      }

      if (((SettingColor)this.oldChunksLineColor.get()).a > 5 || ((SettingColor)this.oldChunksSideColor.get()).a > 5) {
         synchronized(this.oldChunks) {
            for(class_1923 c : this.oldChunks) {
               if (this.mc.method_1560().method_24515().method_19771(c.method_8323(), (double)1024.0F)) {
                  this.render(new class_238(class_243.method_24954(c.method_8323()), class_243.method_24954(c.method_8323().method_10069(16, (Integer)this.renderHeight.get(), 16))), (Color)this.oldChunksSideColor.get(), (Color)this.oldChunksLineColor.get(), (ShapeMode)this.shapeMode.get(), event);
               }
            }
         }
      }

   }

   private void render(class_238 box, Color sides, Color lines, ShapeMode shapeMode, Render3DEvent event) {
      event.renderer.box(box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1324, sides, lines, shapeMode, 0);
   }

   @EventHandler
   private void onReadPacket(PacketEvent.Receive event) {
      if (event.packet instanceof class_2637) {
         class_2637 packet = (class_2637)event.packet;
         packet.method_30621((posx, state) -> {
            if (!state.method_26227().method_15769() && !state.method_26227().method_15771()) {
               class_1923 chunkPos = new class_1923(posx);

               for(class_2350 dir : searchDirs) {
                  if (this.mc.field_1687.method_8320(posx.method_10093(dir)).method_26227().method_15771() && !this.oldChunks.contains(chunkPos)) {
                     this.newChunks.add(chunkPos);
                     return;
                  }
               }
            }

         });
      } else if (event.packet instanceof class_2626) {
         class_2626 packet = (class_2626)event.packet;
         if (!packet.method_11308().method_26227().method_15769() && !packet.method_11308().method_26227().method_15771()) {
            class_1923 chunkPos = new class_1923(packet.method_11309());

            for(class_2350 dir : searchDirs) {
               if (this.mc.field_1687.method_8320(packet.method_11309().method_10093(dir)).method_26227().method_15771() && !this.oldChunks.contains(chunkPos)) {
                  this.newChunks.add(chunkPos);
                  return;
               }
            }
         }
      } else if (event.packet instanceof class_2672 && this.mc.field_1687 != null) {
         class_2672 packet = (class_2672)event.packet;
         class_1923 pos = new class_1923(packet.method_11523(), packet.method_11524());
         if (!this.newChunks.contains(pos) && this.mc.field_1687.method_2935().method_12246(packet.method_11523(), packet.method_11524()) == null) {
            class_2818 chunk = new class_2818(this.mc.field_1687, pos);

            try {
               this.taskExecutor.execute(() -> chunk.method_12224(packet.method_38598().method_38586(), new HashMap(), packet.method_38598().method_38587(packet.method_11523(), packet.method_11524())));
            } catch (ArrayIndexOutOfBoundsException var9) {
               return;
            }

            for(int x = 0; x < 16; ++x) {
               for(int z = 0; z < 16; ++z) {
                  for(int y = this.mc.field_1687.method_31607(); y < this.mc.field_1687.method_8624(class_2903.field_13197, x, z); ++y) {
                     class_3610 fluid = chunk.method_12234(x, y, z);
                     if (!fluid.method_15769() && !fluid.method_15771()) {
                        this.oldChunks.add(pos);
                        return;
                     }
                  }
               }
            }
         }
      }

   }

   static {
      searchDirs = new class_2350[]{class_2350.field_11034, class_2350.field_11043, class_2350.field_11039, class_2350.field_11035, class_2350.field_11036};
   }
}
