package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.events.OffGroundSpeedEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_746;

public class Glide extends Module {
   private final SettingGroup sgGeneral;
   public final Setting<Double> fallSpeed;
   public final Setting<Double> moveSpeed;
   public final Setting<Double> minHeight;

   public Glide() {
      super(MeteorRejectsAddon.CATEGORY, "glide", "Yeehaw!");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.fallSpeed = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("fall-speed")).description("Fall speed.")).defaultValue((double)0.125F).min(0.005).sliderRange(0.005, (double)0.25F).build());
      this.moveSpeed = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("move-speed")).description("Horizontal movement factor.")).defaultValue(1.2).min((double)1.0F).sliderRange((double)1.0F, (double)5.0F).build());
      this.minHeight = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("min-height")).description("Won't glide when you are too close to the ground.")).defaultValue((double)0.0F).min((double)0.0F).sliderRange((double)0.0F, (double)2.0F).build());
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      class_746 player = this.mc.field_1724;
      class_243 v = player.method_18798();
      if (!player.method_24828() && !player.method_5799() && !player.method_5771() && !player.method_6101() && !(v.field_1351 >= (double)0.0F)) {
         if ((Double)this.minHeight.get() > (double)0.0F) {
            class_238 box = player.method_5829();
            box = box.method_991(box.method_989((double)0.0F, -(Double)this.minHeight.get(), (double)0.0F));
            if (!this.mc.field_1687.method_18026(box)) {
               return;
            }
         }

         player.method_18800(v.field_1352, Math.max(v.field_1351, -(Double)this.fallSpeed.get()), v.field_1350);
      }
   }

   @EventHandler
   private void onOffGroundSpeed(OffGroundSpeedEvent event) {
      event.speed *= ((Double)this.moveSpeed.get()).floatValue();
   }
}
