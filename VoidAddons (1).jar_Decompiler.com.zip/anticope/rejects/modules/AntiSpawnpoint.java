package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1937;
import net.minecraft.class_2244;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2885;

public class AntiSpawnpoint extends Module {
   private SettingGroup sgDefault;
   private Setting<Boolean> fakeUse;

   public AntiSpawnpoint() {
      super(MeteorRejectsAddon.CATEGORY, "anti-spawnpoint", "Protects the player from losing the respawn point.");
      this.sgDefault = this.settings.getDefaultGroup();
      this.fakeUse = this.sgDefault.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("fake-use")).description("Fake using the bed or anchor.")).defaultValue(true)).build());
   }

   @EventHandler
   private void onSendPacket(PacketEvent.Send event) {
      if (this.mc.field_1687 != null) {
         if (event.packet instanceof class_2885) {
            class_2338 blockPos = ((class_2885)event.packet).method_12543().method_17777();
            boolean IsOverWorld = this.mc.field_1687.method_27983() == class_1937.field_25179;
            boolean IsNetherWorld = this.mc.field_1687.method_27983() == class_1937.field_25180;
            boolean BlockIsBed = this.mc.field_1687.method_8320(blockPos).method_26204() instanceof class_2244;
            boolean BlockIsAnchor = this.mc.field_1687.method_8320(blockPos).method_26204().equals(class_2246.field_23152);

            assert this.mc.field_1724 != null;

            if ((Boolean)this.fakeUse.get()) {
               if (BlockIsBed && IsOverWorld) {
                  this.mc.field_1724.method_6104(class_1268.field_5808);
                  this.mc.field_1724.method_30634((double)blockPos.method_10263(), (double)blockPos.method_10084().method_10264(), (double)blockPos.method_10260());
               } else if (BlockIsAnchor && IsNetherWorld) {
                  this.mc.field_1724.method_6104(class_1268.field_5808);
               }
            }

            if (BlockIsBed && IsOverWorld || BlockIsAnchor && IsNetherWorld) {
               event.cancel();
            }

         }
      }
   }
}
