package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.entity.BoatMoveEvent;
import meteordevelopment.meteorclient.events.meteor.KeyEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.misc.input.KeyAction;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10255;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_2824;

public class BoatGlitch extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Boolean> toggleAfter;
   private final Setting<Boolean> remount;
   private class_1297 boat;
   private int dismountTicks;
   private int remountTicks;
   private boolean dontPhase;
   private boolean boatPhaseEnabled;

   public BoatGlitch() {
      super(MeteorRejectsAddon.CATEGORY, "boat-glitch", "Glitches your boat into the block beneath you.  Dismount to trigger.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.toggleAfter = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("toggle-after")).description("Disables the module when finished.")).defaultValue(true)).build());
      this.remount = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("remount")).description("Remounts the boat when finished.")).defaultValue(true)).build());
      this.boat = null;
      this.dismountTicks = 0;
      this.remountTicks = 0;
      this.dontPhase = true;
   }

   public void onActivate() {
      this.dontPhase = true;
      this.dismountTicks = 0;
      this.remountTicks = 0;
      this.boat = null;
      if (Modules.get().isActive(BoatPhase.class)) {
         this.boatPhaseEnabled = true;
         ((BoatPhase)Modules.get().get(BoatPhase.class)).toggle();
      } else {
         this.boatPhaseEnabled = false;
      }

   }

   public void onDeactivate() {
      if (this.boat != null) {
         this.boat.field_5960 = false;
         this.boat = null;
      }

      if (this.boatPhaseEnabled && !Modules.get().isActive(BoatPhase.class)) {
         ((BoatPhase)Modules.get().get(BoatPhase.class)).toggle();
      }

   }

   @EventHandler
   private void onBoatMove(BoatMoveEvent event) {
      if (this.dismountTicks == 0 && !this.dontPhase) {
         if (this.boat != event.boat) {
            if (this.boat != null) {
               this.boat.field_5960 = false;
            }

            if (this.mc.field_1724.method_5854() != null && event.boat == this.mc.field_1724.method_5854()) {
               this.boat = event.boat;
            } else {
               this.boat = null;
            }
         }

         if (this.boat != null) {
            this.boat.field_5960 = true;
            this.dismountTicks = 5;
         }
      }

   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      if (this.dismountTicks > 0) {
         --this.dismountTicks;
         if (this.dismountTicks == 0) {
            if (this.boat != null) {
               this.boat.field_5960 = false;
               if ((Boolean)this.toggleAfter.get() && !(Boolean)this.remount.get()) {
                  this.toggle();
               } else if ((Boolean)this.remount.get()) {
                  this.remountTicks = 5;
               }
            }

            this.dontPhase = true;
         }
      }

      if (this.remountTicks > 0) {
         --this.remountTicks;
         if (this.remountTicks == 0) {
            this.mc.method_1562().method_52787(class_2824.method_34207(this.boat, false, class_1268.field_5808));
            if ((Boolean)this.toggleAfter.get()) {
               this.toggle();
            }
         }
      }

   }

   @EventHandler
   private void onKey(KeyEvent event) {
      if (event.key() == this.mc.field_1690.field_1832.method_1429().method_1444() && event.action == KeyAction.Press && this.mc.field_1724.method_5854() instanceof class_10255) {
         this.dontPhase = false;
         this.boat = null;
      }

   }
}
