package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import io.netty.channel.ChannelFutureListener;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10255;
import net.minecraft.class_1688;
import net.minecraft.class_239;
import net.minecraft.class_2824;
import net.minecraft.class_3966;

public class VehicleOneHit extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Integer> amount;
   private boolean sending;

   public VehicleOneHit() {
      super(MeteorRejectsAddon.CATEGORY, "vehicle-one-hit", "Destroy vehicles with one hit.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.amount = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("amount")).description("The number of packets to send.")).defaultValue(16)).range(1, 100).sliderRange(1, 20).build());
      this.sending = false;
   }

   @EventHandler
   private void onPacketSend(PacketEvent.Send event) {
      if (!this.sending) {
         if (event.packet instanceof class_2824) {
            class_239 var3 = this.mc.field_1765;
            if (var3 instanceof class_3966) {
               class_3966 ehr = (class_3966)var3;
               if (ehr.method_17782() instanceof class_1688 || ehr.method_17782() instanceof class_10255) {
                  this.sending = true;

                  for(int i = 0; i < (Integer)this.amount.get() - 1; ++i) {
                     this.mc.field_1724.field_3944.method_48296().method_10752(event.packet, (ChannelFutureListener)null);
                  }

                  this.sending = false;
                  return;
               }
            }
         }

      }
   }
}
