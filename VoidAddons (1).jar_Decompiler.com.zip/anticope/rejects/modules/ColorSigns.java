package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.List;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2596;
import net.minecraft.class_2678;
import net.minecraft.class_2820;
import net.minecraft.class_2877;
import net.minecraft.server.MinecraftServer;

public class ColorSigns extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Boolean> signs;
   private final Setting<Boolean> books;

   public ColorSigns() {
      super(MeteorRejectsAddon.CATEGORY, "color-signs", "Allows you to use colors on signs on NON-PAPER servers (use \"&\" for color symbols)");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.signs = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("signs")).description("Allows you to use colors in signs.")).defaultValue(true)).build());
      this.books = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("books")).description("Allows you to use colors in books.")).defaultValue(false)).build());
   }

   @EventHandler
   private void onPacketSend(PacketEvent.Send event) {
      if (event.packet instanceof class_2678) {
         this.checkWarning();
      } else {
         if ((Boolean)this.signs.get()) {
            class_2596 var3 = event.packet;
            if (var3 instanceof class_2877) {
               class_2877 packet = (class_2877)var3;

               for(int line = 0; line < packet.method_12508().length; ++line) {
                  packet.method_12508()[line] = packet.method_12508()[line].replaceAll("(?i)(?:&|(?<!§)§)([0-9A-Z])", "§§$1$1");
               }
            }
         }

         if ((Boolean)this.books.get()) {
            class_2596 var6 = event.packet;
            if (var6 instanceof class_2820) {
               class_2820 packet = (class_2820)var6;
               List<String> newPages = packet.comp_2286().stream().map((text) -> text.replaceAll("(?i)&([0-9A-Z])", "§$1")).toList();
               if (!packet.comp_2286().equals(newPages)) {
                  assert this.mc.method_1562() != null;

                  this.mc.method_1562().method_52787(new class_2820(packet.comp_2285(), newPages, packet.comp_2287()));
                  event.cancel();
               }
            }
         }

      }
   }

   public void onActivate() {
      super.onActivate();
      this.checkWarning();
   }

   private void checkWarning() {
      assert this.mc.field_1724 != null;

      MinecraftServer server = this.mc.field_1724.method_73183().method_8503();
      if (server != null) {
         String brand = server.getServerModName();
         if (brand != null) {
            if (brand.contains("Paper")) {
               this.warning("You are on a paper server. Color signs won't work here", new Object[0]);
            }

         }
      }
   }
}
