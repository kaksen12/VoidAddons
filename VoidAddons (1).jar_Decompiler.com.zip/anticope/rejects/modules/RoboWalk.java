package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.mixin.PlayerMoveC2SPacketAccessor;
import anticope.rejects.mixin.VehicleMoveC2SPacketAccessor;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_2833;

public class RoboWalk extends Module {
   public RoboWalk() {
      super(MeteorRejectsAddon.CATEGORY, "robo-walk", "Bypasses LiveOverflow movement check.");
   }

   private double smooth(double d) {
      double temp = (double)Math.round(d * (double)100.0F) / (double)100.0F;
      return Math.nextAfter(temp, temp + Math.signum(d));
   }

   @EventHandler
   private void onPacketSend(PacketEvent.Send event) {
      class_2596 x = event.packet;
      if (x instanceof class_2828 packet) {
         if (!packet.method_36171()) {
            return;
         }

         double x = this.smooth(packet.method_12269((double)0.0F));
         double z = this.smooth(packet.method_12274((double)0.0F));
         ((PlayerMoveC2SPacketAccessor)packet).setX(x);
         ((PlayerMoveC2SPacketAccessor)packet).setZ(z);
      } else {
         x = event.packet;
         if (x instanceof class_2833 packet) {
            class_243 pos = ((VehicleMoveC2SPacketAccessor)packet).getPosition();
            double x = this.smooth(pos.method_10216());
            double z = this.smooth(pos.method_10215());
            event.packet = VehicleMoveC2SPacketAccessor.create(new class_243(x, pos.method_10214(), z), packet.comp_3351(), packet.comp_3352(), packet.comp_3353());
         }
      }

   }
}
