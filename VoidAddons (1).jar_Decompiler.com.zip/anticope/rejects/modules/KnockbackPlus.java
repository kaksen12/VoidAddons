package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.mixininterface.IPlayerInteractEntityC2SPacket;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.combat.KillAura;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_2848;
import net.minecraft.class_2848.class_2849;
import org.jspecify.annotations.NonNull;

public class KnockbackPlus extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Boolean> ka;

   public KnockbackPlus() {
      super(MeteorRejectsAddon.CATEGORY, "knockback-plus", "Performs more KB when you hit your target.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.ka = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("only-killaura")).description("Only perform more KB when using killaura.")).defaultValue(false)).build());
   }

   @EventHandler
   private void onSendPacket(PacketEvent.Send event) {
      class_2596 var3 = event.packet;
      if (var3 instanceof final class_2824 packet) {
         packet.method_34209(new class_2824.class_5908() {
            public void method_34219(@NonNull class_1268 interactionHand) {
            }

            public void method_34220(@NonNull class_1268 interactionHand, @NonNull class_243 vec3) {
            }

            public void method_34218() {
               class_1297 entity = ((IPlayerInteractEntityC2SPacket)packet).meteor$getEntity();
               if (entity instanceof class_1309 && (entity == ((KillAura)Modules.get().get(KillAura.class)).getTarget() || !(Boolean)KnockbackPlus.this.ka.get())) {
                  assert KnockbackPlus.this.mc.field_1724 != null;

                  KnockbackPlus.this.mc.field_1724.field_3944.method_52787(new class_2848(KnockbackPlus.this.mc.field_1724, class_2849.field_12981));
               }
            }
         });
      }

   }
}
