package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import com.mojang.brigadier.suggestion.Suggestion;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.UUID;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import meteordevelopment.meteorclient.events.game.ReceiveMessageEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.gui.widgets.containers.WVerticalList;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2596;
import net.minecraft.class_2639;
import net.minecraft.class_2805;

public class AntiVanish extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Integer> interval;
   private final Setting<Mode> mode;
   private final Setting<String> command;
   private Map<UUID, String> playerCache;
   private final List<String> messageCache;
   private final Random random;
   private final List<Integer> completionIDs;
   private List<String> completionPlayerCache;
   private int timer;

   public AntiVanish() {
      super(MeteorRejectsAddon.CATEGORY, "anti-vanish", "Notifies user when a admin uses /vanish");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.interval = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("interval")).description("Vanish check interval.")).defaultValue(100)).min(0).sliderMax(300).build());
      this.mode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("mode")).defaultValue(AntiVanish.Mode.LeaveMessage)).build());
      this.command = this.sgGeneral.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("command")).description("The completion command to detect player names.")).defaultValue("minecraft:msg")).visible(() -> this.mode.get() == AntiVanish.Mode.RealJoinMessage)).build());
      this.playerCache = new HashMap();
      this.messageCache = new ArrayList();
      this.random = new Random();
      this.completionIDs = new ArrayList();
      this.completionPlayerCache = new ArrayList();
      this.timer = 0;
   }

   public void onActivate() {
      this.timer = 0;
      this.completionIDs.clear();
      this.messageCache.clear();
   }

   public WWidget getWidget(GuiTheme theme) {
      WVerticalList l = theme.verticalList();
      l.add(theme.label("LeaveMessage: If client didn't receive a quit game message (like essentials)."));
      l.add(theme.label("RealJoinMessage: Tell whether the player is really left by using player name completion."));
      return l;
   }

   @EventHandler
   private void onPacket(PacketEvent.Receive event) {
      if (this.mode.get() == AntiVanish.Mode.RealJoinMessage) {
         class_2596 var3 = event.packet;
         if (var3 instanceof class_2639) {
            class_2639 packet = (class_2639)var3;
            if (this.completionIDs.contains(packet.comp_2262())) {
               List<String> lastUsernames = this.completionPlayerCache.stream().toList();
               this.completionPlayerCache = packet.method_11397().getList().stream().map(Suggestion::getText).toList();
               if (lastUsernames.isEmpty()) {
                  return;
               }

               Predicate<String> joinedOrQuit = (playerNamex) -> lastUsernames.contains(playerNamex) != this.completionPlayerCache.contains(playerNamex);

               for(String playerName : this.completionPlayerCache) {
                  if (!Objects.equals(playerName, this.mc.field_1724.method_5477().getString()) && !playerName.contains(" ") && playerName.length() >= 3 && playerName.length() <= 16 && joinedOrQuit.test(playerName)) {
                     this.info("Player joined: " + playerName, new Object[0]);
                  }
               }

               for(String playerName : lastUsernames) {
                  if (!Objects.equals(playerName, this.mc.field_1724.method_5477().getString()) && !playerName.contains(" ") && playerName.length() >= 3 && playerName.length() <= 16 && joinedOrQuit.test(playerName)) {
                     this.info("Player left: " + playerName, new Object[0]);
                  }
               }

               this.completionIDs.remove(packet.comp_2262());
               event.cancel();
            }
         }
      }

   }

   @EventHandler
   private void onReceiveMessage(ReceiveMessageEvent event) {
      this.messageCache.add(event.getMessage().getString());
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      ++this.timer;
      if (this.timer >= (Integer)this.interval.get()) {
         switch (((Mode)this.mode.get()).ordinal()) {
            case 0:
               Map<UUID, String> oldPlayers = Map.copyOf(this.playerCache);
               this.playerCache = (Map)this.mc.method_1562().method_2880().stream().collect(Collectors.toMap((e) -> e.method_2966().id(), (e) -> e.method_2966().name()));

               for(UUID uuid : oldPlayers.keySet()) {
                  if (!this.playerCache.containsKey(uuid)) {
                     String name = (String)oldPlayers.get(uuid);
                     if (!name.contains(" ") && name.length() >= 3 && name.length() <= 16 && this.messageCache.stream().noneMatch((s) -> s.contains(name))) {
                        this.warning(name + " has gone into vanish.", new Object[0]);
                     }
                  }
               }
               break;
            case 1:
               int id = this.random.nextInt(200);
               this.completionIDs.add(id);
               this.mc.method_1562().method_52787(new class_2805(id, (String)this.command.get() + " "));
         }

         this.timer = 0;
         this.messageCache.clear();
      }
   }

   public static enum Mode {
      LeaveMessage,
      RealJoinMessage;

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{LeaveMessage, RealJoinMessage};
      }
   }
}
