package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.utils.RejectsUtils;
import com.google.common.collect.Streams;
import java.util.stream.Stream;
import meteordevelopment.meteorclient.events.entity.player.PlayerMoveEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_2596;
import net.minecraft.class_265;
import net.minecraft.class_2828;
import net.minecraft.class_4970;

public class FullFlight extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgAntiKick;
   private final Setting<Double> speed;
   private final Setting<Boolean> verticalSpeedMatch;
   private final Setting<AntiKickMode> antiKickMode;
   private int delayLeft;
   private double lastPacketY;
   private int floatingTicks;

   public FullFlight() {
      super(MeteorRejectsAddon.CATEGORY, "fullflight", "FullFlight.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgAntiKick = this.settings.createGroup("Anti Kick");
      this.speed = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("speed")).description("Your speed when flying.")).defaultValue(0.3).min((double)0.0F).sliderMax((double)10.0F).build());
      this.verticalSpeedMatch = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("vertical-speed-match")).description("Matches your vertical speed to your horizontal speed, otherwise uses vanilla ratio.")).defaultValue(false)).build());
      this.antiKickMode = this.sgAntiKick.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("mode")).description("The mode for anti kick.")).defaultValue(FullFlight.AntiKickMode.PaperNew)).build());
      this.delayLeft = 20;
      this.lastPacketY = Double.MAX_VALUE;
      this.floatingTicks = 0;
   }

   private double calculateGround() {
      for(double ground = this.mc.field_1724.method_23318(); ground > (double)0.0F; ground -= 0.05) {
         class_238 box = this.mc.field_1724.method_5829();
         class_238 adjustedBox = box.method_989((double)0.0F, ground - this.mc.field_1724.method_23318(), (double)0.0F);
         Stream<class_265> blockCollisions = Streams.stream(this.mc.field_1687.method_20812(this.mc.field_1724, adjustedBox));
         if (blockCollisions.findAny().isPresent()) {
            return ground + 0.05;
         }
      }

      return (double)0.0F;
   }

   private boolean isEntityOnAir(class_1297 entity) {
      return this.mc.field_1687.method_29546(entity.method_5829().method_1014((double)0.0625F).method_1012((double)0.0F, -0.55, (double)0.0F)).allMatch(class_4970.class_4971::method_26215);
   }

   private boolean shouldFlyDown(double currentY, double lastY) {
      if (currentY >= lastY) {
         return true;
      } else {
         return lastY - currentY < 0.0313;
      }
   }

   private class_2828 antiKickPacket(class_2828 packet, double currentY) {
      if (this.delayLeft <= 0 && this.lastPacketY != Double.MAX_VALUE && this.shouldFlyDown(currentY, this.lastPacketY) && this.isEntityOnAir(this.mc.field_1724)) {
         double newY = this.lastPacketY - 0.0313;
         this.lastPacketY = newY;
         this.delayLeft = 20;
         return (class_2828)(packet.method_36172() ? new class_2828.class_2830(packet.method_12269((double)0.0F), newY, packet.method_12274((double)0.0F), packet.method_12271(0.0F), packet.method_12270(0.0F), packet.method_12273(), packet.method_61225()) : new class_2828.class_2829(packet.method_12269((double)0.0F), newY, packet.method_12274((double)0.0F), packet.method_12273(), packet.method_61225()));
      } else {
         this.lastPacketY = currentY;
         if (!this.isEntityOnAir(this.mc.field_1724)) {
            this.delayLeft = 20;
         }

         if (this.delayLeft > 0) {
            --this.delayLeft;
         }

         return packet;
      }
   }

   @EventHandler
   private void onSendPacket(PacketEvent.Send event) {
      if (this.mc.field_1724.method_5854() != null) {
         class_2596 var3 = event.packet;
         if (var3 instanceof class_2828) {
            class_2828 packet = (class_2828)var3;
            if (this.antiKickMode.get() == FullFlight.AntiKickMode.PaperNew) {
               double currentY = packet.method_12268(Double.MAX_VALUE);
               class_2828 modifiedPacket;
               if (currentY != Double.MAX_VALUE) {
                  modifiedPacket = this.antiKickPacket(packet, currentY);
               } else {
                  class_2828 fullPacket;
                  if (packet.method_36172()) {
                     fullPacket = new class_2828.class_2830(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318(), this.mc.field_1724.method_23321(), packet.method_12271(0.0F), packet.method_12270(0.0F), packet.method_12273(), packet.method_61225());
                  } else {
                     fullPacket = new class_2828.class_2829(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318(), this.mc.field_1724.method_23321(), packet.method_12273(), packet.method_61225());
                  }

                  modifiedPacket = this.antiKickPacket(fullPacket, this.mc.field_1724.method_23318());
               }

               if (modifiedPacket != packet) {
                  event.cancel();
                  this.mc.method_1562().method_52787(modifiedPacket);
               }

               return;
            }
         }
      }

   }

   @EventHandler
   private void onPlayerMove(PlayerMoveEvent event) {
      if (this.floatingTicks >= 20) {
         switch (((AntiKickMode)this.antiKickMode.get()).ordinal()) {
            case 0:
               class_238 box = this.mc.field_1724.method_5829();
               class_238 adjustedBox = box.method_989((double)0.0F, -0.4, (double)0.0F);
               Stream<class_265> blockCollisions = Streams.stream(this.mc.field_1687.method_20812(this.mc.field_1724, adjustedBox));
               if (blockCollisions.findAny().isPresent()) {
                  break;
               }

               double ground = this.calculateGround();
               double groundExtra = ground + 0.1;

               for(double posY = this.mc.field_1724.method_23318(); posY > groundExtra; posY -= (double)4.0F) {
                  this.mc.method_1562().method_52787(new class_2828.class_2829(this.mc.field_1724.method_23317(), posY, this.mc.field_1724.method_23321(), true, this.mc.field_1724.field_5976));
                  if (posY - (double)4.0F < groundExtra) {
                     break;
                  }
               }

               this.mc.method_1562().method_52787(new class_2828.class_2829(this.mc.field_1724.method_23317(), groundExtra, this.mc.field_1724.method_23321(), true, this.mc.field_1724.field_5976));

               for(double posY = groundExtra; posY < this.mc.field_1724.method_23318(); posY += (double)4.0F) {
                  this.mc.method_1562().method_52787(new class_2828.class_2829(this.mc.field_1724.method_23317(), posY, this.mc.field_1724.method_23321(), this.mc.field_1724.method_24828(), this.mc.field_1724.field_5976));
                  if (posY + (double)4.0F > this.mc.field_1724.method_23318()) {
                     break;
                  }
               }

               this.mc.method_1562().method_52787(new class_2828.class_2829(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318(), this.mc.field_1724.method_23321(), this.mc.field_1724.method_24828(), this.mc.field_1724.field_5976));
               break;
            case 1:
               class_238 box = this.mc.field_1724.method_5829();
               class_238 adjustedBox = box.method_989((double)0.0F, -0.4, (double)0.0F);
               Stream<class_265> blockCollisions = Streams.stream(this.mc.field_1687.method_20812(this.mc.field_1724, adjustedBox));
               if (!blockCollisions.findAny().isPresent()) {
                  this.mc.method_1562().method_52787(new class_2828.class_2829(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318() - 0.4, this.mc.field_1724.method_23321(), this.mc.field_1724.method_24828(), this.mc.field_1724.field_5976));
                  this.mc.method_1562().method_52787(new class_2828.class_2829(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318(), this.mc.field_1724.method_23321(), this.mc.field_1724.method_24828(), this.mc.field_1724.field_5976));
               }
         }

         this.floatingTicks = 0;
      }

      float ySpeed = RejectsUtils.fullFlightMove(event, (Double)this.speed.get(), (Boolean)this.verticalSpeedMatch.get());
      if (this.floatingTicks < 20) {
         if ((double)ySpeed >= -0.1) {
            ++this.floatingTicks;
         } else if (this.antiKickMode.get() == FullFlight.AntiKickMode.New) {
            this.floatingTicks = 0;
         }
      }

   }

   public static enum AntiKickMode {
      Old,
      New,
      PaperNew,
      None;

      // $FF: synthetic method
      private static AntiKickMode[] $values() {
         return new AntiKickMode[]{Old, New, PaperNew, None};
      }
   }
}
