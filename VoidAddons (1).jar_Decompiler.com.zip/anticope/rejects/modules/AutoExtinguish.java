package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.concurrent.atomic.AtomicInteger;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.world.BlockIterator;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_2846.class_2847;

public class AutoExtinguish extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgBucket;
   private final Setting<Boolean> extinguish;
   private final Setting<Integer> horizontalRadius;
   private final Setting<Integer> verticalRadius;
   private final Setting<Integer> maxBlockPerTick;
   private final Setting<Boolean> waterBucket;
   private final Setting<Boolean> center;
   private final Setting<Boolean> onGround;
   private boolean hasPlacedWater;
   private class_2338 blockPos;
   private boolean doesWaterBucketWork;
   private static final class_1291 FIRE_RESISTANCE;

   public AutoExtinguish() {
      super(MeteorRejectsAddon.CATEGORY, "auto-extinguish", "Automatically extinguishes fire around you");
      this.sgGeneral = this.settings.createGroup("Extinguish Fire around you");
      this.sgBucket = this.settings.createGroup("Extinguish yourself");
      this.extinguish = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("extinguish")).description("Automatically extinguishes fire around you.")).defaultValue(false)).build());
      this.horizontalRadius = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("horizontal-radius")).description("Horizontal radius in which to search for fire.")).defaultValue(4)).min(0).sliderMax(6).build());
      this.verticalRadius = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("vertical-radius")).description("Vertical radius in which to search for fire.")).defaultValue(4)).min(0).sliderMax(6).build());
      this.maxBlockPerTick = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("block-per-tick")).description("Maximum amount of Blocks to extinguish per tick.")).defaultValue(5)).min(1).sliderMax(50).build());
      this.waterBucket = this.sgBucket.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("water")).description("Automatically places water when you are on fire (and don't have fire resistance).")).defaultValue(false)).build());
      this.center = this.sgBucket.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("center")).description("Automatically centers you when placing water.")).defaultValue(false)).build());
      this.onGround = this.sgBucket.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("on-ground")).description("Only place when you are on ground.")).defaultValue(false)).build());
      this.hasPlacedWater = false;
      this.blockPos = null;
      this.doesWaterBucketWork = true;
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      if (this.mc.field_1687.method_27983() == class_1937.field_25180) {
         if (this.doesWaterBucketWork) {
            this.warning("Water Buckets don't work in this dimension!", new Object[0]);
            this.doesWaterBucketWork = false;
         }
      } else if (!this.doesWaterBucketWork) {
         this.warning("Enabled Water Buckets!", new Object[0]);
         this.doesWaterBucketWork = true;
      }

      if (!(Boolean)this.onGround.get() || this.mc.field_1724.method_24828()) {
         if ((Boolean)this.waterBucket.get() && this.doesWaterBucketWork) {
            if (this.hasPlacedWater) {
               int slot = this.findSlot(class_1802.field_8550);
               this.blockPos = this.mc.field_1724.method_24515();
               this.place(slot);
               this.hasPlacedWater = false;
            } else if (!this.mc.field_1724.method_6059(class_7923.field_41174.method_47983(FIRE_RESISTANCE)) && this.mc.field_1724.method_5809()) {
               this.blockPos = this.mc.field_1724.method_24515();
               int slot = this.findSlot(class_1802.field_8705);
               if (this.mc.field_1687.method_8320(this.blockPos).method_26204() == class_2246.field_10036 || this.mc.field_1687.method_8320(this.blockPos).method_26204() == class_2246.field_22089) {
                  float yaw = this.mc.field_1773.method_19418().method_19330() % 360.0F;
                  float pitch = this.mc.field_1773.method_19418().method_19329() % 360.0F;
                  if ((Boolean)this.center.get()) {
                     PlayerUtils.centerPlayer();
                  }

                  Rotations.rotate((double)yaw, (double)90.0F);
                  this.mc.method_1562().method_52787(new class_2846(class_2847.field_12968, this.blockPos, class_2350.field_11036));
                  this.mc.field_1724.method_6104(class_1268.field_5808);
                  this.mc.method_1562().method_52787(new class_2846(class_2847.field_12973, this.blockPos, class_2350.field_11036));
                  Rotations.rotate((double)yaw, (double)pitch);
               }

               this.place(slot);
               this.hasPlacedWater = true;
            }
         }

         if ((Boolean)this.extinguish.get()) {
            AtomicInteger blocksPerTick = new AtomicInteger();
            BlockIterator.register((Integer)this.horizontalRadius.get(), (Integer)this.verticalRadius.get(), (blockPos, blockState) -> {
               if (blocksPerTick.get() <= (Integer)this.maxBlockPerTick.get() && (blockState.method_26204() == class_2246.field_10036 || this.mc.field_1687.method_8320(blockPos).method_26204() == class_2246.field_22089)) {
                  this.extinguishFire(blockPos);
                  blocksPerTick.getAndIncrement();
               }

            });
         }

      }
   }

   private void place(int slot) {
      if (slot != -1) {
         int preSlot = this.mc.field_1724.method_31548().method_67532();
         if ((Boolean)this.center.get()) {
            PlayerUtils.centerPlayer();
         }

         this.mc.field_1724.method_31548().method_61496(slot);
         float yaw = this.mc.field_1773.method_19418().method_19330() % 360.0F;
         float pitch = this.mc.field_1773.method_19418().method_19329() % 360.0F;
         Rotations.rotate((double)yaw, (double)90.0F);
         this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5808);
         this.mc.field_1724.method_31548().method_61496(preSlot);
         Rotations.rotate((double)yaw, (double)pitch);
      }

   }

   private void extinguishFire(class_2338 blockPos) {
      this.mc.method_1562().method_52787(new class_2846(class_2847.field_12968, blockPos, class_2350.field_11036));
      this.mc.field_1724.method_6104(class_1268.field_5808);
      this.mc.method_1562().method_52787(new class_2846(class_2847.field_12973, blockPos, class_2350.field_11036));
   }

   private int findSlot(class_1792 item) {
      int slot = -1;

      for(int i = 0; i < 9; ++i) {
         class_1799 block = this.mc.field_1724.method_31548().method_5438(i);
         if (block.method_7909() == item) {
            slot = i;
            break;
         }
      }

      return slot;
   }

   static {
      FIRE_RESISTANCE = (class_1291)class_7923.field_41174.method_63535(class_2960.method_60654("fire_resistance"));
   }
}
