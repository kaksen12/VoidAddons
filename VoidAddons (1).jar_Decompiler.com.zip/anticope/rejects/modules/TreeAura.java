package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.utils.WorldUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.IntStream;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.world.CardinalDirection;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2473;
import net.minecraft.class_2885;
import net.minecraft.class_3965;

public class TreeAura extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Boolean> rotation;
   private final Setting<Integer> plantDelay;
   private final Setting<Integer> bonemealDelay;
   private final Setting<Integer> rRange;
   private final Setting<Integer> yRange;
   private final Setting<SortMode> sortMode;
   private int bonemealTimer;
   private int plantTimer;

   public TreeAura() {
      super(MeteorRejectsAddon.CATEGORY, "tree-aura", "Plants trees around you");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.rotation = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("rotate")).description("rotate for block interactions")).defaultValue(false)).build());
      this.plantDelay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("plant-delay")).description("delay between planting trees")).defaultValue(6)).min(0).sliderMax(25).build());
      this.bonemealDelay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("bonemeal-delay")).description("delay between placing bonemeal on trees")).defaultValue(3)).min(0).sliderMax(25).build());
      this.rRange = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("radius")).description("how far you can place horizontally")).defaultValue(4)).min(1).sliderMax(5).build());
      this.yRange = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("y-range")).description("how far you can place vertically")).defaultValue(3)).min(1).sliderMax(5).build());
      this.sortMode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("sort-mode")).description("how to sort nearby trees/placements.")).defaultValue(TreeAura.SortMode.Farthest)).build());
   }

   public void onActivate() {
      this.bonemealTimer = 0;
      this.plantTimer = 0;
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      --this.plantTimer;
      --this.bonemealTimer;
      if (this.plantTimer <= 0) {
         class_2338 plantPos = this.findPlantLocation();
         if (plantPos == null) {
            return;
         }

         this.doPlant(plantPos);
         this.plantTimer = (Integer)this.plantDelay.get();
      }

      if (this.bonemealTimer <= 0) {
         class_2338 p = this.findPlantedSapling();
         if (p == null) {
            return;
         }

         this.doBonemeal(p);
         this.bonemealTimer = (Integer)this.bonemealDelay.get();
      }

   }

   private FindItemResult findBonemeal() {
      return InvUtils.findInHotbar(new class_1792[]{class_1802.field_8324});
   }

   private FindItemResult findSapling() {
      return InvUtils.findInHotbar((itemStack) -> class_2248.method_9503(itemStack.method_7909()) instanceof class_2473);
   }

   private boolean isSapling(class_2338 pos) {
      return this.mc.field_1687.method_8320(pos).method_26204() instanceof class_2473;
   }

   private void doPlant(class_2338 plantPos) {
      FindItemResult sapling = this.findSapling();
      if (!sapling.found()) {
         this.error("No saplings in hotbar", new Object[0]);
         this.toggle();
      } else {
         InvUtils.swap(sapling.slot(), false);
         if ((Boolean)this.rotation.get()) {
            Rotations.rotate(Rotations.getYaw(plantPos), Rotations.getPitch(plantPos), () -> this.mc.field_1724.field_3944.method_52787(new class_2885(class_1268.field_5808, new class_3965(Utils.vec3d(plantPos), class_2350.field_11036, plantPos, false), 0)));
         } else {
            this.mc.field_1724.field_3944.method_52787(new class_2885(class_1268.field_5808, new class_3965(Utils.vec3d(plantPos), class_2350.field_11036, plantPos, false), 0));
         }

      }
   }

   private void doBonemeal(class_2338 sapling) {
      FindItemResult bonemeal = this.findBonemeal();
      if (!bonemeal.found()) {
         this.error("No bonemeal in hotbar", new Object[0]);
         this.toggle();
      } else {
         InvUtils.swap(bonemeal.slot(), false);
         if ((Boolean)this.rotation.get()) {
            Rotations.rotate(Rotations.getYaw(sapling), Rotations.getPitch(sapling), () -> this.mc.field_1724.field_3944.method_52787(new class_2885(class_1268.field_5808, new class_3965(Utils.vec3d(sapling), class_2350.field_11036, sapling, false), 0)));
         } else {
            this.mc.field_1724.field_3944.method_52787(new class_2885(class_1268.field_5808, new class_3965(Utils.vec3d(sapling), class_2350.field_11036, sapling, false), 0));
         }

      }
   }

   private boolean canPlant(class_2338 pos) {
      class_2248 b = this.mc.field_1687.method_8320(pos).method_26204();
      if (!b.equals(class_2246.field_10479) && !b.equals(class_2246.field_10219) && !b.equals(class_2246.field_10566) && !b.equals(class_2246.field_10253)) {
         return false;
      } else {
         AtomicBoolean plant = new AtomicBoolean(true);
         IntStream.rangeClosed(1, 5).forEach((i) -> {
            class_2338 check = pos.method_10086(i);
            if (!this.mc.field_1687.method_8320(check).method_26204().equals(class_2246.field_10124)) {
               plant.set(false);
            } else {
               for(CardinalDirection dir : CardinalDirection.values()) {
                  if (!this.mc.field_1687.method_8320(check.method_10079(dir.toDirection(), i)).method_26204().equals(class_2246.field_10124)) {
                     plant.set(false);
                     return;
                  }
               }

            }
         });
         return plant.get();
      }
   }

   private List<class_2338> findSaplings(class_2338 centerPos, int radius, int height) {
      ArrayList<class_2338> blocc = new ArrayList();

      for(class_2338 b : WorldUtils.getSphere(centerPos, radius, height)) {
         if (this.isSapling(b)) {
            blocc.add(b);
         }
      }

      return blocc;
   }

   private class_2338 findPlantedSapling() {
      List<class_2338> saplings = this.findSaplings(this.mc.field_1724.method_24515(), (Integer)this.rRange.get(), (Integer)this.yRange.get());
      if (saplings.isEmpty()) {
         return null;
      } else {
         saplings.sort(Comparator.comparingDouble(PlayerUtils::distanceTo));
         if (((SortMode)this.sortMode.get()).equals(TreeAura.SortMode.Farthest)) {
            Collections.reverse(saplings);
         }

         return (class_2338)saplings.get(0);
      }
   }

   private List<class_2338> getPlantLocations(class_2338 centerPos, int radius, int height) {
      ArrayList<class_2338> blocc = new ArrayList();

      for(class_2338 b : WorldUtils.getSphere(centerPos, radius, height)) {
         if (this.canPlant(b)) {
            blocc.add(b);
         }
      }

      return blocc;
   }

   private class_2338 findPlantLocation() {
      List<class_2338> nearby = this.getPlantLocations(this.mc.field_1724.method_24515(), (Integer)this.rRange.get(), (Integer)this.yRange.get());
      if (nearby.isEmpty()) {
         return null;
      } else {
         nearby.sort(Comparator.comparingDouble(PlayerUtils::distanceTo));
         if (((SortMode)this.sortMode.get()).equals(TreeAura.SortMode.Farthest)) {
            Collections.reverse(nearby);
         }

         return (class_2338)nearby.get(0);
      }
   }

   public static enum SortMode {
      Closest,
      Farthest;

      // $FF: synthetic method
      private static SortMode[] $values() {
         return new SortMode[]{Closest, Farthest};
      }
   }
}
