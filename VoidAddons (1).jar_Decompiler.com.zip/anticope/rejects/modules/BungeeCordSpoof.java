package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.mixin.HandshakeC2SPacketAccessor;
import com.google.gson.Gson;
import com.mojang.authlib.properties.PropertyMap;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringListSetting;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2596;
import net.minecraft.class_2889;
import net.minecraft.class_8592;

public class BungeeCordSpoof extends Module {
   private final SettingGroup sgGeneral;
   private static final Gson GSON = new Gson();
   private final Setting<Boolean> whitelist;
   private final Setting<List<String>> whitelistedServers;
   private final Setting<Boolean> spoofProfile;
   private final Setting<String> forwardedIP;

   public BungeeCordSpoof() {
      super(MeteorRejectsAddon.CATEGORY, "bungeeCord-spoof", "Let you join BungeeCord servers, useful when bypassing proxies.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.whitelist = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("whitelist")).description("Use whitelist.")).defaultValue(false)).build());
      SettingGroup var10001 = this.sgGeneral;
      StringListSetting.Builder var10002 = (StringListSetting.Builder)((StringListSetting.Builder)(new StringListSetting.Builder()).name("whitelisted-servers")).description("Will only work if you joined the servers above.");
      Setting var10003 = this.whitelist;
      Objects.requireNonNull(var10003);
      this.whitelistedServers = var10001.add(((StringListSetting.Builder)var10002.visible(var10003::get)).build());
      this.spoofProfile = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("spoof-profile")).description("Spoof account profile.")).defaultValue(false)).build());
      this.forwardedIP = this.sgGeneral.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("forwarded-IP")).description("The forwarded IP address.")).defaultValue("127.0.0.1")).build());
      this.runInMainMenu = true;
   }

   @EventHandler
   private void onPacketSend(PacketEvent.Send event) {
      class_2596 var3 = event.packet;
      if (var3 instanceof class_2889 packet) {
         if (packet.comp_1566() == class_8592.field_44975) {
            if ((Boolean)this.whitelist.get() && !((List)this.whitelistedServers.get()).contains(Utils.getWorldName())) {
               return;
            }

            String var10000 = packet.comp_1564();
            String address = var10000 + "\u0000" + String.valueOf(this.forwardedIP) + "\u0000" + this.mc.method_1548().method_44717().toString().replace("-", "") + ((Boolean)this.spoofProfile.get() ? this.getProperty() : "");
            ((HandshakeC2SPacketAccessor)packet).setHostName(address);
         }
      }

   }

   private String getProperty() {
      PropertyMap propertyMap = this.mc.method_53462().properties();
      Gson var10000 = GSON;
      return "\u0000" + var10000.toJson(propertyMap.values().toArray());
   }
}
