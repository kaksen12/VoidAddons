package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.player.AutoEat;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_9334;

public class ObsidianFarm extends Module {
   private boolean allowBreakAgain;

   public ObsidianFarm() {
      super(MeteorRejectsAddon.CATEGORY, "obsidian-farm", "Auto obsidian farm(portals).");
   }

   public void onActivate() {
      this.allowBreakAgain = true;
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      if (this.mc.field_1724 != null) {
         if (this.mc.field_1687 != null) {
            if (this.mc.field_1761 != null) {
               if (this.mc.field_1687.method_27983() == class_1937.field_25180) {
                  this.allowBreakAgain = true;
               } else if (this.allowBreakAgain) {
                  if (!this.mc.field_1724.method_6115() && !((AutoEat)Modules.get().get(AutoEat.class)).isActive() || !this.mc.field_1724.method_6079().method_57826(class_9334.field_50075) && !this.mc.field_1724.method_6047().method_57826(class_9334.field_50075)) {
                     if (this.mc.field_1724.method_6047().method_7909() != class_1802.field_22024 && this.mc.field_1724.method_6047().method_7909() != class_1802.field_8377) {
                        int pickAxe = this.findPickAxe();
                        if (pickAxe == -1 && this.isActive()) {
                           this.toggle();
                           return;
                        }

                        this.mc.field_1724.method_31548().method_61496(pickAxe);
                     }

                     class_2338 obsidian = this.findObsidian();
                     if (obsidian != null) {
                        this.mc.field_1761.method_2902(obsidian, class_2350.field_11036);
                        this.mc.field_1724.method_6104(class_1268.field_5808);
                        if (this.mc.field_1724.method_24515().method_10074().equals(obsidian) && this.mc.field_1687.method_8320(obsidian).method_26204() != class_2246.field_10540) {
                           this.allowBreakAgain = false;
                        }

                     }
                  }
               }
            }
         }
      }
   }

   private class_2338 findObsidian() {
      List<class_2338> blocksList = new ArrayList();

      for(int x = -2; x < 3; ++x) {
         for(int z = -2; z < 3; ++z) {
            int y = 2;
            class_2338 block = new class_2338(this.mc.field_1724.method_24515().method_10263() + x, this.mc.field_1724.method_24515().method_10264() + y, this.mc.field_1724.method_24515().method_10260() + z);
            blocksList.add(block);
         }
      }

      Optional<class_2338> result = ((Stream)blocksList.stream().parallel()).filter((blockPos) -> this.mc.field_1687.method_8320(blockPos).method_26204() == class_2246.field_10540).min(Comparator.comparingDouble((blockPos) -> this.mc.field_1724.method_5649((double)blockPos.method_10263(), (double)blockPos.method_10264(), (double)blockPos.method_10260())));
      if (result.isPresent()) {
         return (class_2338)result.get();
      } else {
         blocksList.clear();

         for(int x = -2; x < 3; ++x) {
            for(int z = -2; z < 3; ++z) {
               for(int y = 3; y > -2; --y) {
                  class_2338 block = new class_2338(this.mc.field_1724.method_24515().method_10263() + x, this.mc.field_1724.method_24515().method_10264() + y, this.mc.field_1724.method_24515().method_10260() + z);
                  blocksList.add(block);
               }
            }
         }

         Optional<class_2338> result2 = ((Stream)blocksList.stream().parallel()).filter((blockPos) -> !this.mc.field_1724.method_24515().method_10074().equals(blockPos)).filter((blockPos) -> this.mc.field_1687.method_8320(blockPos).method_26204() == class_2246.field_10540).min(Comparator.comparingDouble((blockPos) -> this.mc.field_1724.method_5649((double)blockPos.method_10263(), (double)blockPos.method_10264(), (double)blockPos.method_10260())));
         if (result2.isPresent()) {
            return (class_2338)result2.get();
         } else if (this.mc.field_1687.method_8320(this.mc.field_1724.method_24515().method_10074()).method_26204() == class_2246.field_10540) {
            return this.mc.field_1724.method_24515().method_10074();
         } else {
            return null;
         }
      }
   }

   private int findPickAxe() {
      for(int i = 0; i < 9; ++i) {
         if (this.mc.field_1724.method_31548().method_5438(i).method_7909() == class_1802.field_22024) {
            return i;
         }

         if (this.mc.field_1724.method_31548().method_5438(i).method_7909() == class_1802.field_8377) {
            return i;
         }
      }

      return -1;
   }
}
