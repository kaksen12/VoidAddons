package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import net.minecraft.class_279;
import net.minecraft.class_2960;
import net.minecraft.class_9960;

public class Rendering extends Module {
   private final SettingGroup sgInvisible;
   private final SettingGroup sgFun;
   private final Setting<Boolean> structureVoid;
   private final Setting<Shader> shaderEnum;
   private final Setting<Boolean> dinnerbone;
   private final Setting<Boolean> deadmau5Ears;
   private final Setting<Boolean> christmas;
   private class_279 shader;

   public Rendering() {
      super(MeteorRejectsAddon.CATEGORY, "rendering", "Various Render Tweaks");
      this.sgInvisible = this.settings.createGroup("Invisible");
      this.sgFun = this.settings.createGroup("Fun");
      this.structureVoid = this.sgInvisible.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("structure-void")).description("Render structure void blocks.")).defaultValue(true)).onChanged((onChanged) -> {
         if (this.isActive()) {
            this.mc.field_1769.method_3279();
         }

      })).build());
      this.shaderEnum = this.sgFun.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("shader")).description("Select which shader to use")).defaultValue(Rendering.Shader.None)).onChanged(this::onChanged)).build());
      this.dinnerbone = this.sgFun.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("dinnerbone")).description("Apply dinnerbone effects to all entities")).defaultValue(false)).build());
      this.deadmau5Ears = this.sgFun.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("deadmau5-ears")).description("Add deadmau5 ears to all players")).defaultValue(false)).build());
      this.christmas = this.sgFun.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("christmas")).description("Chistmas chest anytime")).defaultValue(false)).build());
      this.shader = null;
   }

   public void onActivate() {
      this.mc.field_1769.method_3279();
   }

   public void onDeactivate() {
      this.mc.field_1769.method_3279();
   }

   public void onChanged(Shader s) {
      if (this.mc.field_1687 != null) {
         String name = s.toString().toLowerCase();
         if (name.equals("none")) {
            this.shader = null;
         } else {
            class_2960 shaderID = class_2960.method_60656(name);
            this.shader = this.mc.method_62887().method_62941(shaderID, class_9960.field_53902);
         }
      }
   }

   public boolean renderStructureVoid() {
      return this.isActive() && (Boolean)this.structureVoid.get();
   }

   public class_279 getShaderEffect() {
      return !this.isActive() ? null : this.shader;
   }

   public boolean dinnerboneEnabled() {
      return !this.isActive() ? false : (Boolean)this.dinnerbone.get();
   }

   public boolean deadmau5EarsEnabled() {
      return !this.isActive() ? false : (Boolean)this.deadmau5Ears.get();
   }

   public boolean chistmas() {
      return !this.isActive() ? false : (Boolean)this.christmas.get();
   }

   public static enum Shader {
      None,
      Blur,
      Creeper,
      Invert,
      Spider;

      // $FF: synthetic method
      private static Shader[] $values() {
         return new Shader[]{None, Blur, Creeper, Invert, Spider};
      }
   }
}
