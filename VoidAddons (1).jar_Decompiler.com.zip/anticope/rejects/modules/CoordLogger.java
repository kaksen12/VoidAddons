package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.UUID;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1321;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2673;
import net.minecraft.class_2777;
import net.minecraft.class_5250;

public class CoordLogger extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgTeleports;
   private final SettingGroup sgWorldEvents;
   private final Setting<Double> minDistance;
   private final Setting<Boolean> players;
   private final Setting<Boolean> wolves;
   private final Setting<Boolean> enderDragons;
   private final Setting<Boolean> endPortals;
   private final Setting<Boolean> withers;
   private final Setting<Boolean> otherEvents;

   public CoordLogger() {
      super(MeteorRejectsAddon.CATEGORY, "coord-logger", "Logs coordinates of various events. Might not work on Spigot/Paper servers.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgTeleports = this.settings.createGroup("Teleports");
      this.sgWorldEvents = this.settings.createGroup("World Events");
      this.minDistance = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("minimum-distance")).description("Minimum distance to log event.")).min((double)5.0F).max((double)100.0F).sliderMin((double)5.0F).sliderMax((double)100.0F).defaultValue((double)10.0F).build());
      this.players = this.sgTeleports.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("players")).description("Logs player teleports.")).defaultValue(true)).build());
      this.wolves = this.sgTeleports.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("wolves")).description("Logs wolf teleports.")).defaultValue(false)).build());
      this.enderDragons = this.sgWorldEvents.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("ender-dragons")).description("Logs killed ender dragons.")).defaultValue(false)).build());
      this.endPortals = this.sgWorldEvents.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("end-portals")).description("Logs opened end portals.")).defaultValue(false)).build());
      this.withers = this.sgWorldEvents.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("withers")).description("Logs wither spawns.")).defaultValue(false)).build());
      this.otherEvents = this.sgWorldEvents.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("other-global-events")).description("Logs other global events.")).defaultValue(false)).build());
   }

   @EventHandler
   private void onPacketReceive(PacketEvent.Receive event) {
      if (event.packet instanceof class_2777) {
         class_2777 packet = (class_2777)event.packet;

         try {
            class_1297 entity = this.mc.field_1687.method_8469(packet.comp_3237());
            if (entity.method_5864().equals(class_1299.field_6097) && (Boolean)this.players.get()) {
               class_243 packetPosition = packet.comp_3238().comp_3148();
               class_243 playerPosition = new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321());
               if (playerPosition.method_1022(packetPosition) >= (Double)this.minDistance.get()) {
                  this.info(this.formatMessage("Player '" + entity.method_5820() + "' has teleported to ", packetPosition));
               }
            } else if (entity.method_5864().equals(class_1299.field_6055) && (Boolean)this.wolves.get()) {
               class_243 packetPosition = packet.comp_3238().comp_3148();
               class_243 wolfPosition = new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321());
               UUID ownerUuid = ((class_1321)entity).method_35057() != null ? ((class_1321)entity).method_35057().method_5667() : null;
               if (ownerUuid != null && wolfPosition.method_1022(packetPosition) >= (Double)this.minDistance.get()) {
                  this.info(this.formatMessage("Wolf has teleported to ", packetPosition));
               }
            }
         } catch (NullPointerException var7) {
         }
      } else if (event.packet instanceof class_2673) {
         class_2673 worldEventS2CPacket = (class_2673)event.packet;
         if (worldEventS2CPacket.method_11533()) {
            if (PlayerUtils.distanceTo(worldEventS2CPacket.method_11531()) <= (Double)this.minDistance.get()) {
               return;
            }

            switch (worldEventS2CPacket.method_11532()) {
               case 1023:
                  if ((Boolean)this.withers.get()) {
                     this.info(this.formatMessage("Wither spawned at ", worldEventS2CPacket.method_11531()));
                  }
                  break;
               case 1028:
                  if ((Boolean)this.enderDragons.get()) {
                     this.info(this.formatMessage("Ender dragon killed at ", worldEventS2CPacket.method_11531()));
                  }
                  break;
               case 1038:
                  if ((Boolean)this.endPortals.get()) {
                     this.info(this.formatMessage("End portal opened at ", worldEventS2CPacket.method_11531()));
                  }
                  break;
               default:
                  if ((Boolean)this.otherEvents.get()) {
                     this.info(this.formatMessage("Unknown global event at ", worldEventS2CPacket.method_11531()));
                  }
            }
         }
      }

   }

   public class_5250 formatMessage(String message, class_243 coords) {
      class_5250 text = class_2561.method_43470(message);
      text.method_10852(ChatUtils.formatCoords(coords));
      text.method_27693(String.valueOf(class_124.field_1080) + ".");
      return text;
   }

   public class_5250 formatMessage(String message, class_2338 coords) {
      return this.formatMessage(message, new class_243((double)coords.method_10263(), (double)coords.method_10264(), (double)coords.method_10260()));
   }
}
