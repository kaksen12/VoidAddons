package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

public class Lavacast extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgShape;
   private final Setting<Integer> tickInterval;
   private final Setting<Integer> distMin;
   private final Setting<Integer> lavaDownMult;
   private final Setting<Integer> lavaUpMult;
   private final Setting<Integer> waterDownMult;
   private final Setting<Integer> waterUpMult;
   private int dist;
   private class_2338 placeFluidPos;
   private int tick;
   private Stage stage;

   public Lavacast() {
      super(MeteorRejectsAddon.CATEGORY, "lavacast", "Automatically Lavacasts");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgShape = this.settings.createGroup("Shape", false);
      this.tickInterval = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("tick-interval")).description("Interval")).defaultValue(2)).min(0).sliderMax(20).build());
      this.distMin = this.sgShape.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("minimum-distance")).description("Top plane cutoff")).defaultValue(5)).min(0).sliderMax(10).build());
      this.lavaDownMult = this.sgShape.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("lava-down-mulipiler")).description("Controls the shape of the cast")).defaultValue(40)).min(1).sliderMax(100).build());
      this.lavaUpMult = this.sgShape.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("lava-up-mulipiler")).description("Controls the shape of the cast")).defaultValue(8)).min(1).sliderMax(100).build());
      this.waterDownMult = this.sgShape.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("water-down-mulipiler")).description("Controls the shape of the cast")).defaultValue(4)).min(1).sliderMax(100).build());
      this.waterUpMult = this.sgShape.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("water-up-mulipiler")).description("Controls the shape of the cast")).defaultValue(1)).min(1).sliderMax(100).build());
      this.stage = Lavacast.Stage.None;
   }

   public void onActivate() {
      if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
         this.toggle();
      }

      this.tick = 0;
      this.stage = Lavacast.Stage.None;
      this.placeFluidPos = this.getTargetBlockPos();
      if (this.placeFluidPos == null) {
         this.placeFluidPos = this.mc.field_1724.method_24515().method_10087(2);
      } else {
         this.placeFluidPos = this.placeFluidPos.method_10084();
      }

      this.dist = -1;
      this.getDistance(new class_2382(1, 0, 0));
      this.getDistance(new class_2382(-1, 0, 0));
      this.getDistance(new class_2382(0, 0, 1));
      this.getDistance(new class_2382(0, 0, -1));
      if (this.dist < 1) {
         this.error("Couldn't locate bottom.", new Object[0]);
         this.toggle();
      } else {
         this.info("Distance: (highlight)%d(default).", new Object[]{this.dist});
      }
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null) {
         ++this.tick;
         if (!this.shouldBreakOnTick()) {
            if (this.dist < (Integer)this.distMin.get()) {
               this.toggle();
            }

            this.tick = 0;
            if (!this.checkMineBlock()) {
               switch (this.stage.ordinal()) {
                  case 0:
                     Rotations.rotate(Rotations.getYaw(this.placeFluidPos), Rotations.getPitch(this.placeFluidPos), 100, this::placeLava);
                     this.stage = Lavacast.Stage.LavaDown;
                     break;
                  case 1:
                     Rotations.rotate(Rotations.getYaw(this.placeFluidPos), Rotations.getPitch(this.placeFluidPos), 100, this::pickupLiquid);
                     this.stage = Lavacast.Stage.LavaUp;
                     break;
                  case 2:
                     Rotations.rotate(Rotations.getYaw(this.placeFluidPos), Rotations.getPitch(this.placeFluidPos), 100, this::placeWater);
                     this.stage = Lavacast.Stage.WaterDown;
                     break;
                  case 3:
                     Rotations.rotate(Rotations.getYaw(this.placeFluidPos), Rotations.getPitch(this.placeFluidPos), 100, this::pickupLiquid);
                     this.stage = Lavacast.Stage.WaterUp;
                     break;
                  case 4:
                     --this.dist;
                     Rotations.rotate(Rotations.getYaw(this.placeFluidPos), Rotations.getPitch(this.placeFluidPos), 100, this::placeLava);
                     this.stage = Lavacast.Stage.LavaDown;
               }

            }
         }
      }
   }

   private boolean shouldBreakOnTick() {
      if (this.stage == Lavacast.Stage.LavaDown && this.tick < this.dist * (Integer)this.lavaDownMult.get()) {
         return true;
      } else if (this.stage == Lavacast.Stage.LavaUp && this.tick < this.dist * (Integer)this.lavaUpMult.get()) {
         return true;
      } else if (this.stage == Lavacast.Stage.WaterDown && this.tick < this.dist * (Integer)this.waterDownMult.get()) {
         return true;
      } else if (this.stage == Lavacast.Stage.WaterUp && this.tick < this.dist * (Integer)this.waterUpMult.get()) {
         return true;
      } else {
         return this.tick < (Integer)this.tickInterval.get();
      }
   }

   private boolean checkMineBlock() {
      if (this.stage == Lavacast.Stage.None && this.mc.field_1687.method_8320(this.placeFluidPos).method_26204() != class_2246.field_10124) {
         Rotations.rotate(Rotations.getYaw(this.placeFluidPos), Rotations.getPitch(this.placeFluidPos), 100, this::updateBlockBreakingProgress);
         return true;
      } else {
         return false;
      }
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.placeFluidPos != null) {
         double x1 = (double)this.placeFluidPos.method_10263();
         double y1 = (double)this.placeFluidPos.method_10264();
         double z1 = (double)this.placeFluidPos.method_10260();
         double x2 = x1 + (double)1.0F;
         double y2 = y1 + (double)1.0F;
         double z2 = z1 + (double)1.0F;
         SettingColor lineColor = new SettingColor(128, 128, 128);
         if (this.stage == Lavacast.Stage.LavaDown) {
            lineColor = new SettingColor(255, 180, 10);
         }

         if (this.stage == Lavacast.Stage.LavaUp) {
            lineColor = new SettingColor(255, 180, 128);
         }

         if (this.stage == Lavacast.Stage.WaterDown) {
            lineColor = new SettingColor(10, 10, 255);
         }

         if (this.stage == Lavacast.Stage.WaterUp) {
            lineColor = new SettingColor(128, 128, 255);
         }

         SettingColor sideColor = new SettingColor(lineColor.r, lineColor.g, lineColor.b, 75);
         event.renderer.box(x1, y1, z1, x2, y2, z2, sideColor, lineColor, ShapeMode.Both, 0);
      }
   }

   private void placeLava() {
      FindItemResult findItemResult = InvUtils.findInHotbar(new class_1792[]{class_1802.field_8187});
      if (!findItemResult.found()) {
         this.error("No lava bucket found.", new Object[0]);
         this.toggle();
      } else {
         InvUtils.swap(findItemResult.slot(), true);
         this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5808);
         InvUtils.swapBack();
      }
   }

   private void placeWater() {
      FindItemResult findItemResult = InvUtils.findInHotbar(new class_1792[]{class_1802.field_8705});
      if (!findItemResult.found()) {
         this.error("No water bucket found.", new Object[0]);
         this.toggle();
      } else {
         InvUtils.swap(findItemResult.slot(), true);
         this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5808);
         InvUtils.swapBack();
      }
   }

   private void pickupLiquid() {
      FindItemResult findItemResult = InvUtils.findInHotbar(new class_1792[]{class_1802.field_8550});
      if (!findItemResult.found()) {
         this.error("No bucket found.", new Object[0]);
         this.toggle();
      } else {
         InvUtils.swap(findItemResult.slot(), true);
         this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5808);
         InvUtils.swapBack();
      }
   }

   private void updateBlockBreakingProgress() {
      this.mc.field_1761.method_2902(this.placeFluidPos, class_2350.field_11036);
   }

   private class_2338 getTargetBlockPos() {
      class_239 blockHit = this.mc.field_1765;
      return blockHit.method_17783() != class_240.field_1332 ? null : ((class_3965)blockHit).method_17777();
   }

   private void getDistance(class_2382 offset) {
      class_2338 pos = this.placeFluidPos.method_10074().method_10081(offset);
      class_3965 result = this.mc.field_1687.method_17742(new class_3959(class_243.method_24953(pos), class_243.method_24953(pos.method_10087(250)), class_3960.field_17558, class_242.field_1347, this.mc.field_1724));
      if (result != null && result.method_17783() == class_240.field_1332) {
         int new_dist = this.placeFluidPos.method_10264() - result.method_17777().method_10264();
         if (new_dist > this.dist) {
            this.dist = new_dist;
         }

      }
   }

   public String getInfoString() {
      return this.stage.toString();
   }

   private static enum Stage {
      None,
      LavaDown,
      LavaUp,
      WaterDown,
      WaterUp;

      // $FF: synthetic method
      private static Stage[] $values() {
         return new Stage[]{None, LavaDown, LavaUp, WaterDown, WaterUp};
      }
   }
}
