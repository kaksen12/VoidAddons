package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.utils.WorldUtils;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BlockSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class Painter extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<class_2248> block;
   private final Setting<Integer> range;
   private final Setting<Integer> delay;
   private final Setting<Integer> bpt;
   private final Setting<Boolean> rotate;
   private final Setting<Boolean> topSurfaces;
   private final Setting<Boolean> sideSurfaces;
   private final Setting<Boolean> bottomSurfaces;
   private final Setting<Boolean> oneBlockHeight;
   private int ticksWaited;

   public Painter() {
      super(MeteorRejectsAddon.CATEGORY, "painter", "Automatically paints/covers surfaces (good for trolling)");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.block = this.sgGeneral.add(((BlockSetting.Builder)((BlockSetting.Builder)((BlockSetting.Builder)(new BlockSetting.Builder()).name("block")).description("Block to use for painting")).defaultValue(class_2246.field_10494)).build());
      this.range = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("range")).description("Range of placement")).min(0).defaultValue(0)).build());
      this.delay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("delay")).description("Delay between block placement (in ticks)")).min(0).defaultValue(0)).build());
      this.bpt = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("blocks-per-tick")).description("Amount of blocks that can be placed in one tick")).min(1).defaultValue(1)).build());
      this.rotate = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("rotate")).description("Whether or not to rotate towards block while placing")).defaultValue(true)).build());
      this.topSurfaces = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("top-surface")).description("Whether or not to cover top surfaces")).defaultValue(true)).build());
      this.sideSurfaces = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("side-surface")).description("Whether or not to cover side surfaces")).defaultValue(true)).build());
      this.bottomSurfaces = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("bottom-surface")).description("Whether or not to cover bottom surfaces")).defaultValue(true)).build());
      this.oneBlockHeight = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("one-block-height")).description("Whether or not to cover in one block high gaps")).defaultValue(true)).build());
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      if ((Integer)this.delay.get() != 0 && this.ticksWaited < (Integer)this.delay.get() - 1) {
         ++this.ticksWaited;
      } else {
         this.ticksWaited = 0;
         FindItemResult findItemResult = InvUtils.findInHotbar((itemStack) -> this.block.get() == class_2248.method_9503(itemStack.method_7909()));
         if (!findItemResult.found()) {
            this.error("No selected blocks in hotbar", new Object[0]);
            this.toggle();
         } else {
            int placed = 0;

            for(class_2338 blockPos : WorldUtils.getSphere(this.mc.field_1724.method_24515(), (Integer)this.range.get(), (Integer)this.range.get())) {
               if (this.shouldPlace(blockPos, (class_2248)this.block.get())) {
                  BlockUtils.place(blockPos, findItemResult, (Boolean)this.rotate.get(), -100, false);
                  ++placed;
                  if ((Integer)this.delay.get() != 0 && placed >= (Integer)this.bpt.get()) {
                     break;
                  }
               }
            }

         }
      }
   }

   private boolean shouldPlace(class_2338 blockPos, class_2248 useBlock) {
      if (!this.mc.field_1687.method_8320(blockPos).method_45474()) {
         return false;
      } else if (!(Boolean)this.oneBlockHeight.get() && !this.mc.field_1687.method_8320(blockPos.method_10084()).method_45474() && !this.mc.field_1687.method_8320(blockPos.method_10074()).method_45474()) {
         return false;
      } else {
         boolean north = true;
         boolean south = true;
         boolean east = true;
         boolean west = true;
         boolean up = true;
         boolean bottom = true;
         class_2680 northState = this.mc.field_1687.method_8320(blockPos.method_10095());
         class_2680 southState = this.mc.field_1687.method_8320(blockPos.method_10072());
         class_2680 eastState = this.mc.field_1687.method_8320(blockPos.method_10078());
         class_2680 westState = this.mc.field_1687.method_8320(blockPos.method_10067());
         class_2680 upState = this.mc.field_1687.method_8320(blockPos.method_10084());
         class_2680 bottomState = this.mc.field_1687.method_8320(blockPos.method_10074());
         if ((Boolean)this.topSurfaces.get() && (upState.method_45474() || upState.method_26204() == useBlock)) {
            up = false;
         }

         if ((Boolean)this.sideSurfaces.get()) {
            if (northState.method_45474() || northState.method_26204() == useBlock) {
               north = false;
            }

            if (southState.method_45474() || southState.method_26204() == useBlock) {
               south = false;
            }

            if (eastState.method_45474() || eastState.method_26204() == useBlock) {
               east = false;
            }

            if (westState.method_45474() || westState.method_26204() == useBlock) {
               west = false;
            }
         }

         if ((Boolean)this.bottomSurfaces.get() && (bottomState.method_45474() || bottomState.method_26204() == useBlock)) {
            bottom = false;
         }

         return north || south || east || west || up || bottom;
      }
   }
}
