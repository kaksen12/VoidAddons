package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.config.Config;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.render.Freecam;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_5498;
import net.minecraft.class_591;
import net.minecraft.class_630;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class SkeletonESP extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<SettingColor> skeletonColorSetting;
   public final Setting<Boolean> distance;
   private final Freecam freecam;
   private final Color color;

   public SkeletonESP() {
      super(MeteorRejectsAddon.CATEGORY, "skeleton-esp", "Looks cool as fuck");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.skeletonColorSetting = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("players-color")).description("The other player's color.")).defaultValue(new SettingColor(255, 255, 255)).build());
      this.distance = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("distance-colors")).description("Changes the color of skeletons depending on distance.")).defaultValue(false)).build());
      this.color = new Color();
      this.freecam = (Freecam)Modules.get().get(Freecam.class);
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      float tickDelta = event.tickDelta;
      int rotationHoldTicks = (Integer)Config.get().rotationHoldTicks.get();
      this.mc.field_1687.method_18112().forEach((entity) -> {
         if (entity instanceof class_1657) {
            if (this.mc.field_1690.method_31044() != class_5498.field_26664 || this.freecam.isActive() || this.mc.field_1724 != entity) {
               Color skeletonColor = PlayerUtils.getPlayerColor((class_1657)entity, (Color)this.skeletonColorSetting.get());
               if ((Boolean)this.distance.get()) {
                  skeletonColor = this.getColorFromDistance(entity);
               }

               class_1657 player = (class_1657)entity;
               class_243 footPos = this.getEntityRenderPosition(player, (double)tickDelta);
               class_1007 livingEntityRenderer = (class_1007)this.mc.method_1561().method_3953(player);
               class_591 playerModel = (class_591)livingEntityRenderer.method_4038();
               float bodyYaw = class_3532.method_17821(tickDelta, player.field_6220, player.field_6283);
               if (this.mc.field_1724 == entity && Rotations.rotationTimer < rotationHoldTicks) {
                  bodyYaw = Rotations.serverYaw;
               }

               float headYaw = class_3532.method_17821(tickDelta, player.field_6259, player.field_6241);
               if (this.mc.field_1724 == entity && Rotations.rotationTimer < rotationHoldTicks) {
                  headYaw = Rotations.serverYaw;
               }

               float ageInTicks = (float)player.field_6012 + tickDelta;
               float relativeHeadYaw = headYaw - bodyYaw;
               float pitch = player.method_5695(tickDelta);
               if (this.mc.field_1724 == entity && Rotations.rotationTimer < rotationHoldTicks) {
                  pitch = Rotations.serverPitch;
               }

               boolean swimming = player.method_20232();
               boolean sneaking = player.method_18276();
               boolean flying = player.method_6128();
               class_10055 renderState = new class_10055();
               renderState.field_53450 = player.field_42108.method_48572(tickDelta);
               renderState.field_53451 = player.field_42108.method_48570(tickDelta);
               renderState.field_53328 = ageInTicks;
               renderState.field_53447 = relativeHeadYaw;
               renderState.field_53448 = pitch;
               playerModel.method_62110(renderState);
               class_630 head = playerModel.field_3398;
               class_630 leftArm = playerModel.field_27433;
               class_630 rightArm = playerModel.field_3401;
               class_630 leftLeg = playerModel.field_3397;
               class_630 rightLeg = playerModel.field_3392;
               Matrix4f outerMat = new Matrix4f();
               if (swimming) {
                  outerMat.translate(0.0F, 0.35F, 0.0F);
               }

               outerMat.rotateY((float)Math.toRadians((double)(-(bodyYaw + 180.0F))));
               if (swimming || flying) {
                  outerMat.rotateX((float)Math.toRadians((double)(-(90.0F + pitch))));
               }

               if (swimming) {
                  outerMat.translate(0.0F, -0.95F, 0.0F);
               }

               Matrix4f tiltedMat = (new Matrix4f(outerMat)).translate(0.0F, 0.75F, 0.0F);
               if (sneaking && !swimming && !flying) {
                  tiltedMat.rotate(0.5F, -1.0F, 0.0F, 0.0F);
               }

               tiltedMat.translate(0.0F, -0.75F, 0.0F);
               float hipY = sneaking ? 0.6F : 0.7F;
               float hipZ = sneaking ? 0.23F : 0.0F;
               float shoulderY = sneaking ? 1.05F : 1.35F;
               float spineTopY = sneaking ? 1.05F : 1.4F;
               this.drawBone(event, footPos, tiltedMat, 0.0F, hipY, hipZ, 0.0F, spineTopY, 0.0F, skeletonColor);
               this.drawBone(event, footPos, tiltedMat, -0.37F, shoulderY, 0.0F, 0.37F, shoulderY, 0.0F, skeletonColor);
               this.drawBone(event, footPos, outerMat, -0.15F, hipY, hipZ, 0.15F, hipY, hipZ, skeletonColor);
               Matrix4f headMat = (new Matrix4f(tiltedMat)).translate(0.0F, spineTopY, 0.0F);
               this.applyModelRot(headMat, head);
               this.drawBone(event, footPos, headMat, 0.0F, 0.0F, 0.0F, 0.0F, 0.15F, 0.0F, skeletonColor);
               Matrix4f rightLegMat = (new Matrix4f(outerMat)).translate(0.15F, hipY, hipZ);
               this.applyModelRot(rightLegMat, rightLeg);
               this.drawBone(event, footPos, rightLegMat, 0.0F, 0.0F, 0.0F, 0.0F, -0.6F, 0.0F, skeletonColor);
               Matrix4f leftLegMat = (new Matrix4f(outerMat)).translate(-0.15F, hipY, hipZ);
               this.applyModelRot(leftLegMat, leftLeg);
               this.drawBone(event, footPos, leftLegMat, 0.0F, 0.0F, 0.0F, 0.0F, -0.6F, 0.0F, skeletonColor);
               Matrix4f rightArmMat = (new Matrix4f(tiltedMat)).translate(0.37F, shoulderY, 0.0F);
               this.applyModelRot(rightArmMat, rightArm);
               this.drawBone(event, footPos, rightArmMat, 0.0F, 0.0F, 0.0F, 0.0F, -0.55F, 0.0F, skeletonColor);
               Matrix4f leftArmMat = (new Matrix4f(tiltedMat)).translate(-0.37F, shoulderY, 0.0F);
               this.applyModelRot(leftArmMat, leftArm);
               this.drawBone(event, footPos, leftArmMat, 0.0F, 0.0F, 0.0F, 0.0F, -0.55F, 0.0F, skeletonColor);
            }
         }
      });
   }

   private void drawBone(Render3DEvent event, class_243 origin, Matrix4f mat, float x1, float y1, float z1, float x2, float y2, float z2, Color color) {
      Vector3f p1 = mat.transformPosition(new Vector3f(x1, y1, z1));
      Vector3f p2 = mat.transformPosition(new Vector3f(x2, y2, z2));
      event.renderer.line(origin.field_1352 + (double)p1.x, origin.field_1351 + (double)p1.y, origin.field_1350 + (double)p1.z, origin.field_1352 + (double)p2.x, origin.field_1351 + (double)p2.y, origin.field_1350 + (double)p2.z, color);
   }

   private void applyModelRot(Matrix4f mat, class_630 part) {
      if (part.field_3674 != 0.0F) {
         mat.rotate(part.field_3674, 0.0F, 0.0F, 1.0F);
      }

      if (part.field_3675 != 0.0F) {
         mat.rotate(part.field_3675, 0.0F, -1.0F, 0.0F);
      }

      if (part.field_3654 != 0.0F) {
         mat.rotate(part.field_3654, -1.0F, 0.0F, 0.0F);
      }

   }

   private class_243 getEntityRenderPosition(class_1297 entity, double partial) {
      double x = entity.field_6014 + (entity.method_23317() - entity.field_6014) * partial;
      double y = entity.field_6036 + (entity.method_23318() - entity.field_6036) * partial;
      double z = entity.field_5969 + (entity.method_23321() - entity.field_5969) * partial;
      return new class_243(x, y, z);
   }

   private Color getColorFromDistance(class_1297 entity) {
      class_243 entityPos = new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321());
      double distance = this.mc.field_1773.method_19418().method_71156().method_1022(entityPos);
      double percent = distance / (double)60.0F;
      if (!(percent < (double)0.0F) && !(percent > (double)1.0F)) {
         int r;
         int g;
         if (percent < (double)0.5F) {
            r = 255;
            g = (int)((double)255.0F * percent / (double)0.5F);
         } else {
            g = 255;
            r = 255 - (int)((double)255.0F * (percent - (double)0.5F) / (double)0.5F);
         }

         this.color.set(r, g, 0, 255);
         return this.color;
      } else {
         this.color.set(0, 255, 0, 255);
         return this.color;
      }
   }
}
