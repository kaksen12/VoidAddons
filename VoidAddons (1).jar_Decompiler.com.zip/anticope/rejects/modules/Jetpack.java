package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.events.OffGroundSpeedEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;

public class Jetpack extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Double> jetpackSpeed;

   public Jetpack() {
      super(MeteorRejectsAddon.CATEGORY, "jetpack", "Flies as if using a jetpack.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.jetpackSpeed = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("jetpack-speed")).description("How fast while ascending.")).defaultValue(0.42).min((double)0.0F).sliderMax((double)1.0F).build());
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      if (this.mc.field_1690.field_1903.method_1434()) {
         ((IVec3d)this.mc.field_1724.method_18798()).meteor$setY((Double)this.jetpackSpeed.get());
      }

   }

   @EventHandler
   private void onOffGroundSpeed(OffGroundSpeedEvent event) {
      event.speed = this.mc.field_1724.method_6029() * ((Double)this.jetpackSpeed.get()).floatValue();
   }
}
