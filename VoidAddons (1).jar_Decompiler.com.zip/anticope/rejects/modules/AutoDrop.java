package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

public class AutoDrop extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<List<class_1792>> items;
   private final Setting<Boolean> dropHotbar;
   private final Setting<Integer> delay;
   private int timer;

   public AutoDrop() {
      super(MeteorRejectsAddon.CATEGORY, "auto-drop", "Automatically drops selected items from your inventory.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.items = this.sgGeneral.add(((ItemListSetting.Builder)((ItemListSetting.Builder)((ItemListSetting.Builder)(new ItemListSetting.Builder()).name("items")).description("Items to automatically drop from your inventory.")).defaultValue(List.of())).build());
      this.dropHotbar = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("drop-hotbar")).description("Also drop matching items from your hotbar.")).defaultValue(false)).build());
      this.delay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("delay")).description("Delay in ticks between each drop check.")).defaultValue(10)).min(1).sliderMax(40).build());
      this.timer = 0;
   }

   public void onActivate() {
      this.timer = 0;
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      if (this.mc.field_1724 != null) {
         if (this.timer > 0) {
            --this.timer;
         } else {
            this.timer = (Integer)this.delay.get();
            int startSlot = (Boolean)this.dropHotbar.get() ? 0 : 9;

            for(int i = startSlot; i < 36; ++i) {
               class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
               if (stack != null && !stack.method_7960() && ((List)this.items.get()).contains(stack.method_7909())) {
                  InvUtils.drop().slot(i);
                  return;
               }
            }

         }
      }
   }
}
