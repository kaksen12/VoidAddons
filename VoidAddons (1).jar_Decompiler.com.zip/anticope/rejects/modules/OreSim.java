package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.events.PlayerRespawnEvent;
import anticope.rejects.events.SeedChangedEvent;
import anticope.rejects.utils.Ore;
import anticope.rejects.utils.seeds.Seed;
import anticope.rejects.utils.seeds.Seeds;
import baritone.api.BaritoneAPI;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.pathing.BaritoneUtils;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1923;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2791;
import net.minecraft.class_2806;
import net.minecraft.class_2826;
import net.minecraft.class_2919;
import net.minecraft.class_3532;
import net.minecraft.class_5321;
import net.minecraft.class_638;
import net.minecraft.class_2902.class_2903;
import net.minecraft.class_2919.class_6675;

public class OreSim extends Module {
   private final Map<Long, Map<Ore, Set<class_243>>> chunkRenderers = new ConcurrentHashMap();
   private Seed worldSeed = null;
   private Map<class_5321<class_1959>, List<Ore>> oreConfig;
   public List<class_2338> oreGoals = new ArrayList();
   private final SettingGroup sgGeneral;
   private final Setting<Integer> horizontalRadius;
   private final Setting<AirCheck> airCheck;
   private final Setting<Boolean> baritone;

   public OreSim() {
      super(MeteorRejectsAddon.CATEGORY, "ore-sim", "Xray on crack.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.horizontalRadius = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("chunk-range")).description("Taxi cap distance of chunks being shown.")).defaultValue(5)).min(1).sliderMax(10).build());
      this.airCheck = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("air-check-mode")).description("Checks if there is air at a calculated ore pos.")).defaultValue(OreSim.AirCheck.RECHECK)).build());
      this.baritone = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("baritone")).description("Set baritone ore positions to the simulated ones.")).defaultValue(false)).build());
      SettingGroup sgOres = this.settings.createGroup("Ores");
      List var10000 = Ore.oreSettings;
      Objects.requireNonNull(sgOres);
      var10000.forEach(sgOres::add);
   }

   public boolean baritone() {
      return this.isActive() && (Boolean)this.baritone.get() && BaritoneUtils.IS_AVAILABLE;
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.mc.field_1724 != null && this.oreConfig != null) {
         if (Seeds.get().getSeed() != null) {
            int chunkX = this.mc.field_1724.method_31476().field_9181;
            int chunkZ = this.mc.field_1724.method_31476().field_9180;
            int rangeVal = (Integer)this.horizontalRadius.get();

            for(int range = 0; range <= rangeVal; ++range) {
               for(int x = -range + chunkX; x <= range + chunkX; ++x) {
                  this.renderChunk(x, chunkZ + range - rangeVal, event);
               }

               for(int x = -range + 1 + chunkX; x < range + chunkX; ++x) {
                  this.renderChunk(x, chunkZ - range + rangeVal + 1, event);
               }
            }
         }

      }
   }

   private void renderChunk(int x, int z, Render3DEvent event) {
      long chunkKey = class_1923.method_8331(x, z);
      if (this.chunkRenderers.containsKey(chunkKey)) {
         Map<Ore, Set<class_243>> chunk = (Map)this.chunkRenderers.get(chunkKey);

         for(Map.Entry<Ore, Set<class_243>> oreRenders : chunk.entrySet()) {
            if ((Boolean)((Ore)oreRenders.getKey()).active.get()) {
               for(class_243 pos : (Set)oreRenders.getValue()) {
                  event.renderer.boxLines(pos.field_1352, pos.field_1351, pos.field_1350, pos.field_1352 + (double)1.0F, pos.field_1351 + (double)1.0F, pos.field_1350 + (double)1.0F, ((Ore)oreRenders.getKey()).color, 0);
               }
            }
         }
      }

   }

   @EventHandler
   private void onBlockUpdate(BlockUpdateEvent event) {
      if (this.airCheck.get() == OreSim.AirCheck.RECHECK && !event.newState.method_26225()) {
         long chunkKey = class_1923.method_37232(event.pos);
         if (this.chunkRenderers.containsKey(chunkKey)) {
            class_243 pos = class_243.method_24954(event.pos);

            for(Set<class_243> ore : ((Map)this.chunkRenderers.get(chunkKey)).values()) {
               ore.remove(pos);
            }
         }

      }
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      if (this.mc.field_1724 != null && this.mc.field_1687 != null && this.oreConfig != null) {
         if (this.baritone() && BaritoneAPI.getProvider().getPrimaryBaritone().getMineProcess().isActive()) {
            this.oreGoals.clear();
            class_1923 chunkPos = this.mc.field_1724.method_31476();
            int rangeVal = 4;

            for(int range = 0; range <= rangeVal; ++range) {
               for(int x = -range + chunkPos.field_9181; x <= range + chunkPos.field_9181; ++x) {
                  this.oreGoals.addAll(this.addToBaritone(x, chunkPos.field_9180 + range - rangeVal));
               }

               for(int x = -range + 1 + chunkPos.field_9181; x < range + chunkPos.field_9181; ++x) {
                  this.oreGoals.addAll(this.addToBaritone(x, chunkPos.field_9180 - range + rangeVal + 1));
               }
            }
         }

      }
   }

   private ArrayList<class_2338> addToBaritone(int chunkX, int chunkZ) {
      ArrayList<class_2338> baritoneGoals = new ArrayList();
      long chunkKey = class_1923.method_8331(chunkX, chunkZ);
      if (this.chunkRenderers.containsKey(chunkKey)) {
         Stream var10000 = ((Map)this.chunkRenderers.get(chunkKey)).entrySet().stream().filter((entry) -> (Boolean)((Ore)entry.getKey()).active.get()).flatMap((entry) -> ((Set)entry.getValue()).stream()).map(class_2338::method_49638);
         Objects.requireNonNull(baritoneGoals);
         var10000.forEach(baritoneGoals::add);
      }

      return baritoneGoals;
   }

   public void onActivate() {
      if (Seeds.get().getSeed() == null) {
         this.error("No seed found. To set a seed do .seed <seed>", new Object[0]);
         this.toggle();
      }

      this.reload();
   }

   public void onDeactivate() {
      this.chunkRenderers.clear();
      this.oreConfig = null;
   }

   @EventHandler
   private void onSeedChanged(SeedChangedEvent event) {
      this.reload();
   }

   @EventHandler
   private void onPlayerRespawn(PlayerRespawnEvent event) {
      this.reload();
   }

   private void loadVisibleChunks() {
      if (this.mc.field_1724 != null) {
         for(class_2791 chunk : Utils.chunks(false)) {
            this.doMathOnChunk(chunk);
         }

      }
   }

   private void reload() {
      Seed seed = Seeds.get().getSeed();
      if (seed != null) {
         this.worldSeed = seed;
         this.oreConfig = Ore.getRegistry(PlayerUtils.getDimension());
         this.chunkRenderers.clear();
         if (this.mc.field_1687 != null && this.worldSeed != null) {
            this.loadVisibleChunks();
         }

      }
   }

   @EventHandler
   public void onChunkData(ChunkDataEvent event) {
      this.doMathOnChunk(event.chunk());
   }

   private void doMathOnChunk(class_2791 chunk) {
      class_1923 chunkPos = chunk.method_12004();
      long chunkKey = chunkPos.method_8324();
      class_638 world = this.mc.field_1687;
      if (!this.chunkRenderers.containsKey(chunkKey) && world != null) {
         Set<class_5321<class_1959>> biomes = new HashSet();
         class_1923.method_19280(chunkPos, 1).forEach((chunkPosx) -> {
            class_2791 chunkxx = world.method_8402(chunkPosx.field_9181, chunkPosx.field_9180, class_2806.field_12794, false);
            if (chunkxx != null) {
               for(class_2826 chunkSection : chunkxx.method_12006()) {
                  chunkSection.method_38294().method_39793((entry) -> biomes.add((class_5321)entry.method_40230().get()));
               }

            }
         });
         Set<Ore> oreSet = (Set)biomes.stream().flatMap((b) -> this.getDefaultOres(b).stream()).collect(Collectors.toSet());
         int chunkX = chunkPos.field_9181 << 4;
         int chunkZ = chunkPos.field_9180 << 4;
         class_2919 random = new class_2919(class_6675.field_35143.method_39006(0L));
         long populationSeed = random.method_12661(this.worldSeed.seed, chunkX, chunkZ);
         HashMap<Ore, Set<class_243>> h = new HashMap();

         for(Ore ore : oreSet) {
            HashSet<class_243> ores = new HashSet();
            random.method_12664(populationSeed, ore.index, ore.step);
            int repeat = ore.count.method_35008(random);

            for(int i = 0; i < repeat; ++i) {
               if (ore.rarity == 1.0F || !(random.method_43057() >= 1.0F / ore.rarity)) {
                  int x = random.method_43048(16) + chunkX;
                  int z = random.method_43048(16) + chunkZ;
                  int y = ore.heightProvider.method_35391(random, ore.heightContext);
                  class_2338 origin = new class_2338(x, y, z);
                  class_5321<class_1959> biome = (class_5321)chunk.method_16359(x, y, z).method_40230().get();
                  if (this.getDefaultOres(biome).contains(ore)) {
                     if (ore.scattered) {
                        ores.addAll(this.generateHidden(world, random, origin, ore.size));
                     } else {
                        ores.addAll(this.generateNormal(world, random, origin, ore.size, ore.discardOnAirChance));
                     }
                  }
               }
            }

            if (!ores.isEmpty()) {
               h.put(ore, ores);
            }
         }

         this.chunkRenderers.put(chunkKey, h);
      }
   }

   private List<Ore> getDefaultOres(class_5321<class_1959> biomeRegistryKey) {
      return this.oreConfig.containsKey(biomeRegistryKey) ? (List)this.oreConfig.get(biomeRegistryKey) : (List)this.oreConfig.values().stream().findAny().get();
   }

   private ArrayList<class_243> generateNormal(class_638 world, class_2919 random, class_2338 blockPos, int veinSize, float discardOnAir) {
      float f = random.method_43057() * (float)Math.PI;
      float g = (float)veinSize / 8.0F;
      int i = class_3532.method_15386(((float)veinSize / 16.0F * 2.0F + 1.0F) / 2.0F);
      double d = (double)blockPos.method_10263() + Math.sin((double)f) * (double)g;
      double e = (double)blockPos.method_10263() - Math.sin((double)f) * (double)g;
      double h = (double)blockPos.method_10260() + Math.cos((double)f) * (double)g;
      double j = (double)blockPos.method_10260() - Math.cos((double)f) * (double)g;
      double l = (double)(blockPos.method_10264() + random.method_43048(3) - 2);
      double m = (double)(blockPos.method_10264() + random.method_43048(3) - 2);
      int n = blockPos.method_10263() - class_3532.method_15386(g) - i;
      int o = blockPos.method_10264() - 2 - i;
      int p = blockPos.method_10260() - class_3532.method_15386(g) - i;
      int q = 2 * (class_3532.method_15386(g) + i);
      int r = 2 * (2 + i);

      for(int s = n; s <= n + q; ++s) {
         for(int t = p; t <= p + q; ++t) {
            if (o <= world.method_8624(class_2903.field_13197, s, t)) {
               return this.generateVeinPart(world, random, veinSize, d, e, h, j, l, m, n, o, p, q, r, discardOnAir);
            }
         }
      }

      return new ArrayList();
   }

   private ArrayList<class_243> generateVeinPart(class_638 world, class_2919 random, int veinSize, double startX, double endX, double startZ, double endZ, double startY, double endY, int x, int y, int z, int size, int i, float discardOnAir) {
      BitSet bitSet = new BitSet(size * i * size);
      class_2338.class_2339 mutable = new class_2338.class_2339();
      double[] ds = new double[veinSize * 4];
      ArrayList<class_243> poses = new ArrayList();

      for(int n = 0; n < veinSize; ++n) {
         float f = (float)n / (float)veinSize;
         double p = class_3532.method_16436((double)f, startX, endX);
         double q = class_3532.method_16436((double)f, startY, endY);
         double r = class_3532.method_16436((double)f, startZ, endZ);
         double s = random.method_43058() * (double)veinSize / (double)16.0F;
         double m = ((double)(class_3532.method_15374((double)((float)Math.PI * f)) + 1.0F) * s + (double)1.0F) / (double)2.0F;
         ds[n * 4] = p;
         ds[n * 4 + 1] = q;
         ds[n * 4 + 2] = r;
         ds[n * 4 + 3] = m;
      }

      for(int var59 = 0; var59 < veinSize - 1; ++var59) {
         if (!(ds[var59 * 4 + 3] <= (double)0.0F)) {
            for(int o = var59 + 1; o < veinSize; ++o) {
               if (!(ds[o * 4 + 3] <= (double)0.0F)) {
                  double p = ds[var59 * 4] - ds[o * 4];
                  double q = ds[var59 * 4 + 1] - ds[o * 4 + 1];
                  double r = ds[var59 * 4 + 2] - ds[o * 4 + 2];
                  double s = ds[var59 * 4 + 3] - ds[o * 4 + 3];
                  if (s * s > p * p + q * q + r * r) {
                     if (s > (double)0.0F) {
                        ds[o * 4 + 3] = (double)-1.0F;
                     } else {
                        ds[var59 * 4 + 3] = (double)-1.0F;
                     }
                  }
               }
            }
         }
      }

      for(int var60 = 0; var60 < veinSize; ++var60) {
         double u = ds[var60 * 4 + 3];
         if (!(u < (double)0.0F)) {
            double v = ds[var60 * 4];
            double w = ds[var60 * 4 + 1];
            double aa = ds[var60 * 4 + 2];
            int ab = Math.max(class_3532.method_15357(v - u), x);
            int ac = Math.max(class_3532.method_15357(w - u), y);
            int ad = Math.max(class_3532.method_15357(aa - u), z);
            int ae = Math.max(class_3532.method_15357(v + u), ab);
            int af = Math.max(class_3532.method_15357(w + u), ac);
            int ag = Math.max(class_3532.method_15357(aa + u), ad);

            for(int ah = ab; ah <= ae; ++ah) {
               double ai = ((double)ah + (double)0.5F - v) / u;
               if (ai * ai < (double)1.0F) {
                  for(int aj = ac; aj <= af; ++aj) {
                     double ak = ((double)aj + (double)0.5F - w) / u;
                     if (ai * ai + ak * ak < (double)1.0F) {
                        for(int al = ad; al <= ag; ++al) {
                           double am = ((double)al + (double)0.5F - aa) / u;
                           if (ai * ai + ak * ak + am * am < (double)1.0F) {
                              int an = ah - x + (aj - y) * size + (al - z) * size * i;
                              if (!bitSet.get(an)) {
                                 bitSet.set(an);
                                 mutable.method_10103(ah, aj, al);
                                 if (aj >= -64 && aj < 320 && (this.airCheck.get() == OreSim.AirCheck.OFF || world.method_8320(mutable).method_26225()) && this.shouldPlace(world, mutable, discardOnAir, random)) {
                                    poses.add(new class_243((double)ah, (double)aj, (double)al));
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      return poses;
   }

   private boolean shouldPlace(class_638 world, class_2338 orePos, float discardOnAir, class_2919 random) {
      if (discardOnAir != 0.0F && (discardOnAir == 1.0F || !(random.method_43057() >= discardOnAir))) {
         for(class_2350 direction : class_2350.values()) {
            if (!world.method_8320(orePos.method_10081(direction.method_62675())).method_26225() && discardOnAir != 1.0F) {
               return false;
            }
         }

         return true;
      } else {
         return true;
      }
   }

   private ArrayList<class_243> generateHidden(class_638 world, class_2919 random, class_2338 blockPos, int size) {
      ArrayList<class_243> poses = new ArrayList();
      int i = random.method_43048(size + 1);

      for(int j = 0; j < i; ++j) {
         size = Math.min(j, 7);
         int x = this.randomCoord(random, size) + blockPos.method_10263();
         int y = this.randomCoord(random, size) + blockPos.method_10264();
         int z = this.randomCoord(random, size) + blockPos.method_10260();
         if ((this.airCheck.get() == OreSim.AirCheck.OFF || world.method_8320(new class_2338(x, y, z)).method_26225()) && this.shouldPlace(world, new class_2338(x, y, z), 1.0F, random)) {
            poses.add(new class_243((double)x, (double)y, (double)z));
         }
      }

      return poses;
   }

   private int randomCoord(class_2919 random, int size) {
      return Math.round((random.method_43057() - random.method_43057()) * (float)size);
   }

   public static enum AirCheck {
      ON_LOAD,
      RECHECK,
      OFF;

      // $FF: synthetic method
      private static AirCheck[] $values() {
         return new AirCheck[]{ON_LOAD, RECHECK, OFF};
      }
   }
}
