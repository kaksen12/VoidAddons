package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.mixin.LivingEntityAccessor;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;

public class NoJumpDelay extends Module {
   public NoJumpDelay() {
      super(MeteorRejectsAddon.CATEGORY, "no-jump-delay", "NoJumpDelay.");
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      if (this.mc.field_1724 != null) {
         ((LivingEntityAccessor)this.mc.field_1724).setJumpingCooldown(0);
      }
   }
}
