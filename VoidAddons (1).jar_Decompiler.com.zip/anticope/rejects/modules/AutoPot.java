package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import baritone.api.BaritoneAPI;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.meteorclient.events.entity.player.ItemUseCrosshairTargetEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.pathing.BaritoneUtils;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StatusEffectListSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.combat.AnchorAura;
import meteordevelopment.meteorclient.systems.modules.combat.BedAura;
import meteordevelopment.meteorclient.systems.modules.combat.CrystalAura;
import meteordevelopment.meteorclient.systems.modules.combat.KillAura;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9334;

public class AutoPot extends Module {
   private static final Class<? extends Module>[] AURAS = new Class[]{KillAura.class, CrystalAura.class, AnchorAura.class, BedAura.class};
   private final SettingGroup sgGeneral;
   private final Setting<List<class_1291>> usablePotions;
   private final Setting<Boolean> useSplashPots;
   private final Setting<Integer> health;
   private final Setting<Boolean> pauseAuras;
   private final Setting<Boolean> pauseBaritone;
   private final Setting<Boolean> lookDown;
   private int slot;
   private int prevSlot;
   private boolean drinking;
   private boolean splashing;
   private final List<Class<? extends Module>> wasAura;
   private boolean wasBaritone;

   public AutoPot() {
      super(MeteorRejectsAddon.CATEGORY, "auto-pot", "Automatically Drinks Potions");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.usablePotions = this.sgGeneral.add(((StatusEffectListSetting.Builder)((StatusEffectListSetting.Builder)(new StatusEffectListSetting.Builder()).name("potions-to-use")).description("The potions to use.")).defaultValue(new class_1291[]{(class_1291)class_1294.field_5915.comp_349(), (class_1291)class_1294.field_5910.comp_349(), (class_1291)class_1294.field_16595.comp_349()}).build());
      this.useSplashPots = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("splash-potions")).description("Allow the use of splash potions")).defaultValue(true)).build());
      this.health = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("health")).description("If health goes below this point, Healing potions will trigger.")).defaultValue(15)).min(0).sliderMax(20).build());
      this.pauseAuras = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("pause-auras")).description("Pauses all auras when eating.")).defaultValue(true)).build());
      this.pauseBaritone = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("pause-baritone")).description("Pause baritone when eating.")).defaultValue(true)).build());
      this.lookDown = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("rotate")).description("Forces you to rotate downwards when throwing splash potions.")).defaultValue(true)).build());
      this.wasAura = new ArrayList();
   }

   public void onDeactivate() {
      this.stopPotionUsage();
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      if (!this.mc.field_1724.method_6115()) {
         for(class_1291 statusEffect : (List)this.usablePotions.get()) {
            class_6880<class_1291> registryEntry = class_7923.field_41174.method_47983(statusEffect);
            if (!this.mc.field_1724.method_6059(registryEntry)) {
               this.slot = this.potionSlot(statusEffect);
               if (this.slot != -1) {
                  if (registryEntry == class_1294.field_5915 && this.ShouldDrinkHealth()) {
                     this.startPotionUse();
                     return;
                  }

                  if (registryEntry == class_1294.field_5915) {
                     return;
                  }

                  this.startPotionUse();
               }
            }
         }

      }
   }

   @EventHandler
   private void onItemUseCrosshairTarget(ItemUseCrosshairTargetEvent event) {
      if (this.drinking) {
         event.target = null;
      }

   }

   private void setPressed(boolean pressed) {
      this.mc.field_1690.field_1904.method_23481(pressed);
   }

   private void drink() {
      this.changeSlot(this.slot);
      this.setPressed(true);
      if (!this.mc.field_1724.method_6115()) {
         Utils.rightClick();
      }

      this.drinking = true;
   }

   private void splash() {
      this.changeSlot(this.slot);
      this.setPressed(true);
      this.splashing = true;
   }

   private void stopPotionUsage() {
      this.changeSlot(this.prevSlot);
      this.setPressed(false);
      this.drinking = false;
      this.splashing = false;
      if ((Boolean)this.pauseAuras.get()) {
         for(Class<? extends Module> klass : AURAS) {
            Module module = Modules.get().get(klass);
            if (this.wasAura.contains(klass) && !module.isActive()) {
               module.toggle();
            }
         }
      }

      if ((Boolean)this.pauseBaritone.get() && this.wasBaritone) {
         BaritoneAPI.getProvider().getPrimaryBaritone().getCommandManager().execute("resume");
      }

   }

   private double trueHealth() {
      assert this.mc.field_1724 != null;

      return (double)this.mc.field_1724.method_6032();
   }

   private void changeSlot(int slot) {
      this.mc.field_1724.method_31548().method_61496(slot);
      this.slot = slot;
   }

   private int potionSlot(class_1291 statusEffect) {
      int slot = -1;

      for(int i = 0; i < 9; ++i) {
         class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
         if (!stack.method_7960()) {
            if (this.isOminousBottle(stack)) {
               if (statusEffect == class_1294.field_16595.comp_349()) {
                  slot = i;
                  break;
               }
            } else {
               boolean isPotion = stack.method_7909() == class_1802.field_8574;
               boolean isSplashPotion = stack.method_7909() == class_1802.field_8436;
               if (isPotion || isSplashPotion && (Boolean)this.useSplashPots.get()) {
                  class_1844 effects = (class_1844)stack.method_57353().method_58695(class_9334.field_49651, class_1844.field_49274);

                  for(class_1293 effectInstance : effects.method_57397()) {
                     if (effectInstance.method_5586().equals(statusEffect.method_5567())) {
                        slot = i;
                        break;
                     }
                  }

                  if (slot != -1) {
                     break;
                  }
               }
            }
         }
      }

      return slot;
   }

   private void startPotionUse() {
      this.prevSlot = this.mc.field_1724.method_31548().method_67532();
      class_1799 stack = this.mc.field_1724.method_31548().method_5438(this.slot);
      boolean isSplashPotion = stack.method_7909() == class_1802.field_8436;
      if (isSplashPotion && (Boolean)this.useSplashPots.get()) {
         if ((Boolean)this.lookDown.get()) {
            Rotations.rotate((double)this.mc.field_1724.method_36454(), (double)90.0F);
            this.splash();
         } else {
            this.splash();
         }
      } else {
         this.drink();
      }

      this.wasAura.clear();
      if ((Boolean)this.pauseAuras.get()) {
         for(Class<? extends Module> klass : AURAS) {
            Module module = Modules.get().get(klass);
            if (module.isActive()) {
               this.wasAura.add(klass);
               module.toggle();
            }
         }
      }

      this.wasBaritone = false;
      if (BaritoneUtils.IS_AVAILABLE && (Boolean)this.pauseBaritone.get() && BaritoneAPI.getProvider().getPrimaryBaritone().getPathingBehavior().isPathing()) {
         this.wasBaritone = true;
         BaritoneAPI.getProvider().getPrimaryBaritone().getCommandManager().execute("pause");
      }

   }

   private boolean isOminousBottle(class_1799 stack) {
      return stack.method_7909() == class_1802.field_50140;
   }

   private boolean ShouldDrinkHealth() {
      return this.trueHealth() < (double)(Integer)this.health.get();
   }
}
