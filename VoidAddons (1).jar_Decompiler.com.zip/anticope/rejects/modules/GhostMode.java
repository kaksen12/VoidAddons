package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
import meteordevelopment.meteorclient.events.game.OpenScreenEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_418;

public class GhostMode extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Boolean> fullFood;
   private boolean active;

   public GhostMode() {
      super(MeteorRejectsAddon.CATEGORY, "ghost-mode", "Allows you to keep playing after you die. Works on Forge, Fabric and Vanilla servers.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.fullFood = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("full-food")).description("Sets the food level client-side to max.")).defaultValue(true)).build());
      this.active = false;
   }

   public void onDeactivate() {
      super.onDeactivate();
      this.active = false;
      this.warning("You are no longer in a ghost mode!", new Object[0]);
      if (this.mc.field_1724 != null && this.mc.field_1724.field_3944 != null) {
         this.mc.field_1724.method_7331();
         this.info("Respawn request has been sent to the server.", new Object[0]);
      }

   }

   @EventHandler
   private void onGameJoin(GameJoinedEvent event) {
      this.active = false;
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      if (this.active) {
         if (this.mc.field_1724.method_6032() < 1.0F) {
            this.mc.field_1724.method_6033(20.0F);
         }

         if ((Boolean)this.fullFood.get() && this.mc.field_1724.method_7344().method_7586() < 20) {
            this.mc.field_1724.method_7344().method_7580(20);
         }

      }
   }

   @EventHandler
   private void onOpenScreen(OpenScreenEvent event) {
      if (event.screen instanceof class_418) {
         event.cancel();
         if (!this.active) {
            this.active = true;
            this.info("You are now in a ghost mode. ", new Object[0]);
         }
      }

   }
}
