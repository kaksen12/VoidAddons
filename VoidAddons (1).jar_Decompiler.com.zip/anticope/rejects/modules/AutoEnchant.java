package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.game.OpenScreenEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.network.MeteorExecutor;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1703;
import net.minecraft.class_1718;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_636;
import net.minecraft.class_746;

public class AutoEnchant extends Module {
   public final SettingGroup sgGeneral;
   private final Setting<Integer> delay;
   private final Setting<Integer> level;
   private final Setting<Boolean> drop;
   private final Setting<List<class_1792>> itemWhitelist;

   public AutoEnchant() {
      super(MeteorRejectsAddon.CATEGORY, "auto-enchant", "Automatically enchanting items.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.delay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("delay")).description("The tick delay between enchanting items.")).defaultValue(50)).sliderMax(500).min(0).build());
      this.level = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("level")).description("Choose enchantment levels 1-3")).defaultValue(3)).max(3).min(1).build());
      this.drop = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("drop")).description("Automatically drops enchanted items (useful for when not enough inventory space)")).defaultValue(false)).build());
      this.itemWhitelist = this.sgGeneral.add(((ItemListSetting.Builder)((ItemListSetting.Builder)(new ItemListSetting.Builder()).name("item-whitelist")).description("Item that require enchantment.")).defaultValue(new class_1792[0]).filter((item) -> item.equals(class_1802.field_8529) || (new class_1799(item)).method_7923()).build());
   }

   @EventHandler
   private void onOpenScreen(OpenScreenEvent event) {
      if (((class_746)Objects.requireNonNull(this.mc.field_1724)).field_7512 instanceof class_1718) {
         MeteorExecutor.execute(this::autoEnchant);
      }
   }

   private void autoEnchant() {
      class_1703 var2 = ((class_746)Objects.requireNonNull(this.mc.field_1724)).field_7512;
      if (var2 instanceof class_1718 handler) {
         if (this.mc.field_1724.field_7520 < 30) {
            this.info("You don't have enough experience levels", new Object[0]);
         } else {
            while(this.getEmptySlotCount(handler) > 2 || (Boolean)this.drop.get()) {
               if (!(this.mc.field_1724.field_7512 instanceof class_1718)) {
                  this.info("Enchanting table is closed.", new Object[0]);
                  break;
               }

               if (handler.method_7638() < (Integer)this.level.get() && !this.fillLapisItem()) {
                  this.info("Lapis lazuli is not found.", new Object[0]);
                  break;
               }

               if (!this.fillCanEnchantItem()) {
                  this.info("No items found to enchant.", new Object[0]);
                  break;
               }

               ((class_636)Objects.requireNonNull(this.mc.field_1761)).method_2900(handler.field_7763, (Integer)this.level.get() - 1);
               if (this.getEmptySlotCount(handler) > 2) {
                  InvUtils.shiftClick().slotId(0);
               } else if ((Boolean)this.drop.get() && handler.method_7611(0).method_7681()) {
                  this.mc.execute(() -> InvUtils.drop().slotId(0));
               }

               try {
                  Thread.sleep((long)(Integer)this.delay.get());
               } catch (InterruptedException e) {
                  throw new RuntimeException(e);
               }
            }

         }
      }
   }

   private boolean fillCanEnchantItem() {
      FindItemResult res = InvUtils.find((stack) -> ((List)this.itemWhitelist.get()).contains(stack.method_7909()));
      if (!res.found()) {
         return false;
      } else {
         InvUtils.shiftClick().slot(res.slot());
         return true;
      }
   }

   private boolean fillLapisItem() {
      FindItemResult res = InvUtils.find(new class_1792[]{class_1802.field_8759});
      if (!res.found()) {
         return false;
      } else {
         InvUtils.shiftClick().slot(res.slot());
         return true;
      }
   }

   private int getEmptySlotCount(class_1703 handler) {
      int emptySlotCount = 0;

      for(int i = 0; i < handler.field_7761.size(); ++i) {
         if (((class_1735)handler.field_7761.get(i)).method_7677().method_7909().equals(class_1802.field_8162)) {
            ++emptySlotCount;
         }
      }

      return emptySlotCount;
   }
}
