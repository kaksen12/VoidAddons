package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_2873;
import net.minecraft.class_5819;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class ItemGenerator extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Integer> speed;
   private final Setting<Integer> stackSize;
   private final class_5819 random;

   public ItemGenerator() {
      super(MeteorRejectsAddon.CATEGORY, "item-generator", "Generates random items and drops them on the ground. Creative mode only.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.speed = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("speed")).description("Stacks per tick. High speeds may cause lag.")).defaultValue(1)).min(1).max(36).sliderMax(36).build());
      this.stackSize = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("stack-size")).description("How many items to place in each stack. ")).defaultValue(1)).min(1).max(64).sliderMax(64).build());
      this.random = class_5819.method_43047();
   }

   public void onActivate() {
      if (!this.mc.field_1724.method_31549().field_7477) {
         this.error("Creative mode only.", new Object[0]);
         this.toggle();
      }

   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      int stacks = (Integer)this.speed.get();
      int size = (Integer)this.stackSize.get();

      for(int i = 9; i < 9 + stacks; ++i) {
         this.mc.field_1724.field_3944.method_52787(new class_2873(i, new class_1799((class_1935)class_7923.field_41178.method_10240(this.random).map(class_6880::comp_349).orElse(class_1802.field_8831), size)));
      }

      for(int i = 9; i < 9 + stacks; ++i) {
         InvUtils.drop().slot(i);
      }

   }
}
