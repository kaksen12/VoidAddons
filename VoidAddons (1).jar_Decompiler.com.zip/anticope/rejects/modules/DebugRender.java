package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.HashMap;
import java.util.Map;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import net.minecraft.class_10161;
import net.minecraft.class_12021;
import net.minecraft.class_12043;
import net.minecraft.class_12046;
import net.minecraft.class_1944;
import net.minecraft.class_4205;
import net.minecraft.class_4207;
import net.minecraft.class_4304;
import net.minecraft.class_4604;
import net.minecraft.class_4703;
import net.minecraft.class_4841;
import net.minecraft.class_5739;
import net.minecraft.class_8520;
import net.minecraft.class_8560;
import net.minecraft.class_860;
import net.minecraft.class_863;
import net.minecraft.class_865;
import net.minecraft.class_866;
import net.minecraft.class_867;
import net.minecraft.class_868;
import net.minecraft.class_869;
import net.minecraft.class_870;
import net.minecraft.class_871;
import net.minecraft.class_872;
import net.minecraft.class_8985;
import net.minecraft.class_9986;
import net.minecraft.class_9987;

public class DebugRender extends Module {
   private final SettingGroup sgGeneral;
   private final Map<Setting<Boolean>, class_863.class_864> renderers;

   public DebugRender() {
      super(MeteorRejectsAddon.CATEGORY, "debug-renders", "Render useful debug information.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.renderers = new HashMap();
      class_4207 brainRenderer = new class_4207(this.mc);
      this.addRenderer("bee-brain-&-hive", new class_4703(this.mc));
      this.addRenderer("breeze-brain", new class_8985(this.mc));
      this.addRenderer("chunk-culling", new class_9986(this.mc));
      this.addRenderer("chunk-debug", new class_860(this.mc));
      this.addRenderer("collision", new class_865(this.mc));
      this.addRenderer("entity-block-intersection", new class_12043());
      this.addRenderer("game-event", new class_5739());
      this.addRenderer("mob-goals", new class_4205(this.mc));
      this.addRenderer("heightmap", new class_867(this.mc));
      this.addRenderer("block-light", new class_866(this.mc, true, false));
      this.addRenderer("sky-light", new class_866(this.mc, false, true));
      this.addRenderer("light-sections-sky", new class_8520(this.mc, class_1944.field_9284));
      this.addRenderer("light-sections-block", new class_8520(this.mc, class_1944.field_9282));
      this.addRenderer("neighbor-updates", new class_869());
      this.addRenderer("octree", new class_10161(this.mc));
      this.addRenderer("pathfinding-debug", new class_868());
      this.addRenderer("raid-center", new class_4304(this.mc));
      this.addRenderer("redstone-wire-orientations", new class_9987());
      this.addRenderer("solid-faces", new class_871(this.mc));
      this.addRenderer("structure-outlines", new class_870());
      this.addRenderer("support-blocks", new class_8560(this.mc));
      this.addRenderer("brain-debug", brainRenderer);
      this.addRenderer("poi-debug", new class_12046(brainRenderer));
      this.addRenderer("village-sections", new class_4841());
      this.addRenderer("water", new class_872(this.mc));
   }

   private void addRenderer(String name, class_863.class_864 renderer) {
      Setting<Boolean> setting = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name(name)).defaultValue(false)).build());
      this.renderers.put(setting, renderer);
   }

   public void render(class_4604 frustum, double x, double y, double z, float partialTick) {
      if (this.mc.method_1562() != null) {
         class_12021 debugValueAccess = this.mc.method_1562().method_74750();

         for(Map.Entry<Setting<Boolean>, class_863.class_864> entry : this.renderers.entrySet()) {
            if ((Boolean)((Setting)entry.getKey()).get()) {
               ((class_863.class_864)entry.getValue()).method_23109(x, y, z, debugValueAccess, frustum, partialTick);
            }
         }

      }
   }
}
