package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2664;
import net.minecraft.class_2675;
import net.minecraft.class_2708;
import net.minecraft.class_2743;

public class AntiCrash extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Boolean> log;

   public AntiCrash() {
      super(MeteorRejectsAddon.CATEGORY, "anti-crash", "Attempts to cancel packets that may crash the client.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.log = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("log")).description("Logs when crash packet detected.")).defaultValue(false)).build());
   }

   @EventHandler
   private void onPacketReceive(PacketEvent.Receive event) {
      class_2596 explodePos = event.packet;
      if (explodePos instanceof class_2664 packet) {
         class_243 explodePos = packet.comp_2883();
         class_243 playerKnockback = new class_243((double)0.0F, (double)0.0F, (double)0.0F);
         if (packet.comp_2884().isPresent()) {
            playerKnockback = (class_243)packet.comp_2884().get();
         }

         if (explodePos.method_10216() > (double)3.0E7F || explodePos.method_10214() > (double)3.0E7F || explodePos.method_10215() > (double)3.0E7F || explodePos.method_10216() < (double)-3.0E7F || explodePos.method_10214() < (double)-3.0E7F || explodePos.method_10215() < (double)-3.0E7F || playerKnockback.field_1352 > (double)3.0E7F || playerKnockback.field_1351 > (double)3.0E7F || playerKnockback.field_1350 > (double)3.0E7F || playerKnockback.field_1352 < (double)-3.0E7F || playerKnockback.field_1351 < (double)-3.0E7F || playerKnockback.field_1350 < (double)-3.0E7F) {
            this.cancel(event);
         }
      } else {
         explodePos = event.packet;
         if (explodePos instanceof class_2675 packet) {
            if (packet.method_11545() > 100000) {
               this.cancel(event);
            }
         } else {
            explodePos = event.packet;
            if (explodePos instanceof class_2708 packet) {
               class_243 playerPos = packet.comp_3228().comp_3148();
               if (playerPos.field_1352 > (double)3.0E7F || playerPos.field_1351 > (double)3.0E7F || playerPos.field_1350 > (double)3.0E7F || playerPos.field_1352 < (double)-3.0E7F || playerPos.field_1351 < (double)-3.0E7F || playerPos.field_1350 < (double)-3.0E7F) {
                  this.cancel(event);
               }
            } else {
               explodePos = event.packet;
               if (explodePos instanceof class_2743 packet) {
                  if (packet.method_73085().field_1352 > (double)1000.0F || packet.method_73085().field_1351 > (double)1000.0F || packet.method_73085().field_1350 > (double)1000.0F || packet.method_73085().field_1352 < (double)-1000.0F || packet.method_73085().field_1351 < (double)-1000.0F || packet.method_73085().field_1350 < (double)-1000.0F) {
                     this.cancel(event);
                  }
               }
            }
         }
      }

   }

   private void cancel(PacketEvent.Receive event) {
      if ((Boolean)this.log.get()) {
         this.warning("Server attempts to crash you", new Object[0]);
      }

      event.cancel();
   }
}
