package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2848;
import net.minecraft.class_3532;
import net.minecraft.class_2848.class_2849;

public class ExtraElytra extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Boolean> instantFly;
   private final Setting<Boolean> speedCtrl;
   private final Setting<Boolean> heightCtrl;
   private final Setting<Boolean> stopInWater;
   private int jumpTimer;

   public void onActivate() {
      this.jumpTimer = 0;
   }

   public ExtraElytra() {
      super(MeteorRejectsAddon.CATEGORY, "extra-elytra", "Easier elytra");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.instantFly = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("instant-fly")).description("Jump to fly, no weird double-jump needed!")).defaultValue(true)).build());
      this.speedCtrl = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("speed-ctrl")).description("Control your speed with the Forward and Back keys.\n(default: W and S)\nNo fireworks needed!")).defaultValue(true)).build());
      this.heightCtrl = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("height-ctrl")).description("Control your height with the Jump and Sneak keys.\n(default: Spacebar and Shift)\nNo fireworks needed!")).defaultValue(false)).build());
      this.stopInWater = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("stop-in-water")).description("Stop flying in water")).defaultValue(true)).build());
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      if (this.jumpTimer > 0) {
         --this.jumpTimer;
      }

      class_1799 chest = this.mc.field_1724.method_6118(class_1304.field_6174);
      if (chest.method_7909() == class_1802.field_8833) {
         if (this.mc.field_1724.method_6128()) {
            if ((Boolean)this.stopInWater.get() && this.mc.field_1724.method_5799()) {
               this.sendStartStopPacket();
            } else {
               this.controlSpeed();
               this.controlHeight();
            }
         } else {
            if (chest.method_7919() < chest.method_7936() - 1 && this.mc.field_1690.field_1903.method_1434()) {
               this.doInstantFly();
            }

         }
      }
   }

   private void sendStartStopPacket() {
      class_2848 packet = new class_2848(this.mc.field_1724, class_2849.field_12982);
      this.mc.field_1724.field_3944.method_52787(packet);
   }

   private void controlHeight() {
      if ((Boolean)this.heightCtrl.get()) {
         class_243 v = this.mc.field_1724.method_18798();
         if (this.mc.field_1690.field_1903.method_1434()) {
            this.mc.field_1724.method_18800(v.field_1352, v.field_1351 + 0.08, v.field_1350);
         } else if (this.mc.field_1690.field_1832.method_1434()) {
            this.mc.field_1724.method_18800(v.field_1352, v.field_1351 - 0.04, v.field_1350);
         }

      }
   }

   private void controlSpeed() {
      if ((Boolean)this.speedCtrl.get()) {
         float yaw = (float)Math.toRadians((double)this.mc.field_1724.method_36454());
         class_243 forward = new class_243((double)(-class_3532.method_15374((double)yaw)) * 0.05, (double)0.0F, (double)class_3532.method_15362((double)yaw) * 0.05);
         class_243 v = this.mc.field_1724.method_18798();
         if (this.mc.field_1690.field_1894.method_1434()) {
            this.mc.field_1724.method_18799(v.method_1019(forward));
         } else if (this.mc.field_1690.field_1881.method_1434()) {
            this.mc.field_1724.method_18799(v.method_1020(forward));
         }

      }
   }

   private void doInstantFly() {
      if ((Boolean)this.instantFly.get()) {
         if (this.jumpTimer <= 0) {
            this.jumpTimer = 20;
            this.mc.field_1724.method_6100(false);
            this.mc.field_1724.method_5728(true);
            this.mc.field_1724.method_6043();
         }

         this.sendStartStopPacket();
      }
   }
}
