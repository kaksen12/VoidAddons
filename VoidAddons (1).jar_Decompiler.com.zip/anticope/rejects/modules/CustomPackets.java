package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import io.netty.buffer.Unpooled;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2596;
import net.minecraft.class_2658;
import net.minecraft.class_5250;

public class CustomPackets extends Module {
   private static final Gson GSON_NON_PRETTY = (new GsonBuilder()).enableComplexMapKeySerialization().disableHtmlEscaping().create();
   private static final Type BADLION_MODS_TYPE = (new TypeToken<Map<String, BadlionMod>>() {
   }).getType();
   private final SettingGroup sgGeneral;
   private final SettingGroup sgBadlion;
   private final Setting<Boolean> unknownPackets;
   private final Setting<Boolean> mods;
   class_2540 buffer;

   public CustomPackets() {
      super(MeteorRejectsAddon.CATEGORY, "custom-packets", "Handles different non-vanilla protocols.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgBadlion = this.settings.createGroup("Bad Lion");
      this.unknownPackets = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("unknown-packets")).description("Whether to print unknown packets.")).defaultValue(false)).build());
      this.mods = this.sgBadlion.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("disallowed-mods")).description("Whether to print what badlion mods are disallowed.")).defaultValue(true)).build());
      this.buffer = new class_2540(Unpooled.buffer());
   }

   @EventHandler
   private void onCustomPayloadPacket(PacketEvent.Receive event) {
      class_2596 var3 = event.packet;
      if (var3 instanceof class_2658 packet) {
         if (packet.comp_1646().method_56479().toString().equals("badlion:mods")) {
            event.setCancelled(this.onBadlionModsPacket(packet));
         } else {
            this.onUnknownPacket(packet);
         }
      }

   }

   private void onUnknownPacket(class_2658 packet) {
      if ((Boolean)this.unknownPackets.get()) {
         class_5250 text = class_2561.method_43470(packet.comp_1646().method_56479().toString());
         this.buffer.method_52931();
         text.method_10862(text.method_10866().method_10949(new class_2568.class_10613(class_2561.method_43470(this.readString(this.buffer)))));
         this.info(text);
      }
   }

   private boolean onBadlionModsPacket(class_2658 packet) {
      if (!(Boolean)this.mods.get()) {
         return false;
      } else {
         this.buffer.method_52931();
         String json = this.readString(this.buffer);
         Map<String, BadlionMod> mods = (Map)GSON_NON_PRETTY.fromJson(json, BADLION_MODS_TYPE);
         ChatUtils.sendMsg("Badlion", this.format("Mods", this.formatMods(mods)));
         return true;
      }
   }

   private class_5250 format(String type, class_5250 message) {
      class_5250 text = class_2561.method_43470(String.format("[%s%s%s]", class_124.field_1075, type, class_124.field_1080));
      text.method_27693(" ");
      text.method_10852(message);
      return text;
   }

   private String readString(class_2540 data) {
      return data.readCharSequence(data.readableBytes(), StandardCharsets.UTF_8).toString();
   }

   private class_5250 formatMods(Map<String, BadlionMod> mods) {
      class_5250 text = class_2561.method_43470("Disallowed mods: \n");
      mods.forEach((name, data) -> {
         class_5250 modLine = class_2561.method_43470(String.format("- %s%s%s ", class_124.field_1054, name, class_124.field_1080));
         modLine.method_27693(data.disabled ? "disabled" : "enabled");
         modLine.method_27693("\n");
         if (data.extra_data != null) {
            modLine.method_10862(modLine.method_10866().method_10949(new class_2568.class_10613(class_2561.method_43470(data.extra_data.toString()))));
         }

         text.method_10852(modLine);
      });
      return text;
   }

   private static class BadlionMod {
      private boolean disabled;
      private JsonObject extra_data;
      private JsonObject settings;
   }
}
