package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.world.BlockIterator;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1778;
import net.minecraft.class_1786;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2530;
import net.minecraft.class_3965;

public class AutoTNT extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Boolean> ignite;
   private final Setting<Integer> igniteDelay;
   private final Setting<Integer> horizontalRange;
   private final Setting<Integer> verticalRange;
   private final Setting<Boolean> antiBreak;
   private final Setting<Integer> durability;
   private final Setting<Boolean> fireCharge;
   private final Setting<Boolean> rotate;
   private final List<class_2338.class_2339> blocksToIgnite;
   private final Pool<class_2338.class_2339> ignitePool;
   private int igniteTick;

   public AutoTNT() {
      super(MeteorRejectsAddon.CATEGORY, "auto-tnt", "Ignites tnt automatically. Good for griefing.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.ignite = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("ignite")).description("Whether to ignite tnt.")).defaultValue(true)).build());
      SettingGroup var10001 = this.sgGeneral;
      IntSetting.Builder var10002 = (IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("ignition-delay")).description("Delay in ticks between ignition")).defaultValue(1);
      Setting var10003 = this.ignite;
      Objects.requireNonNull(var10003);
      this.igniteDelay = var10001.add(((IntSetting.Builder)var10002.visible(var10003::get)).build());
      this.horizontalRange = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("horizontal-range")).description("Horizontal range of ignition")).defaultValue(4)).build());
      this.verticalRange = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("vertical-range")).description("Vertical range of ignition")).defaultValue(4)).build());
      var10001 = this.sgGeneral;
      BoolSetting.Builder var4 = (BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("anti-break")).description("Whether to save flint and steel from breaking.")).defaultValue(true);
      var10003 = this.ignite;
      Objects.requireNonNull(var10003);
      this.antiBreak = var10001.add(((BoolSetting.Builder)var4.visible(var10003::get)).build());
      var10001 = this.sgGeneral;
      IntSetting.Builder var5 = (IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("durability")).description("Decides the amount of durability to leave on the flint and steel")).min(1).max(63).sliderMax(63).defaultValue(10);
      var10003 = this.antiBreak;
      Objects.requireNonNull(var10003);
      this.durability = var10001.add(((IntSetting.Builder)var5.visible(var10003::get)).build());
      var10001 = this.sgGeneral;
      BoolSetting.Builder var6 = (BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("fire-charge")).description("Whether to also use fire charges.")).defaultValue(true);
      var10003 = this.ignite;
      Objects.requireNonNull(var10003);
      this.fireCharge = var10001.add(((BoolSetting.Builder)var6.visible(var10003::get)).build());
      this.rotate = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("rotate")).description("Whether to rotate towards action.")).defaultValue(true)).build());
      this.blocksToIgnite = new ArrayList();
      this.ignitePool = new Pool(class_2338.class_2339::new);
      this.igniteTick = 0;
   }

   public void onDeactivate() {
      this.igniteTick = 0;
   }

   @EventHandler
   private void onPreTick(TickEvent.Pre event) {
      if ((Boolean)this.ignite.get() && this.igniteTick > (Integer)this.igniteDelay.get()) {
         for(class_2338.class_2339 blockPos : this.blocksToIgnite) {
            this.ignitePool.free(blockPos);
         }

         this.blocksToIgnite.clear();
         BlockIterator.register((Integer)this.horizontalRange.get(), (Integer)this.verticalRange.get(), (blockPosx, blockState) -> {
            if (blockState.method_26204() instanceof class_2530) {
               this.blocksToIgnite.add(((class_2338.class_2339)this.ignitePool.get()).method_10101(blockPosx));
            }

         });
      }

   }

   @EventHandler
   private void onPostTick(TickEvent.Post event) {
      if ((Boolean)this.ignite.get() && !this.blocksToIgnite.isEmpty() && this.igniteTick > (Integer)this.igniteDelay.get()) {
         this.blocksToIgnite.sort(Comparator.comparingDouble(PlayerUtils::distanceTo));
         FindItemResult itemResult = InvUtils.findInHotbar((item) -> {
            if (!(item.method_7909() instanceof class_1786)) {
               return item.method_7909() instanceof class_1778 ? (Boolean)this.fireCharge.get() : false;
            } else {
               return !(Boolean)this.antiBreak.get() || item.method_7936() - item.method_7919() > (Integer)this.durability.get();
            }
         });
         if (!itemResult.found()) {
            this.error("No flint and steel in hotbar or durability too low.", new Object[0]);
            this.toggle();
            return;
         }

         this.ignite((class_2338)this.blocksToIgnite.get(0), itemResult);
         this.igniteTick = 0;
      }

      ++this.igniteTick;
   }

   private void ignite(class_2338 pos, FindItemResult item) {
      Runnable action = () -> {
         InvUtils.swap(item.slot(), true);
         this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, new class_3965(new class_243((double)pos.method_10263() + (double)0.5F, (double)pos.method_10264() + (double)0.5F, (double)pos.method_10260() + (double)0.5F), class_2350.field_11036, pos, true));
         InvUtils.swapBack();
      };
      if ((Boolean)this.rotate.get()) {
         Rotations.rotate(Rotations.getYaw(pos), Rotations.getPitch(pos), action);
      } else {
         action.run();
      }

   }
}
