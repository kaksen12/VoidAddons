package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1321;
import net.minecraft.class_1646;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2304;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public class AutoSoup extends Module {
   private static final String desc = "Automatically eats soup when your health is low on some servers.";
   private final SettingGroup sgGeneral;
   public final Setting<Double> health;
   private int oldSlot;

   public AutoSoup() {
      super(MeteorRejectsAddon.CATEGORY, "auto-soup", "Automatically eats soup when your health is low on some servers.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.health = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("health")).description("Eats a soup when your health reaches this value or falls below it.")).defaultValue((double)6.5F).min((double)0.5F).sliderMin((double)0.5F).sliderMax((double)9.5F).build());
      this.oldSlot = -1;
   }

   public void onDeactivate() {
      this.stopIfEating();
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      for(int i = 0; i < 36; ++i) {
         class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
         if (stack != null && stack.method_7909() == class_1802.field_8428 && i != 9) {
            class_1799 emptyBowlStack = this.mc.field_1724.method_31548().method_5438(9);
            boolean swap = !emptyBowlStack.method_7960() && emptyBowlStack.method_7909() != class_1802.field_8428;
            InvUtils.click().slot(i < 9 ? 36 + i : i);
            InvUtils.click().slot(9);
            if (swap) {
               InvUtils.click().slot(i < 9 ? 36 + i : i);
            }
         }
      }

      int soupInHotbar = this.findSoup(0, 9);
      if (soupInHotbar != -1) {
         if (!this.shouldEatSoup()) {
            this.stopIfEating();
         } else {
            if (this.oldSlot == -1) {
               this.oldSlot = this.mc.field_1724.method_31548().method_67532();
            }

            this.mc.field_1724.method_31548().method_61496(soupInHotbar);
            this.mc.field_1690.field_1904.method_23481(true);
            this.mc.field_1761.method_2919(this.mc.field_1724, class_1268.field_5808);
         }
      } else {
         this.stopIfEating();
         int soupInInventory = this.findSoup(9, 36);
         if (soupInInventory != -1) {
            InvUtils.quickSwap().slot(soupInInventory);
         }

      }
   }

   private int findSoup(int startSlot, int endSlot) {
      List<class_1792> stews = List.of(class_1802.field_8308, class_1802.field_8208, class_1802.field_8515);

      for(int i = startSlot; i < endSlot; ++i) {
         class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
         if (stack != null && stews.contains(stack.method_7909())) {
            return i;
         }
      }

      return -1;
   }

   private boolean shouldEatSoup() {
      if ((double)this.mc.field_1724.method_6032() > (Double)this.health.get() * (double)2.0F) {
         return false;
      } else {
         return !this.isClickable(this.mc.field_1765);
      }
   }

   private boolean isClickable(class_239 hitResult) {
      byte var3 = 0;
      //$FF: var3->value
      //0->net/minecraft/class_3966
      //1->net/minecraft/class_3965
      switch (hitResult.typeSwitch<invokedynamic>(hitResult, var3)) {
         case -1:
            return false;
         case 0:
            class_3966 entityHitResult = (class_3966)hitResult;
            class_1297 entity = ((class_3966)this.mc.field_1765).method_17782();
            return entity instanceof class_1646 || entity instanceof class_1321;
         case 1:
            class_3965 blockHitResult = (class_3965)hitResult;
            class_2338 pos = ((class_3965)this.mc.field_1765).method_17777();
            if (pos == null) {
               return false;
            }

            class_2248 block = this.mc.field_1687.method_8320(pos).method_26204();
            return block instanceof class_2237 || block instanceof class_2304;
         default:
            return false;
      }
   }

   private void stopIfEating() {
      if (this.oldSlot != -1) {
         this.mc.field_1690.field_1904.method_23481(false);
         this.mc.field_1724.method_31548().method_61496(this.oldSlot);
         this.oldSlot = -1;
      }
   }
}
