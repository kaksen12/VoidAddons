package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.entity.BoatMoveEvent;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10255;
import net.minecraft.class_243;

public class BoatPhase extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgSpeeds;
   private final Setting<Boolean> lockYaw;
   private final Setting<Boolean> verticalControl;
   private final Setting<Boolean> adjustHorizontalSpeed;
   private final Setting<Boolean> fall;
   private final Setting<Double> horizontalSpeed;
   private final Setting<Double> verticalSpeed;
   private final Setting<Double> fallSpeed;
   private class_10255 boat;

   public BoatPhase() {
      super(MeteorRejectsAddon.CATEGORY, "boat-phase", "Phase through blocks using a boat.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgSpeeds = this.settings.createGroup("Speeds");
      this.lockYaw = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("lock-boat-yaw")).description("Locks boat yaw to the direction you're facing.")).defaultValue(true)).build());
      this.verticalControl = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("vertical-control")).description("Whether or not space/ctrl can be used to move vertically.")).defaultValue(true)).build());
      this.adjustHorizontalSpeed = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("adjust-horizontal-speed")).description("Whether or not horizontal speed is modified.")).defaultValue(false)).build());
      this.fall = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("fall")).description("Toggles vertical glide.")).defaultValue(false)).build());
      this.horizontalSpeed = this.sgSpeeds.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("horizontal-speed")).description("Horizontal speed in blocks per second.")).defaultValue((double)10.0F).min((double)0.0F).sliderMax((double)50.0F).build());
      this.verticalSpeed = this.sgSpeeds.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("vertical-speed")).description("Vertical speed in blocks per second.")).defaultValue((double)5.0F).min((double)0.0F).sliderMax((double)20.0F).build());
      this.fallSpeed = this.sgSpeeds.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("fall-speed")).description("How fast you fall in blocks per second.")).defaultValue((double)0.625F).min((double)0.0F).sliderMax((double)10.0F).build());
      this.boat = null;
   }

   public void onActivate() {
      this.boat = null;
      if (Modules.get().isActive(BoatGlitch.class)) {
         ((BoatGlitch)Modules.get().get(BoatGlitch.class)).toggle();
      }

   }

   public void onDeactivate() {
      if (this.boat != null) {
         this.boat.field_5960 = false;
      }

   }

   @EventHandler
   private void onBoatMove(BoatMoveEvent event) {
      if (this.mc.field_1724.method_5854() instanceof class_10255) {
         if (this.boat != this.mc.field_1724.method_5854()) {
            if (this.boat != null) {
               this.boat.field_5960 = false;
            }

            this.boat = (class_10255)this.mc.field_1724.method_5854();
         }
      } else {
         this.boat = null;
      }

      if (this.boat != null) {
         this.boat.field_5960 = true;
         if ((Boolean)this.lockYaw.get()) {
            this.boat.method_36456(this.mc.field_1724.method_36454());
         }

         class_243 vel;
         if ((Boolean)this.adjustHorizontalSpeed.get()) {
            vel = PlayerUtils.getHorizontalVelocity((Double)this.horizontalSpeed.get());
         } else {
            vel = this.boat.method_18798();
         }

         double velX = vel.field_1352;
         double velY = (double)0.0F;
         double velZ = vel.field_1350;
         if ((Boolean)this.verticalControl.get()) {
            if (this.mc.field_1690.field_1903.method_1434()) {
               velY += (Double)this.verticalSpeed.get() / (double)20.0F;
            }

            if (this.mc.field_1690.field_1867.method_1434()) {
               velY -= (Double)this.verticalSpeed.get() / (double)20.0F;
            } else if ((Boolean)this.fall.get()) {
               velY -= (Double)this.fallSpeed.get() / (double)20.0F;
            }
         } else if ((Boolean)this.fall.get()) {
            velY -= (Double)this.fallSpeed.get() / (double)20.0F;
         }

         ((IVec3d)this.boat.method_18798()).meteor$set(velX, velY, velZ);
      }

   }
}
