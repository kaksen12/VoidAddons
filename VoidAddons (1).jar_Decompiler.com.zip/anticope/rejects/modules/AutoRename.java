package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.Iterator;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1703;
import net.minecraft.class_1706;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_342;
import net.minecraft.class_471;
import net.minecraft.class_9276;
import net.minecraft.class_9288;
import net.minecraft.class_9334;

public class AutoRename extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgRename;
   private final SettingGroup sgLabelContainers;
   private final Setting<Integer> delay;
   private final Setting<List<class_1792>> items;
   private final Setting<String> name;
   private final Setting<ContainerType> containerType;
   private int delayLeft;

   public AutoRename() {
      super(MeteorRejectsAddon.CATEGORY, "auto-rename", "Automatically renames items at an anvil. Can also label shulkers and bundles based on their contents.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgRename = this.settings.createGroup("Rename");
      this.sgLabelContainers = this.settings.createGroup("Label Containers");
      this.delay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("delay")).description("How many ticks to wait between actions.")).defaultValue(2)).min(0).sliderMax(40).build());
      this.items = this.sgRename.add(((ItemListSetting.Builder)((ItemListSetting.Builder)((ItemListSetting.Builder)(new ItemListSetting.Builder()).name("items")).description("Items to rename.")).defaultValue(List.of())).build());
      this.name = this.sgRename.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("name")).description("Name to apply to items. Leave blank to keep the default name.")).defaultValue("")).build());
      this.containerType = this.sgLabelContainers.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("container-type")).description("Which container types to rename based on the first item inside them.")).defaultValue(AutoRename.ContainerType.NONE)).build());
      this.delayLeft = 0;
   }

   @EventHandler
   private void onTick(TickEvent.Post ignoredEvent) {
      if (this.mc.field_1761 != null) {
         if (!((List)this.items.get()).isEmpty() || this.containerType.get() != AutoRename.ContainerType.NONE) {
            if (this.mc.field_1724.field_7512 instanceof class_1706) {
               if (this.delayLeft > 0) {
                  --this.delayLeft;
               } else {
                  this.delayLeft = (Integer)this.delay.get();
                  class_1735 slot0 = this.mc.field_1724.field_7512.method_7611(0);
                  class_1735 slot1 = this.mc.field_1724.field_7512.method_7611(1);
                  class_1735 slot2 = this.mc.field_1724.field_7512.method_7611(2);
                  if (!slot1.method_7681()) {
                     if (slot2.method_7681()) {
                        if (this.mc.field_1724.field_7520 >= 1) {
                           this.extractNamed();
                        }
                     } else if (slot0.method_7681()) {
                        this.renameItem(slot0.method_7677());
                     } else {
                        this.populateAnvil();
                     }

                  }
               }
            }
         }
      }
   }

   private boolean isContainerTarget(class_1799 st) {
      boolean var10000;
      switch (((ContainerType)this.containerType.get()).ordinal()) {
         case 0 -> var10000 = st.method_57826(class_9334.field_49622) || st.method_57826(class_9334.field_49650);
         case 1 -> var10000 = st.method_57826(class_9334.field_49650);
         case 2 -> var10000 = st.method_57826(class_9334.field_49622);
         case 3 -> var10000 = false;
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private void renameItem(class_1799 s) {
      String setname = this.isContainerTarget(s) ? this.getFirstItemName(s) : (String)this.name.get();
      if (!(this.mc.field_1755 instanceof class_471)) {
         this.error("Not anvil screen", new Object[0]);
         this.toggle();
      } else {
         class_342 input = (class_342)this.mc.field_1755.method_25396().get(0);
         input.method_1852(setname);
      }
   }

   private String getFirstItemName(class_1799 stack) {
      class_9288 container = (class_9288)stack.method_58694(class_9334.field_49622);
      if (container != null) {
         Iterator var3 = container.method_59714().iterator();
         if (var3.hasNext()) {
            class_1799 item = (class_1799)var3.next();
            return item.method_7964().getString();
         }
      }

      class_9276 bundle = (class_9276)stack.method_58694(class_9334.field_49650);
      if (bundle != null) {
         Iterator item = bundle.method_57421().iterator();
         if (item.hasNext()) {
            class_1799 item = (class_1799)item.next();
            return item.method_7964().getString();
         }
      }

      return "";
   }

   private void extractNamed() {
      class_1703 inv = this.mc.field_1724.field_7512;

      for(int i = 3; i < 38; ++i) {
         if (inv.method_7611(i).method_7681()) {
            InvUtils.shiftClick().fromId(2).toId(i);
            return;
         }
      }

   }

   private void populateAnvil() {
      class_1703 inv = this.mc.field_1724.field_7512;

      for(int i = 3; i < 38; ++i) {
         class_1735 sl = inv.method_7611(i);
         if (sl.method_7681()) {
            class_1799 st;
            boolean hasCustomName;
            boolean var10000;
            label43: {
               label42: {
                  st = sl.method_7677();
                  hasCustomName = st.method_57353().method_57832(class_9334.field_49631);
                  if (((List)this.items.get()).contains(st.method_7909())) {
                     if (((String)this.name.get()).isEmpty()) {
                        if (hasCustomName) {
                           break label42;
                        }
                     } else if (!hasCustomName) {
                        break label42;
                     }
                  }

                  var10000 = false;
                  break label43;
               }

               var10000 = true;
            }

            boolean isRenameItem = var10000;
            boolean isContainerItem = this.isContainerTarget(st) && !this.getFirstItemName(st).isEmpty();
            if (isRenameItem || isContainerItem && !hasCustomName) {
               InvUtils.shiftClick().fromId(i).toId(0);
               return;
            }
         }
      }

   }

   public static enum ContainerType {
      BOTH,
      BUNDLES,
      SHULKERS,
      NONE;

      public String toString() {
         String var10000;
         switch (this.ordinal()) {
            case 0 -> var10000 = "Both";
            case 1 -> var10000 = "Bundles";
            case 2 -> var10000 = "Shulkers";
            case 3 -> var10000 = "None";
            default -> throw new MatchException((String)null, (Throwable)null);
         }

         return var10000;
      }

      // $FF: synthetic method
      private static ContainerType[] $values() {
         return new ContainerType[]{BOTH, BUNDLES, SHULKERS, NONE};
      }
   }
}
