package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.settings.GameModeListSetting;
import java.util.List;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1934;
import net.minecraft.class_2596;
import net.minecraft.class_2703;
import net.minecraft.class_640;
import net.minecraft.class_2703.class_5893;

public class GamemodeNotifier extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<List<class_1934>> gamemodes;

   public GamemodeNotifier() {
      super(MeteorRejectsAddon.CATEGORY, "gamemode-notifier", "Notifies user a player's gamemode was changed.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.gamemodes = this.sgGeneral.add(((GameModeListSetting.Builder)((GameModeListSetting.Builder)(new GameModeListSetting.Builder()).name("gamemode")).description("Which gamemodes to notify.")).build());
   }

   @EventHandler
   public void onPacket(PacketEvent.Receive event) {
      class_2596 var3 = event.packet;
      if (var3 instanceof class_2703 packet) {
         for(class_2703.class_2705 entry : packet.method_46329()) {
            if (packet.method_46327().contains(class_5893.field_29137)) {
               class_640 entry1 = this.mc.method_1562().method_2871(entry.comp_1106());
               if (entry1 != null) {
                  class_1934 gameMode = entry.comp_1110();
                  if (entry1.method_2958() != gameMode && ((List)this.gamemodes.get()).contains(gameMode)) {
                     this.info("Player %s changed gamemode to %s", new Object[]{entry1.method_2966().name(), entry.comp_1110()});
                  }
               }
            }
         }
      }

   }
}
