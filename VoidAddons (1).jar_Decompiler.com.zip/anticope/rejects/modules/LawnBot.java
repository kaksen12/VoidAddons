package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3965;

public class LawnBot extends Module {
   private final ArrayList<class_2338> myceliumSpots = new ArrayList();
   private final SettingGroup sgGeneral;
   private final Setting<List<class_2248>> blockWhitelist;
   private final Setting<Integer> range;
   private final Setting<Integer> delay;
   private final Setting<Boolean> useShovel;
   private int tickCounter;

   public LawnBot() {
      super(MeteorRejectsAddon.CATEGORY, "lawnbot", "Replace a variety of dirt-type blocks with grass");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.blockWhitelist = this.sgGeneral.add(((BlockListSetting.Builder)((BlockListSetting.Builder)(new BlockListSetting.Builder()).name("block-whitelist")).description("Which blocks to replace with grass.")).defaultValue(new class_2248[0]).filter(this::grassFilter).build());
      this.range = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("range")).description("The range to search for blocks to replace.")).defaultValue(5)).min(1).sliderMax(10).build());
      this.delay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("delay")).description("The delay between block placements in ticks.")).defaultValue(0)).min(0).sliderMax(20).build());
      this.useShovel = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("use-shovel")).description("Automatically switch to shovel when breaking blocks.")).defaultValue(true)).build());
      this.tickCounter = 0;
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      if ((Integer)this.delay.get() > 0) {
         if (this.tickCounter < (Integer)this.delay.get()) {
            ++this.tickCounter;
            return;
         }

         this.tickCounter = 0;
      }

      class_1792 grassBlockItem = class_1802.field_8270;
      int grassCount = InvUtils.find(new class_1792[]{grassBlockItem}).count();
      if (grassCount != 0) {
         int grassHotbarSlot = InvUtils.findInHotbar((itemStack) -> itemStack.method_7909() == grassBlockItem).slot();
         if (grassHotbarSlot == -1) {
            int grassInvSlot = InvUtils.find((itemStack) -> itemStack.method_7909() == grassBlockItem).slot();
            if (grassInvSlot != -1) {
               this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, grassInvSlot < 9 ? grassInvSlot + 36 : grassInvSlot, 8, class_1713.field_7791, this.mc.field_1724);
            }
         } else {
            int rangeValue = (Integer)this.range.get();

            for(int i = 0; i < this.myceliumSpots.size(); ++i) {
               class_2338 pos = (class_2338)this.myceliumSpots.get(i);
               class_2248 block = this.mc.field_1687.method_8320(pos).method_26204();
               double distance = (new class_243(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318(), this.mc.field_1724.method_23321())).method_1022(new class_243((double)pos.method_10263(), (double)pos.method_10264(), (double)pos.method_10260()));
               if (block == class_2246.field_10124 && distance <= (double)rangeValue) {
                  this.mc.field_1724.method_31548().method_61496(grassHotbarSlot);
                  this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, new class_3965(new class_243((double)pos.method_10263(), (double)pos.method_10264(), (double)pos.method_10260()), class_2350.field_11036, pos, false));
                  return;
               }

               if (!((List)this.blockWhitelist.get()).contains(block)) {
                  this.myceliumSpots.remove(i);
               }
            }

            for(int i = 0; i < this.myceliumSpots.size(); ++i) {
               class_2338 pos = (class_2338)this.myceliumSpots.get(i);
               class_2248 block = this.mc.field_1687.method_8320(pos).method_26204();
               double distance = (new class_243(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318(), this.mc.field_1724.method_23321())).method_1022(new class_243((double)pos.method_10263(), (double)pos.method_10264(), (double)pos.method_10260()));
               if (((List)this.blockWhitelist.get()).contains(block) && distance <= (double)rangeValue) {
                  if ((Boolean)this.useShovel.get()) {
                     int shovelSlot = InvUtils.findInHotbar((itemStack) -> itemStack.method_7909() == class_1802.field_22023 || itemStack.method_7909() == class_1802.field_8250 || itemStack.method_7909() == class_1802.field_8699 || itemStack.method_7909() == class_1802.field_8322 || itemStack.method_7909() == class_1802.field_8776 || itemStack.method_7909() == class_1802.field_8876).slot();
                     if (shovelSlot != -1) {
                        this.mc.field_1724.method_31548().method_61496(shovelSlot);
                     }
                  }

                  this.mc.field_1761.method_2902(pos, class_2350.field_11036);
                  return;
               }
            }

            this.myceliumSpots.clear();

            for(int x = -rangeValue; x < rangeValue; ++x) {
               for(int y = -3; y < 3; ++y) {
                  for(int z = -rangeValue; z < rangeValue; ++z) {
                     class_2338 pos = this.mc.field_1724.method_24515().method_10069(x, y, z);
                     if (((List)this.blockWhitelist.get()).contains(this.mc.field_1687.method_8320(pos).method_26204())) {
                        this.myceliumSpots.add(pos);
                     }
                  }
               }
            }

         }
      }
   }

   private boolean grassFilter(class_2248 block) {
      return block == class_2246.field_10402 || block == class_2246.field_10520 || block == class_2246.field_10194 || block == class_2246.field_10253 || block == class_2246.field_28685;
   }
}
