package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.utils.WorldUtils;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import org.apache.commons.lang3.tuple.Pair;

public class MossBot extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Integer> range;
   private final Setting<Boolean> rotate;
   private final Map<class_2338, Integer> mossMap;

   public MossBot() {
      super(MeteorRejectsAddon.CATEGORY, "moss-bot", "Use bonemeal on moss blocks with maximized efficiency.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.range = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("range")).description("The bonemeal range.")).defaultValue(4)).min(0).build());
      this.rotate = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("rotate")).description("Whether or not to rotate towards block while bonemealing.")).defaultValue(true)).build());
      this.mossMap = new HashMap();
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      this.mossMap.entrySet().removeIf((e) -> (Integer)e.setValue((Integer)e.getValue() - 1) == 0);
      FindItemResult findItemResult = InvUtils.findInHotbar(new class_1792[]{class_1802.field_8324});
      if (findItemResult.found()) {
         class_2338 bestBlock = (class_2338)class_2338.method_25998(class_2338.method_49638(this.mc.field_1724.method_33571()), (Integer)this.range.get(), (Integer)this.range.get(), (Integer)this.range.get()).filter((b) -> this.mc.field_1724.method_33571().method_1022(class_243.method_24953(b)) <= (double)(Integer)this.range.get() && !this.mossMap.containsKey(b)).map((b) -> Pair.of(b.method_10062(), this.getMossSpots(b))).filter((p) -> (Integer)p.getRight() > 10).map(Pair::getLeft).max(Comparator.naturalOrder()).orElse((Object)null);
         if (bestBlock != null) {
            if (!this.mc.field_1687.method_22347(bestBlock.method_10084())) {
               this.mc.field_1761.method_2902(bestBlock.method_10084(), class_2350.field_11036);
            }

            WorldUtils.interact(bestBlock, findItemResult, (Boolean)this.rotate.get());
            this.mossMap.put(bestBlock, 100);
         }

      }
   }

   private int getMossSpots(class_2338 pos) {
      class_2248 block = this.mc.field_1687.method_8320(pos).method_26204();
      return (block == class_2246.field_28681 || block == class_2246.field_54731) && this.mc.field_1687.method_8320(pos.method_10084()).method_26214(this.mc.field_1687, pos) == 0.0F ? (int)class_2338.method_25998(pos, 3, 4, 3).filter((b) -> this.isMossGrowableOn(this.mc.field_1687.method_8320(b)) && this.mc.field_1687.method_22347(b.method_10084())).count() : 0;
   }

   private boolean isMossGrowableOn(class_2680 state) {
      return state.method_26164(class_3481.field_28622);
   }
}
