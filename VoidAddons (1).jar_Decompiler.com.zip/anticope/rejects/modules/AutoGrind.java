package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import meteordevelopment.meteorclient.events.game.OpenScreenEvent;
import meteordevelopment.meteorclient.settings.EnchantmentListSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.ItemListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.network.MeteorExecutor;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_3803;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import net.minecraft.class_9636;

public class AutoGrind extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Integer> delay;
   private final Setting<List<class_1792>> itemBlacklist;
   private final Setting<Set<class_5321<class_1887>>> enchantmentBlacklist;

   public AutoGrind() {
      super(MeteorRejectsAddon.CATEGORY, "auto-grind", "Automatically disenchants items.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.delay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("delay")).description("The tick delay between grinding items.")).defaultValue(50)).sliderMax(500).min(0).build());
      this.itemBlacklist = this.sgGeneral.add(((ItemListSetting.Builder)((ItemListSetting.Builder)(new ItemListSetting.Builder()).name("item-blacklist")).description("Items that should be ignored.")).defaultValue(new class_1792[0]).filter((Item) -> Item.method_57347().method_58694(class_9334.field_49629) != null).build());
      this.enchantmentBlacklist = this.sgGeneral.add(((EnchantmentListSetting.Builder)((EnchantmentListSetting.Builder)(new EnchantmentListSetting.Builder()).name("enchantment-blacklist")).description("Enchantments that should be ignored.")).defaultValue(new class_5321[0]).build());
   }

   @EventHandler
   private void onOpenScreen(OpenScreenEvent event) {
      if (this.mc.field_1724.field_7512 instanceof class_3803) {
         MeteorExecutor.execute(() -> {
            for(int i = 0; i <= this.mc.field_1724.method_31548().method_5439(); ++i) {
               if (this.canGrind(this.mc.field_1724.method_31548().method_5438(i))) {
                  try {
                     Thread.sleep((long)(Integer)this.delay.get());
                  } catch (InterruptedException e) {
                     e.printStackTrace();
                  }

                  if (this.mc.field_1755 == null) {
                     break;
                  }

                  InvUtils.shiftClick().slot(i);
                  InvUtils.move().fromId(2).to(i);
               }
            }

         });
      }
   }

   private boolean canGrind(class_1799 stack) {
      if (((List)this.itemBlacklist.get()).contains(stack.method_7909())) {
         return false;
      } else {
         class_9304 enchantments = class_1890.method_57532(stack);
         int availEnchs = 0;

         for(class_6880<class_1887> enchantment : enchantments.method_57534()) {
            if (!enchantment.method_40220(class_9636.field_51551)) {
               ++availEnchs;
               Optional var10000 = enchantment.method_40230();
               Set var10001 = (Set)this.enchantmentBlacklist.get();
               Objects.requireNonNull(var10001);
               if ((Boolean)var10000.map(var10001::contains).orElse(false)) {
                  return false;
               }
            }
         }

         return !enchantments.method_57543() && availEnchs > 0;
      }
   }
}
