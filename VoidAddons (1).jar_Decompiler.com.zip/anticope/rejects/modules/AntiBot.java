package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.EntityUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1297.class_5529;

public class AntiBot extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgFilters;
   private final Setting<Boolean> removeInvisible;
   private final Setting<Boolean> gameMode;
   private final Setting<Boolean> api;
   private final Setting<Boolean> profile;
   private final Setting<Boolean> latency;
   private final Setting<Boolean> nullException;

   public AntiBot() {
      super(MeteorRejectsAddon.CATEGORY, "anti-bot", "Detects and removes bots.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgFilters = this.settings.createGroup("Filters");
      this.removeInvisible = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("remove-invisible")).description("Removes bot only if they are invisible.")).defaultValue(true)).build());
      this.gameMode = this.sgFilters.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("null-gamemode")).description("Removes players without a gamemode")).defaultValue(true)).build());
      this.api = this.sgFilters.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("null-entry")).description("Removes players without a player entry")).defaultValue(true)).build());
      this.profile = this.sgFilters.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("null-profile")).description("Removes players without a game profile")).defaultValue(true)).build());
      this.latency = this.sgFilters.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("ping-check")).description("Removes players using ping check")).defaultValue(false)).build());
      this.nullException = this.sgFilters.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("null-exception")).description("Removes players if a NullPointerException occurred")).defaultValue(false)).build());
   }

   @EventHandler
   public void onTick(TickEvent.Post tickEvent) {
      for(class_1297 entity : this.mc.field_1687.method_18112()) {
         if (entity instanceof class_1657 playerEntity) {
            if ((!(Boolean)this.removeInvisible.get() || entity.method_5767()) && this.isBot(playerEntity)) {
               entity.method_5650(class_5529.field_26999);
            }
         }
      }

   }

   private boolean isBot(class_1657 entity) {
      try {
         if ((Boolean)this.gameMode.get() && EntityUtils.getGameMode(entity) == null) {
            return true;
         }

         if ((Boolean)this.api.get() && this.mc.method_1562().method_2871(entity.method_5667()) == null) {
            return true;
         }

         if ((Boolean)this.profile.get() && this.mc.method_1562().method_2871(entity.method_5667()).method_2966() == null) {
            return true;
         }

         if ((Boolean)this.latency.get() && this.mc.method_1562().method_2871(entity.method_5667()).method_2959() > 1) {
            return true;
         }
      } catch (NullPointerException var3) {
         if ((Boolean)this.nullException.get()) {
            return true;
         }
      }

      return false;
   }
}
