package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.settings.StringMapSetting;
import anticope.rejects.utils.RejectsUtils;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.widgets.WWidget;
import meteordevelopment.meteorclient.gui.widgets.containers.WHorizontalList;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_5250;
import net.minecraft.class_7472;

public class AutoLogin extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Integer> delay;
   private final Setting<Boolean> smart;
   private final Setting<Map<String, String>> commands;
   private final Timer timer;

   public AutoLogin() {
      super(MeteorRejectsAddon.CATEGORY, "auto-login", "Runs command when joining specified server.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.delay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("delay")).description("Delay in ms before executing the command.")).defaultValue(1000)).min(0).sliderMax(10000).build());
      this.smart = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("smart")).description("Auto add the entries.")).defaultValue(false)).build());
      this.commands = this.sgGeneral.add(((StringMapSetting.Builder)((StringMapSetting.Builder)(new StringMapSetting.Builder()).name("commands")).description("Server and commands. (* for universal)")).defaultValue(new LinkedHashMap<String, String>() {
         {
            this.put("localhost", "/login 123456");
         }
      }).build());
      this.timer = new Timer();
      this.runInMainMenu = true;
   }

   public WWidget getWidget(GuiTheme theme) {
      WHorizontalList l = theme.horizontalList();
      WButton btn = (WButton)l.add(theme.button("Random generate password")).widget();
      btn.action = () -> {
         String password = RejectsUtils.getRandomPassword(16);
         class_5250 text = class_2561.method_43470(String.valueOf(class_124.field_1067) + "Click here to register securely.");
         text.method_10862(text.method_10866().method_10958(new class_2558.class_10609(String.format("/register %s %s", password, password))));
         this.info(text);
      };
      return l;
   }

   @EventHandler
   private void onGameJoined(GameJoinedEvent event) {
      if (this.isActive()) {
         final String command = (String)((Map)this.commands.get()).getOrDefault("*", (String)((Map)this.commands.get()).get(Utils.getWorldName()));
         if (command != null) {
            this.timer.schedule(new TimerTask() {
               public void run() {
                  if (AutoLogin.this.mc.field_1724 != null) {
                     ChatUtils.sendPlayerMsg(command);
                  }

               }
            }, (long)(Integer)this.delay.get());
         }

      }
   }

   @EventHandler
   private void onPacketSent(PacketEvent.Send event) {
      if ((Boolean)this.smart.get()) {
         class_2596 var3 = event.packet;
         if (var3 instanceof class_7472) {
            class_7472 packet = (class_7472)var3;
            String command = packet.comp_808();
            List<String> hint = Arrays.asList("reg", "register", "l", "login", "log");
            String[] cmds = command.split(" ");
            if (cmds.length >= 2 && hint.contains(cmds[0])) {
               ((Map)this.commands.get()).put(Utils.getWorldName(), "/login " + cmds[1]);
            }
         }

      }
   }
}
