package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.PlaySoundEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.SoundEventListSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1113;
import net.minecraft.class_1146;
import net.minecraft.class_124;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3414;
import net.minecraft.class_5250;

public class SoundLocator extends Module {
   private final SettingGroup sgGeneral;
   private final SettingGroup sgRender;
   private final Setting<Boolean> whitelist;
   private final Setting<List<class_3414>> sounds;
   private final Setting<Boolean> chatActive;
   private final Setting<Integer> timeS;
   private final Setting<Boolean> renderActive;
   private final Setting<ShapeMode> shapeMode;
   private final Setting<SettingColor> sideColor;
   private final Setting<SettingColor> lineColor;
   private List<class_243> renderPos;
   private List<Integer> delay;

   public SoundLocator() {
      super(MeteorRejectsAddon.CATEGORY, "sound-locator", "Prints locations of sound events.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.sgRender = this.settings.createGroup("Render");
      this.whitelist = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("whitelist")).description("Enable sounds filter whitelist.")).defaultValue(false)).build());
      SettingGroup var10001 = this.sgGeneral;
      SoundEventListSetting.Builder var10002 = (SoundEventListSetting.Builder)((SoundEventListSetting.Builder)((SoundEventListSetting.Builder)(new SoundEventListSetting.Builder()).name("sounds")).description("Sounds to find.")).defaultValue(new ArrayList(0));
      Setting var10003 = this.whitelist;
      Objects.requireNonNull(var10003);
      this.sounds = var10001.add(((SoundEventListSetting.Builder)var10002.visible(var10003::get)).build());
      this.chatActive = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("log-chat")).description("Send the position of the sound in the chat.")).defaultValue(false)).build());
      this.timeS = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("time")).description("The time between the sounds verification.")).defaultValue(60)).build());
      this.renderActive = this.sgRender.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("render-positions")).description("Renders boxes where the sound was emitted.")).defaultValue(true)).build());
      this.shapeMode = this.sgRender.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("shape-mode")).description("How the shapes are rendered.")).defaultValue(ShapeMode.Both)).build());
      this.sideColor = this.sgRender.add(((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("side-color")).description("The side color of the target sound rendering.")).defaultValue(new SettingColor(255, 0, 0, 70)).build());
      this.lineColor = this.sgRender.add(((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("line-color")).description("The line color of the target sound rendering.")).defaultValue(new SettingColor(255, 0, 0)).build());
      this.renderPos = new ArrayList();
      this.delay = new ArrayList();
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      Iterator<Integer> iterator = this.delay.iterator();

      while(iterator.hasNext()) {
         int time = (Integer)iterator.next();
         if (time <= 0) {
            iterator.remove();
            this.renderPos.remove(0);
         } else {
            this.delay.set(this.delay.indexOf(time), time - 1);
         }
      }

   }

   @EventHandler
   private void onPlaySound(PlaySoundEvent event) {
      if ((Boolean)this.whitelist.get()) {
         for(class_3414 sound : (List)this.sounds.get()) {
            if (sound.comp_3319().equals(event.sound.method_4775())) {
               this.printSound(event.sound);
               break;
            }
         }
      } else {
         this.printSound(event.sound);
      }

   }

   private void printSound(class_1113 sound) {
      class_1146 soundSet = this.mc.method_1483().method_4869(sound.method_4775());
      class_243 pos = new class_243(sound.method_4784() - (double)0.5F, sound.method_4779() - (double)0.5F, sound.method_4778() - (double)0.5F);
      if (!this.renderPos.contains(pos)) {
         this.renderPos.add(pos);
         this.delay.add((Integer)this.timeS.get());
         if ((Boolean)this.chatActive.get()) {
            class_5250 text;
            if (soundSet != null && soundSet.method_4886() != null) {
               text = soundSet.method_4886().method_27661();
            } else {
               text = class_2561.method_43470(sound.method_4775().toString());
            }

            text.method_27693(String.format("%s at ", class_124.field_1070));
            text.method_10852(ChatUtils.formatCoords(pos));
            text.method_27693(String.format("%s.", class_124.field_1070));
            this.info(text);
         }
      }

   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if ((Boolean)this.renderActive.get()) {
         this.renderPos.forEach((pos) -> event.renderer.box(class_238.method_29968(pos), (Color)this.sideColor.get(), (Color)this.lineColor.get(), (ShapeMode)this.shapeMode.get(), 0));
      }

   }
}
