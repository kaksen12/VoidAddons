package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.mixininterface.IInventoryTweaks;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.packets.InventoryEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StorageBlockListSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.misc.InventoryTweaks;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.meteorclient.utils.player.SlotUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_3965;

public class ChestAura extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Boolean> rotate;
   private final Setting<Double> range;
   private final Setting<List<class_2591<?>>> blocks;
   private final Setting<Integer> delay;
   private final Setting<Integer> forget;
   private final Setting<CloseCondition> closeCondition;
   private final Map<class_2338, Integer> openedBlocks;
   private final CloseListener closeListener;
   private int timer;

   public ChestAura() {
      super(MeteorRejectsAddon.CATEGORY, "chest-aura", "Automatically open chests in radius");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.rotate = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("rotate")).description("Rotates when opening.")).defaultValue(true)).build());
      this.range = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("range")).description("The interact range.")).defaultValue((double)4.0F).min((double)0.0F).build());
      this.blocks = this.sgGeneral.add(((StorageBlockListSetting.Builder)((StorageBlockListSetting.Builder)(new StorageBlockListSetting.Builder()).name("blocks")).description("The blocks you open.")).defaultValue(new class_2591[]{class_2591.field_11914}).build());
      this.delay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("delay")).description("Delay between opening chests.")).defaultValue(10)).sliderMax(20).build());
      this.forget = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("forget-after")).description("How many ticks to wait before forgetting which chest to open. 0 for infinite.")).defaultValue(0)).min(0).sliderMax(1000).build());
      this.closeCondition = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("close-condition")).defaultValue(ChestAura.CloseCondition.IfEmpty)).description("When to close the chest screen.")).build());
      this.openedBlocks = new HashMap();
      this.closeListener = new CloseListener();
      this.timer = 0;
   }

   public void onActivate() {
      this.timer = 0;
      this.openedBlocks.clear();
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      if ((Integer)this.forget.get() != 0) {
         for(Map.Entry<class_2338, Integer> e : (new HashMap(this.openedBlocks)).entrySet()) {
            int time = (Integer)e.getValue();
            if (time > (Integer)this.forget.get()) {
               this.openedBlocks.remove(e.getKey());
            } else {
               this.openedBlocks.replace((class_2338)e.getKey(), time + 1);
            }
         }
      }

      if (this.timer <= 0 || this.mc.field_1755 == null) {
         for(class_2586 block : Utils.blockEntities()) {
            if (((List)this.blocks.get()).contains(block.method_11017()) && !(this.mc.field_1724.method_33571().method_1022(class_243.method_24953(block.method_11016())) >= (Double)this.range.get())) {
               class_2338 pos = block.method_11016();
               if (!this.openedBlocks.containsKey(pos)) {
                  Runnable click = () -> this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, new class_3965(new class_243((double)pos.method_10263(), (double)pos.method_10264(), (double)pos.method_10260()), class_2350.field_11036, pos, false));
                  if ((Boolean)this.rotate.get()) {
                     Rotations.rotate(Rotations.getYaw(pos), Rotations.getPitch(pos), click);
                  } else {
                     click.run();
                  }

                  class_2680 state = block.method_11010();
                  if (state.method_28498(class_2281.field_10770)) {
                     class_2350 direction = (class_2350)state.method_11654(class_2281.field_10768);
                     switch ((class_2745)state.method_11654(class_2281.field_10770)) {
                        case field_12574 -> this.openedBlocks.put(pos.method_10093(direction.method_10170()), 0);
                        case field_12571 -> this.openedBlocks.put(pos.method_10093(direction.method_10160()), 0);
                     }
                  }

                  this.openedBlocks.put(pos, 0);
                  this.timer = (Integer)this.delay.get();
                  MeteorClient.EVENT_BUS.subscribe(this.closeListener);
                  break;
               }
            }
         }

         --this.timer;
      }
   }

   public class CloseListener {
      @EventHandler(
         priority = 100
      )
      private void onInventory(InventoryEvent event) {
         class_1703 handler = ChestAura.this.mc.field_1724.field_7512;
         if (event.packet.comp_3837() == handler.field_7763) {
            switch (((CloseCondition)ChestAura.this.closeCondition.get()).ordinal()) {
               case 0:
                  ChestAura.this.mc.field_1724.method_7346();
                  break;
               case 1:
                  class_2371<class_1799> stacks = class_2371.method_10211();
                  IntStream var10000 = IntStream.range(0, SlotUtils.indexToId(9));
                  class_2371 var10001 = handler.field_7761;
                  Objects.requireNonNull(var10001);
                  Stream var4 = var10000.mapToObj(var10001::get).map(class_1735::method_7677);
                  Objects.requireNonNull(stacks);
                  var4.forEach(stacks::add);
                  if (stacks.stream().allMatch(class_1799::method_7960)) {
                     ChestAura.this.mc.field_1724.method_7346();
                  }
                  break;
               case 2:
                  ((IInventoryTweaks)Modules.get().get(InventoryTweaks.class)).stealCallback(() -> ChestAura.this.mc.field_1724.method_7346());
            }
         }

         MeteorClient.EVENT_BUS.unsubscribe(this);
      }
   }

   public static enum CloseCondition {
      Always,
      IfEmpty,
      AfterSteal,
      Never;

      // $FF: synthetic method
      private static CloseCondition[] $values() {
         return new CloseCondition[]{Always, IfEmpty, AfterSteal, Never};
      }
   }
}
