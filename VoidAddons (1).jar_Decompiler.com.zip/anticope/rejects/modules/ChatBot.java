package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.settings.StringMapSetting;
import java.util.LinkedHashMap;
import java.util.Map;
import meteordevelopment.meteorclient.events.game.ReceiveMessageEvent;
import meteordevelopment.meteorclient.gui.utils.StarscriptTextBoxRenderer;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.MeteorStarscript;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import org.meteordev.starscript.Script;
import org.meteordev.starscript.Section;
import org.meteordev.starscript.compiler.Compiler;
import org.meteordev.starscript.compiler.Parser;
import org.meteordev.starscript.utils.Error;
import org.meteordev.starscript.utils.StarscriptError;

public class ChatBot extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<String> prefix;
   private final Setting<Boolean> help;
   private final Setting<Map<String, String>> commands;

   public ChatBot() {
      super(MeteorRejectsAddon.CATEGORY, "chat-bot", "Bot which automatically responds to chat messages.");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.prefix = this.sgGeneral.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("prefix")).description("Command prefix for the bot.")).defaultValue("!")).build());
      this.help = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("help")).description("Add help command.")).defaultValue(true)).build());
      this.commands = this.sgGeneral.add(((StringMapSetting.Builder)((StringMapSetting.Builder)(new StringMapSetting.Builder()).name("commands")).description("Commands.")).renderer(StarscriptTextBoxRenderer.class).defaultValue(new LinkedHashMap<String, String>() {
         {
            this.put("ping", "Pong!");
            this.put("tps", "Current TPS: {server.tps}");
            this.put("time", "It's currently {server.time}");
            this.put("pos", "I am @ {player.pos}");
         }
      }).build());
   }

   @EventHandler
   private void onMessageReceive(ReceiveMessageEvent event) {
      String msg = event.getMessage().getString();
      if ((Boolean)this.help.get() && msg.endsWith((String)this.prefix.get() + "help")) {
         ChatUtils.sendPlayerMsg("Available commands: " + String.join(", ", ((Map)this.commands.get()).keySet()));
      } else {
         for(String cmd : ((Map)this.commands.get()).keySet()) {
            String var10001 = (String)this.prefix.get();
            if (msg.endsWith(var10001 + cmd)) {
               Script script = compile((String)((Map)this.commands.get()).get(cmd));
               if (script == null) {
                  ChatUtils.sendPlayerMsg("An error occurred");
               }

               try {
                  Section section = MeteorStarscript.ss.run(script);
                  ChatUtils.sendPlayerMsg(section.text);
               } catch (StarscriptError e) {
                  MeteorStarscript.printChatError(e);
                  ChatUtils.sendPlayerMsg("An error occurred");
               }

               return;
            }
         }

      }
   }

   private static Script compile(String script) {
      if (script == null) {
         return null;
      } else {
         Parser.Result result = Parser.parse(script);
         if (result.hasErrors()) {
            MeteorStarscript.printChatError((Error)result.errors.get(0));
            return null;
         } else {
            return Compiler.compile(result);
         }
      }
   }
}
