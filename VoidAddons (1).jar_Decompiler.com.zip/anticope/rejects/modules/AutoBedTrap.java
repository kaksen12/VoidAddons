package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.misc.Pool;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.world.BlockIterator;
import meteordevelopment.meteorclient.utils.world.BlockUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1747;
import net.minecraft.class_2244;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;

public class AutoBedTrap extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Integer> bpt;
   private final Setting<Boolean> rotate;
   private final Setting<Double> range;
   private final Setting<List<class_2248>> blockTypes;
   private final Pool<class_2338.class_2339> blockPosPool;
   private final List<class_2338.class_2339> blocks;
   int cap;

   public AutoBedTrap() {
      super(MeteorRejectsAddon.CATEGORY, "auto-bed-trap", "Automatically places obsidian around beds");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.bpt = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("blocks-per-tick")).description("How many blocks to place per tick")).defaultValue(2)).min(1).sliderMax(8).build());
      this.rotate = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("rotate")).description("Rotates when placing")).defaultValue(true)).build());
      this.range = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("range")).description("The break range.")).defaultValue((double)4.0F).min((double)0.0F).build());
      this.blockTypes = this.sgGeneral.add(((BlockListSetting.Builder)((BlockListSetting.Builder)((BlockListSetting.Builder)(new BlockListSetting.Builder()).name("blocks")).description("The blocks you bedtrap with.")).defaultValue(Arrays.asList(class_2246.field_10540))).build());
      this.blockPosPool = new Pool(class_2338.class_2339::new);
      this.blocks = new ArrayList();
      this.cap = 0;
   }

   public void onDeactivate() {
      for(class_2338.class_2339 blockPos : this.blocks) {
         this.blockPosPool.free(blockPos);
      }

      this.blocks.clear();
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      BlockIterator.register((int)Math.ceil((Double)this.range.get()), (int)Math.ceil((Double)this.range.get()), (blockPos, blockState) -> {
         if (BlockUtils.canBreak(blockPos, blockState)) {
            if (blockState.method_26204() instanceof class_2244) {
               this.blocks.add(((class_2338.class_2339)this.blockPosPool.get()).method_10101(blockPos));
            }
         }
      });
   }

   @EventHandler
   private void onTickPost(TickEvent.Post event) {
      boolean noBlocks = false;

      for(class_2338 blockPos : this.blocks) {
         if (!this.placeTickAround(blockPos)) {
            noBlocks = true;
            break;
         }
      }

      if (noBlocks && this.isActive()) {
         this.toggle();
      }

   }

   public boolean placeTickAround(class_2338 block) {
      for(class_2338 b : new class_2338[]{block.method_10084(), block.method_10067(), block.method_10095(), block.method_10072(), block.method_10078(), block.method_10074()}) {
         if (this.cap >= (Integer)this.bpt.get()) {
            this.cap = 0;
            return true;
         }

         if (((List)this.blockTypes.get()).contains(this.mc.field_1687.method_8320(b).method_26204())) {
            return true;
         }

         FindItemResult findBlock = InvUtils.findInHotbar((item) -> {
            if (!(item.method_7909() instanceof class_1747)) {
               return false;
            } else {
               class_1747 bitem = (class_1747)item.method_7909();
               return ((List)this.blockTypes.get()).contains(bitem.method_7711());
            }
         });
         if (!findBlock.found()) {
            this.error("No specified blocks found. Disabling.", new Object[0]);
            return false;
         }

         if (BlockUtils.place(b, findBlock, (Boolean)this.rotate.get(), 10, false)) {
            ++this.cap;
            if (this.cap >= (Integer)this.bpt.get()) {
               return true;
            }
         }
      }

      this.cap = 0;
      return true;
   }
}
