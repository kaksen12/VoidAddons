package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.Objects;
import java.util.Random;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.entity.SortPriority;
import meteordevelopment.meteorclient.utils.entity.TargetUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

public class Confuse extends Module {
   private final SettingGroup sgGeneral;
   private final Setting<Mode> mode;
   private final Setting<Integer> delay;
   private final Setting<Integer> range;
   private final Setting<SortPriority> priority;
   private final Setting<Integer> circleSpeed;
   private final Setting<Boolean> moveThroughBlocks;
   private final Setting<Boolean> budgetGraphics;
   private final Setting<SettingColor> circleColor;
   int delayWaited;
   double circleProgress;
   double addition;
   class_1297 target;

   public Confuse() {
      super(MeteorRejectsAddon.CATEGORY, "confuse", "Makes your enemies shit themselves");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.mode = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("mode")).defaultValue(Confuse.Mode.RandomTP)).description("Mode")).build());
      this.delay = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("delay")).description("Delay")).defaultValue(3)).min(0).sliderMax(20).build());
      this.range = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("radius")).description("Range to confuse opponents")).defaultValue(6)).min(0).sliderMax(10).build());
      this.priority = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("priority")).description("Targeting priority")).defaultValue(SortPriority.LowestHealth)).build());
      this.circleSpeed = this.sgGeneral.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("circle-speed")).description("Circle mode speed")).defaultValue(10)).min(1).sliderMax(180).build());
      this.moveThroughBlocks = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("move-through-blocks")).defaultValue(false)).build());
      this.budgetGraphics = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("budget-graphics")).defaultValue(false)).build());
      SettingGroup var10001 = this.sgGeneral;
      ColorSetting.Builder var10002 = ((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("circle-color")).description("Color for circle rendering")).defaultValue(new SettingColor(0, 255, 0));
      Setting var10003 = this.budgetGraphics;
      Objects.requireNonNull(var10003);
      this.circleColor = var10001.add(((ColorSetting.Builder)var10002.visible(var10003::get)).build());
      this.delayWaited = 0;
      this.circleProgress = (double)0.0F;
      this.addition = (double)0.0F;
      this.target = null;
   }

   public void onActivate() {
      this.delayWaited = 0;
      this.circleProgress = (double)0.0F;
      this.addition = (double)0.0F;
      this.target = null;
   }

   @EventHandler
   private void onTick(TickEvent.Pre event) {
      ++this.delayWaited;
      if (this.delayWaited >= (Integer)this.delay.get()) {
         this.delayWaited = 0;
         this.target = TargetUtils.getPlayerTarget((double)(Integer)this.range.get(), (SortPriority)this.priority.get());
         if (this.target != null) {
            class_243 entityPos = this.target.method_73189();
            class_243 playerPos = this.mc.field_1724.method_73189();
            Random r = new Random();
            int halfRange = (Integer)this.range.get() / 2;
            switch (((Mode)this.mode.get()).ordinal()) {
               case 0:
                  double x = r.nextDouble() * (double)(Integer)this.range.get() - (double)halfRange;
                  double y = (double)0.0F;
                  double z = r.nextDouble() * (double)(Integer)this.range.get() - (double)halfRange;
                  class_243 addend = new class_243(x, y, z);
                  class_243 goal = entityPos.method_1019(addend);
                  if (this.mc.field_1687.method_8320(class_2338.method_49637(goal.field_1352, goal.field_1351, goal.field_1350)).method_26204() != class_2246.field_10124) {
                     goal = new class_243(x, playerPos.field_1351, z);
                  }

                  if (this.mc.field_1687.method_8320(class_2338.method_49637(goal.field_1352, goal.field_1351, goal.field_1350)).method_26204() == class_2246.field_10124) {
                     class_3965 hit = this.mc.field_1687.method_17742(new class_3959(this.mc.field_1724.method_73189(), goal, class_3960.field_17558, class_242.field_1347, this.mc.field_1724));
                     if (!(Boolean)this.moveThroughBlocks.get() && hit.method_17781()) {
                        this.delayWaited = (Integer)this.delay.get() - 1;
                     } else {
                        this.mc.field_1724.method_30634(goal.field_1352, goal.field_1351, goal.field_1350);
                     }
                  } else {
                     this.delayWaited = (Integer)this.delay.get() - 1;
                  }
                  break;
               case 1:
                  class_243 diff = entityPos.method_1020(playerPos);
                  class_243 diff1 = new class_243(class_3532.method_15350(diff.field_1352, (double)(-halfRange), (double)halfRange), class_3532.method_15350(diff.field_1351, (double)(-halfRange), (double)halfRange), class_3532.method_15350(diff.field_1350, (double)(-halfRange), (double)halfRange));
                  class_243 goal2 = entityPos.method_1019(diff1);
                  class_3965 hit = this.mc.field_1687.method_17742(new class_3959(this.mc.field_1724.method_73189(), goal2, class_3960.field_17558, class_242.field_1347, this.mc.field_1724));
                  if (!(Boolean)this.moveThroughBlocks.get() && hit.method_17781()) {
                     this.delayWaited = (Integer)this.delay.get() - 1;
                  } else {
                     this.mc.field_1724.method_30634(goal2.field_1352, goal2.field_1351, goal2.field_1350);
                  }
                  break;
               case 2:
                  this.delay.set(0);
                  this.circleProgress += (double)(Integer)this.circleSpeed.get();
                  if (this.circleProgress > (double)360.0F) {
                     this.circleProgress -= (double)360.0F;
                  }

                  double rad = Math.toRadians(this.circleProgress);
                  double sin = Math.sin(rad) * (double)3.0F;
                  double cos = Math.cos(rad) * (double)3.0F;
                  class_243 current = new class_243(entityPos.field_1352 + sin, playerPos.field_1351, entityPos.field_1350 + cos);
                  class_3965 hit = this.mc.field_1687.method_17742(new class_3959(this.mc.field_1724.method_73189(), current, class_3960.field_17558, class_242.field_1347, this.mc.field_1724));
                  if ((Boolean)this.moveThroughBlocks.get() || !hit.method_17781()) {
                     this.mc.field_1724.method_30634(current.field_1352, current.field_1351, current.field_1350);
                  }
            }

         }
      }
   }

   @EventHandler
   private void onRender(Render3DEvent event) {
      if (this.target != null) {
         boolean flag = (Boolean)this.budgetGraphics.get();
         class_243 last = null;
         this.addition += flag ? (double)0.0F : (double)1.0F;
         if (this.addition > (double)360.0F) {
            this.addition = (double)0.0F;
         }

         for(int i = 0; i < 360; i += flag ? 7 : 1) {
            Color c1;
            if (flag) {
               c1 = (Color)this.circleColor.get();
            } else {
               double rot = (double)765.0F * (((double)i + this.addition) % (double)360.0F / (double)360.0F);
               int seed = (int)Math.floor(rot / (double)255.0F);
               double current = rot % (double)255.0F;
               double red = seed == 0 ? current : (seed == 1 ? Math.abs(current - (double)255.0F) : (double)0.0F);
               double green = seed == 1 ? current : (seed == 2 ? Math.abs(current - (double)255.0F) : (double)0.0F);
               double blue = seed == 2 ? current : (seed == 0 ? Math.abs(current - (double)255.0F) : (double)0.0F);
               c1 = new Color((int)red, (int)green, (int)blue);
            }

            class_243 tp = this.target.method_73189();
            double rad = Math.toRadians((double)i);
            double sin = Math.sin(rad) * (double)3.0F;
            double cos = Math.cos(rad) * (double)3.0F;
            class_243 c = new class_243(tp.field_1352 + sin, tp.field_1351 + (double)(this.target.method_17682() / 2.0F), tp.field_1350 + cos);
            if (last != null) {
               event.renderer.line(last.field_1352, last.field_1351, last.field_1350, c.field_1352, c.field_1351, c.field_1350, c1);
            }

            last = c;
         }

      }
   }

   public static enum Mode {
      RandomTP,
      Switch,
      Circle;

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{RandomTP, Switch, Circle};
      }
   }
}
