package anticope.rejects.modules;

import anticope.rejects.MeteorRejectsAddon;
import java.util.HashSet;
import meteordevelopment.meteorclient.events.entity.player.PlayerMoveEvent;
import meteordevelopment.meteorclient.events.entity.player.SendMovementPacketsEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10182;
import net.minecraft.class_243;
import net.minecraft.class_2708;
import net.minecraft.class_2793;
import net.minecraft.class_2828;

public class PacketFly extends Module {
   private final HashSet<class_2828> packets = new HashSet();
   private final SettingGroup sgMovement;
   private final SettingGroup sgClient;
   private final SettingGroup sgBypass;
   private final Setting<Double> horizontalSpeed;
   private final Setting<Double> verticalSpeed;
   private final Setting<Boolean> sendTeleport;
   private final Setting<Boolean> setYaw;
   private final Setting<Boolean> setMove;
   private final Setting<Boolean> setPos;
   private final Setting<Boolean> setID;
   private final Setting<Boolean> antiKick;
   private final Setting<Integer> downDelay;
   private final Setting<Integer> downDelayFlying;
   private final Setting<Boolean> invalidPacket;
   private int flightCounter;
   private int teleportID;

   public PacketFly() {
      super(MeteorRejectsAddon.CATEGORY, "packet-fly", "Fly using packets.");
      this.sgMovement = this.settings.createGroup("movement");
      this.sgClient = this.settings.createGroup("client");
      this.sgBypass = this.settings.createGroup("bypass");
      this.horizontalSpeed = this.sgMovement.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("horizontal-speed")).description("Horizontal speed in blocks per second.")).defaultValue(5.2).min((double)0.0F).max((double)20.0F).sliderMin((double)0.0F).sliderMax((double)20.0F).build());
      this.verticalSpeed = this.sgMovement.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("vertical-speed")).description("Vertical speed in blocks per second.")).defaultValue(1.24).min((double)0.0F).max((double)20.0F).sliderMin((double)0.0F).sliderMax((double)20.0F).build());
      this.sendTeleport = this.sgMovement.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("teleport")).description("Sends teleport packets.")).defaultValue(true)).build());
      this.setYaw = this.sgClient.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("set-yaw")).description("Sets yaw client side.")).defaultValue(true)).build());
      this.setMove = this.sgClient.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("set-move")).description("Sets movement client side.")).defaultValue(false)).build());
      this.setPos = this.sgClient.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("set-pos")).description("Sets position client side.")).defaultValue(false)).build());
      this.setID = this.sgClient.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("set-id")).description("Updates teleport id when a position packet is received.")).defaultValue(false)).build());
      this.antiKick = this.sgBypass.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("anti-kick")).description("Moves down occasionally to prevent kicks.")).defaultValue(true)).build());
      this.downDelay = this.sgBypass.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("down-delay")).description("How often you move down when not flying upwards. (ticks)")).defaultValue(4)).sliderMin(1).sliderMax(30).min(1).max(30).build());
      this.downDelayFlying = this.sgBypass.add(((IntSetting.Builder)((IntSetting.Builder)((IntSetting.Builder)(new IntSetting.Builder()).name("flying-down-delay")).description("How often you move down when flying upwards. (ticks)")).defaultValue(10)).sliderMin(1).sliderMax(30).min(1).max(30).build());
      this.invalidPacket = this.sgBypass.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("invalid-packet")).description("Sends invalid movement packets.")).defaultValue(false)).build());
      this.flightCounter = 0;
      this.teleportID = 0;
   }

   @EventHandler
   public void onSendMovementPackets(SendMovementPacketsEvent.Pre event) {
      this.mc.field_1724.method_18800((double)0.0F, (double)0.0F, (double)0.0F);
      double speed = (double)0.0F;
      boolean checkCollisionBoxes = this.checkHitBoxes();
      speed = this.mc.field_1724.field_3913.field_54155.comp_3163() && (checkCollisionBoxes || (double)this.mc.field_1724.field_3913.method_3128().field_1342 == (double)0.0F && (double)this.mc.field_1724.field_3913.method_3128().field_1343 == (double)0.0F) ? ((Boolean)this.antiKick.get() && !checkCollisionBoxes ? (this.resetCounter((Integer)this.downDelayFlying.get()) ? -0.032 : (Double)this.verticalSpeed.get() / (double)20.0F) : (Double)this.verticalSpeed.get() / (double)20.0F) : (this.mc.field_1724.field_3913.field_54155.comp_3164() ? (Double)this.verticalSpeed.get() / (double)-20.0F : (!checkCollisionBoxes ? (this.resetCounter((Integer)this.downDelay.get()) ? ((Boolean)this.antiKick.get() ? -0.04 : (double)0.0F) : (double)0.0F) : (double)0.0F));
      class_243 horizontal = PlayerUtils.getHorizontalVelocity((Double)this.horizontalSpeed.get());
      this.mc.field_1724.method_18800(horizontal.field_1352, speed, horizontal.field_1350);
      this.sendPackets(this.mc.field_1724.method_18798().field_1352, this.mc.field_1724.method_18798().field_1351, this.mc.field_1724.method_18798().field_1350, (Boolean)this.sendTeleport.get());
   }

   @EventHandler
   public void onMove(PlayerMoveEvent event) {
      if ((Boolean)this.setMove.get() && this.flightCounter != 0) {
         event.movement = new class_243(this.mc.field_1724.method_18798().field_1352, this.mc.field_1724.method_18798().field_1351, this.mc.field_1724.method_18798().field_1350);
      }

   }

   @EventHandler
   public void onPacketSent(PacketEvent.Send event) {
      if (event.packet instanceof class_2828 && !this.packets.remove((class_2828)event.packet)) {
         event.setCancelled(true);
      }

   }

   @EventHandler
   public void onPacketReceive(PacketEvent.Receive event) {
      if (event.packet instanceof class_2708 && this.mc.field_1724 != null && this.mc.field_1687 != null) {
         class_2708 packet = (class_2708)event.packet;
         class_10182 oldPos = packet.comp_3228();
         if ((Boolean)this.setYaw.get()) {
            class_10182 newPos = new class_10182(oldPos.comp_3148(), oldPos.comp_3149(), this.mc.field_1724.method_36454(), this.mc.field_1724.method_36455());
            event.packet = class_2708.method_63542(packet.comp_3133(), newPos, packet.comp_3229());
         }

         if ((Boolean)this.setID.get()) {
            this.teleportID = packet.comp_3133();
         }
      }

   }

   private boolean checkHitBoxes() {
      return !this.mc.field_1687.method_20812(this.mc.field_1724, this.mc.field_1724.method_5829().method_1012((double)-0.0625F, (double)-0.0625F, (double)-0.0625F)).iterator().hasNext();
   }

   private boolean resetCounter(int counter) {
      if (++this.flightCounter >= counter) {
         this.flightCounter = 0;
         return true;
      } else {
         return false;
      }
   }

   private void sendPackets(double x, double y, double z, boolean teleport) {
      class_243 vec = new class_243(x, y, z);
      class_243 playerPos = new class_243(this.mc.field_1724.method_23317(), this.mc.field_1724.method_23318(), this.mc.field_1724.method_23321());
      class_243 position = playerPos.method_1019(vec);
      class_243 outOfBoundsVec = this.outOfBoundsVec(vec, position);
      this.packetSender(new class_2828.class_2829(position.field_1352, position.field_1351, position.field_1350, this.mc.field_1724.method_24828(), this.mc.field_1724.field_5976));
      if ((Boolean)this.invalidPacket.get()) {
         this.packetSender(new class_2828.class_2829(outOfBoundsVec.field_1352, outOfBoundsVec.field_1351, outOfBoundsVec.field_1350, this.mc.field_1724.method_24828(), this.mc.field_1724.field_5976));
      }

      if ((Boolean)this.setPos.get()) {
         this.mc.field_1724.method_23327(position.field_1352, position.field_1351, position.field_1350);
      }

      this.teleportPacket(position, teleport);
   }

   private void teleportPacket(class_243 pos, boolean shouldTeleport) {
      if (shouldTeleport) {
         this.mc.field_1724.field_3944.method_52787(new class_2793(++this.teleportID));
      }

   }

   private class_243 outOfBoundsVec(class_243 offset, class_243 position) {
      return position.method_1031((double)0.0F, (double)1500.0F, (double)0.0F);
   }

   private void packetSender(class_2828 packet) {
      this.packets.add(packet);
      this.mc.field_1724.field_3944.method_52787(packet);
   }
}
