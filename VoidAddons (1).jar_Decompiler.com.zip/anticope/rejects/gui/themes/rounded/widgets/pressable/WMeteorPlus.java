package anticope.rejects.gui.themes.rounded.widgets.pressable;

import anticope.rejects.gui.themes.rounded.MeteorRoundedGuiTheme;
import anticope.rejects.gui.themes.rounded.MeteorWidget;
import meteordevelopment.meteorclient.gui.renderer.GuiRenderer;
import meteordevelopment.meteorclient.gui.widgets.pressable.WPlus;
import meteordevelopment.meteorclient.utils.render.color.Color;

public class WMeteorPlus extends WPlus implements MeteorWidget {
   protected void onRender(GuiRenderer renderer, double mouseX, double mouseY, double delta) {
      MeteorRoundedGuiTheme theme = this.theme();
      double pad = this.pad();
      double s = theme.scale((double)3.0F);
      this.renderBackground(renderer, this, this.pressed, this.mouseOver);
      renderer.quad(this.x + pad, this.y + this.height / (double)2.0F - s / (double)2.0F, this.width - pad * (double)2.0F, s, (Color)theme.plusColor.get());
      renderer.quad(this.x + this.width / (double)2.0F - s / (double)2.0F, this.y + pad, s, this.height - pad * (double)2.0F, (Color)theme.plusColor.get());
   }
}
