package anticope.rejects.gui.themes.rounded.widgets;

import anticope.rejects.gui.themes.rounded.MeteorRoundedGuiTheme;
import anticope.rejects.gui.themes.rounded.MeteorWidget;
import meteordevelopment.meteorclient.gui.renderer.GuiRenderer;
import meteordevelopment.meteorclient.gui.widgets.WHorizontalSeparator;
import meteordevelopment.meteorclient.utils.render.color.Color;

public class WMeteorHorizontalSeparator extends WHorizontalSeparator implements MeteorWidget {
   public WMeteorHorizontalSeparator(String text) {
      super(text);
   }

   protected void onRender(GuiRenderer renderer, double mouseX, double mouseY, double delta) {
      if (this.text == null) {
         this.renderWithoutText(renderer);
      } else {
         this.renderWithText(renderer);
      }

   }

   private void renderWithoutText(GuiRenderer renderer) {
      MeteorRoundedGuiTheme theme = this.theme();
      double s = theme.scale((double)1.0F);
      double w = this.width / (double)2.0F;
      renderer.quad(this.x, this.y + s, w, s, (Color)theme.separatorEdges.get(), (Color)theme.separatorCenter.get());
      renderer.quad(this.x + w, this.y + s, w, s, (Color)theme.separatorCenter.get(), (Color)theme.separatorEdges.get());
   }

   private void renderWithText(GuiRenderer renderer) {
      MeteorRoundedGuiTheme theme = this.theme();
      double s = theme.scale((double)2.0F);
      double h = theme.scale((double)1.0F);
      double textStart = (double)Math.round(this.width / (double)2.0F - this.textWidth / (double)2.0F - s);
      double textEnd = s + textStart + this.textWidth + s;
      double offsetY = (double)Math.round(this.height / (double)2.0F);
      renderer.quad(this.x, this.y + offsetY, textStart, h, (Color)theme.separatorEdges.get(), (Color)theme.separatorCenter.get());
      renderer.text(this.text, this.x + textStart + s, this.y, (Color)theme.separatorText.get(), false);
      renderer.quad(this.x + textEnd, this.y + offsetY, this.width - textEnd, h, (Color)theme.separatorCenter.get(), (Color)theme.separatorEdges.get());
   }
}
