package anticope.rejects.gui.servers;

import anticope.rejects.mixin.MultiplayerScreenAccessor;
import anticope.rejects.mixin.ServerListAccessor;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.widgets.WLabel;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.gui.widgets.pressable.WCheckbox;
import meteordevelopment.meteorclient.utils.render.color.Color;
import net.minecraft.class_155;
import net.minecraft.class_4267;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_642;

public class CleanUpScreen extends WindowScreen {
   private final class_500 multiplayerScreen;
   private final WCheckbox removeAll;
   private final WCheckbox removeFailed;
   private final WCheckbox removeOutdated;
   private final WCheckbox removeUnknown;
   private final WCheckbox removeGriefMe;
   private final WCheckbox removeDuplicates;
   private final WCheckbox rename;

   public CleanUpScreen(GuiTheme theme, class_500 multiplayerScreen, class_437 parent) {
      super(theme, "Clean Up");
      this.multiplayerScreen = multiplayerScreen;
      this.parent = parent;
      this.removeUnknown = theme.checkbox(true);
      this.removeOutdated = theme.checkbox(false);
      this.removeFailed = theme.checkbox(true);
      this.removeGriefMe = theme.checkbox(false);
      this.removeAll = theme.checkbox(false);
      this.removeDuplicates = theme.checkbox(true);
      this.rename = theme.checkbox(true);
   }

   public void initWidgets() {
      WTable table = (WTable)this.add(new WTable()).widget();
      table.add(this.theme.label("Remove:"));
      table.row();
      ((WLabel)table.add(this.theme.label("Unknown Hosts:")).widget()).tooltip = "";
      table.add(this.removeUnknown).widget();
      table.row();
      table.add(this.theme.label("Outdated Servers:"));
      table.add(this.removeOutdated).widget();
      table.row();
      table.add(this.theme.label("Failed Ping:"));
      table.add(this.removeFailed).widget();
      table.row();
      table.add(this.theme.label("\"Server discovery\" Servers:"));
      table.add(this.removeGriefMe).widget();
      table.row();
      ((WLabel)table.add(this.theme.label("Everything:")).widget()).color = new Color(255, 0, 0);
      table.add(this.removeAll).widget();
      table.row();
      table.add(this.theme.label("Duplicates:"));
      table.add(this.removeDuplicates).widget();
      table.row();
      table.add(this.theme.label("Rename all Servers:"));
      table.add(this.rename).widget();
      table.row();
      ((WButton)table.add(this.theme.button("Execute!")).expandX().widget()).action = this::cleanUp;
   }

   private void cleanUp() {
      Set<String> knownIPs = new HashSet();
      List<class_642> servers = ((ServerListAccessor)this.multiplayerScreen.method_2529()).getServerList();

      for(class_642 server : (class_642[])servers.toArray((x$0) -> new class_642[x$0])) {
         if (this.removeAll.checked || this.shouldRemove(server, knownIPs)) {
            servers.remove(server);
         }
      }

      if (this.rename.checked) {
         for(int i = 0; i < servers.size(); ++i) {
            class_642 server = (class_642)servers.get(i);
            server.field_3752 = "Server discovery " + (i + 1);
         }
      }

      this.saveServerList();
      this.field_22787.method_1507(this.parent);
   }

   private boolean shouldRemove(class_642 server, Set<String> knownIPs) {
      return server != null && (this.removeUnknown.checked && this.isUnknownHost(server) || this.removeOutdated.checked && !this.isSameProtocol(server) || this.removeFailed.checked && this.isFailedPing(server) || this.removeGriefMe.checked && this.isGriefMeServer(server) || this.removeDuplicates.checked && !knownIPs.add(server.field_3761));
   }

   private boolean isUnknownHost(class_642 server) {
      return server.field_3757 != null && server.field_3757.getString() != null ? server.field_3757.getString().equals("§4Can't resolve hostname") : false;
   }

   private boolean isSameProtocol(class_642 server) {
      return server.field_3756 == class_155.method_16673().comp_4027();
   }

   private boolean isFailedPing(class_642 server) {
      return server.field_3758 != -2L && server.field_3758 < 0L;
   }

   private boolean isGriefMeServer(class_642 server) {
      return server.field_3752 != null && server.field_3752.startsWith("Server discovery ");
   }

   private void saveServerList() {
      this.multiplayerScreen.method_2529().method_2987();
      class_4267 serverListSelector = ((MultiplayerScreenAccessor)this.multiplayerScreen).getServerListWidget();
      serverListSelector.method_20122((class_4267.class_504)null);
      serverListSelector.method_20125(this.multiplayerScreen.method_2529());
   }
}
