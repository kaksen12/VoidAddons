package anticope.rejects.gui.screens;

import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.GuiThemes;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.widgets.containers.WSection;
import meteordevelopment.meteorclient.utils.world.TickRate;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1078;
import net.minecraft.class_1291;
import net.minecraft.class_1292;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_238;
import net.minecraft.class_2477;

public class StatsScreen extends WindowScreen {
   public final class_1297 entity;
   private boolean effectListExpanded = true;
   private boolean attribListExpanded = true;
   private boolean dimensionExpanded = true;

   public StatsScreen(class_1297 e) {
      super(GuiThemes.get(), e.method_5477().getString());
      this.entity = e;
      this.updateData();
      MeteorClient.EVENT_BUS.subscribe(this);
   }

   protected void onClosed() {
      MeteorClient.EVENT_BUS.unsubscribe(this);
      super.onClosed();
   }

   private void updateData() {
      this.clear();
      GuiTheme theme = GuiThemes.get();
      class_2477 lang = class_1078.method_10517();
      this.add(theme.label(String.format("Type: %s", lang.method_48307(this.entity.method_5864().method_5882()))));
      this.add(theme.label(String.format("Age: %d", this.entity.field_6012)));
      this.add(theme.label(String.format("UUID: %s", this.entity.method_5845())));
      class_1297 var4 = this.entity;
      if (var4 instanceof class_1309 liv) {
         this.add(theme.label(String.format("Health: %.2f/%.2f", liv.method_6032(), liv.method_6063())));
         this.add(theme.label(String.format("Armor: %d/20", liv.method_6096())));
         WSection effectList = (WSection)this.add(theme.section("Status Effects", this.effectListExpanded)).expandX().widget();
         effectList.action = () -> this.effectListExpanded = effectList.isExpanded();
         liv.method_6088().forEach((effect, instance) -> {
            String status = lang.method_48307(((class_1291)effect.comp_349()).method_5567());
            float tps = TickRate.INSTANCE.getTickRate();
            if (instance.method_5578() != 0) {
               status = status + String.format(" %d (%s)", instance.method_5578() + 1, class_1292.method_5577(instance, 1.0F, tps));
            } else {
               status = status + String.format(" (%s)", class_1292.method_5577(instance, 1.0F, tps));
            }

            effectList.add(theme.label(status)).expandX();
         });
         if (liv.method_6088().isEmpty()) {
            effectList.add(theme.label("No effects")).expandX();
         }

         WSection attribList = (WSection)this.add(theme.section("Attributes", this.attribListExpanded)).expandX().widget();
         attribList.action = () -> this.attribListExpanded = attribList.isExpanded();
         liv.method_6127().method_60497().forEach((attrib) -> attribList.add(theme.label(String.format("%s: %.2f", lang.method_48307(((class_1320)attrib.method_6198().comp_349()).method_26830()), attrib.method_6194()))).expandX());
      }

      WSection dimension = (WSection)this.add(theme.section("Dimensions", this.dimensionExpanded)).expandX().widget();
      dimension.action = () -> this.dimensionExpanded = dimension.isExpanded();
      dimension.add(theme.label(String.format("Position: %.2f, %.2f, %.2f", this.entity.method_23317(), this.entity.method_23318(), this.entity.method_23321()))).expandX();
      dimension.add(theme.label(String.format("Yaw: %.2f, Pitch: %.2f", this.entity.method_36454(), this.entity.method_36455()))).expandX();
      class_238 box = this.entity.method_5829();
      dimension.add(theme.label(String.format("Bounding Box: %.2f, %.2f, %.2f", box.field_1320 - box.field_1323, box.field_1325 - box.field_1322, box.field_1324 - box.field_1321))).expandX();
   }

   @EventHandler
   private void onTick(TickEvent.Post event) {
      this.updateData();
   }

   public void initWidgets() {
   }
}
