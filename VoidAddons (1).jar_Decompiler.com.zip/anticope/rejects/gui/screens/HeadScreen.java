package anticope.rejects.gui.screens;

import anticope.rejects.utils.GiveUtils;
import com.google.common.reflect.TypeToken;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.WindowScreen;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.Settings;
import meteordevelopment.meteorclient.utils.network.Http;
import meteordevelopment.meteorclient.utils.network.MeteorExecutor;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2495;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2561;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

public class HeadScreen extends WindowScreen {
   private static final Type gsonType = (new TypeToken<List<Map<String, String>>>() {
   }).getType();
   private final Settings settings = new Settings();
   private final SettingGroup sgGeneral;
   private static Categories category;
   private final Setting<Categories> categorySetting;

   public HeadScreen(GuiTheme theme) {
      super(theme, "Heads");
      this.sgGeneral = this.settings.getDefaultGroup();
      this.categorySetting = this.sgGeneral.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("Category")).defaultValue(category)).description("Category")).onChanged((v) -> this.loadHeads())).build());
      this.loadHeads();
   }

   private void set() {
      this.clear();
      this.add(this.theme.settings(this.settings)).expandX();
      this.add(this.theme.horizontalSeparator()).expandX();
   }

   private String getCat() {
      category = (Categories)this.categorySetting.get();
      return category.toString().replace("_", "-");
   }

   private void loadHeads() {
      MeteorExecutor.execute(() -> {
         List<Map<String, String>> res = (List)Http.get("https://minecraft-heads.com/scripts/api.php?cat=" + this.getCat()).sendJson(gsonType);
         List<class_1799> heads = new ArrayList();
         res.forEach((a) -> {
            try {
               heads.add(this.createHeadStack((String)a.get("uuid"), (String)a.get("value"), (String)a.get("name")));
            } catch (Exception var4) {
            }

         });
         WTable t = this.theme.table();

         for(class_1799 head : heads) {
            t.add(this.theme.item(head));
            t.add(this.theme.label(head.method_7964().getString()));
            WButton give = (WButton)t.add(this.theme.button("Give")).widget();
            give.action = () -> {
               try {
                  GiveUtils.giveItem(head);
               } catch (CommandSyntaxException e) {
                  ChatUtils.errorPrefix("Heads", e.getMessage(), new Object[0]);
               }

            };
            WButton equip = (WButton)t.add(this.theme.button("Equip")).widget();
            equip.tooltip = "Equip client-side.";
            equip.action = () -> MeteorClient.mc.field_1724.method_31548().method_5447(39, head);
            t.row();
         }

         this.set();
         this.add(t).expandX().minWidth((double)400.0F).widget();
      });
   }

   private class_1799 createHeadStack(String uuid, String value, String name) {
      class_1799 head = class_1802.field_8575.method_7854();
      class_2487 tag = new class_2487();
      class_2487 skullOwner = new class_2487();
      UUID parsedUuid = UUID.fromString(uuid);
      skullOwner.method_10566("Id", new class_2495(new int[]{(int)(parsedUuid.getMostSignificantBits() >> 32), (int)parsedUuid.getMostSignificantBits(), (int)(parsedUuid.getLeastSignificantBits() >> 32), (int)parsedUuid.getLeastSignificantBits()}));
      class_2487 properties = new class_2487();
      class_2499 textures = new class_2499();
      class_2487 Value = new class_2487();
      Value.method_10566("Value", class_2519.method_23256(value));
      textures.add(Value);
      properties.method_10566("textures", textures);
      skullOwner.method_10566("Properties", properties);
      tag.method_10566("SkullOwner", skullOwner);
      head.method_57379(class_9334.field_49628, class_9279.method_57456(tag));
      head.method_57379(class_9334.field_49631, class_2561.method_43470(name));
      return head;
   }

   public void initWidgets() {
   }

   static {
      category = HeadScreen.Categories.Decoration;
   }

   public static enum Categories {
      Alphabet,
      Animals,
      Blocks,
      Decoration,
      Food_Drinks,
      Humanoid,
      Miscellaneous,
      Monsters,
      Plants;

      // $FF: synthetic method
      private static Categories[] $values() {
         return new Categories[]{Alphabet, Animals, Blocks, Decoration, Food_Drinks, Humanoid, Miscellaneous, Monsters, Plants};
      }
   }
}
