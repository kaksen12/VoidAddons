package anticope.rejects.gui.screens;

import anticope.rejects.mixin.EntityAccessor;
import anticope.rejects.modules.InteractionMenu;
import java.awt.Point;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.meteor.KeyEvent;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.misc.Keybind;
import meteordevelopment.meteorclient.utils.misc.MeteorStarscript;
import meteordevelopment.meteorclient.utils.render.PeekScreen;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_10185;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1496;
import net.minecraft.class_1560;
import net.minecraft.class_1657;
import net.minecraft.class_1693;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2824;
import net.minecraft.class_2851;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_408;
import net.minecraft.class_437;
import net.minecraft.class_490;
import net.minecraft.class_9334;
import org.joml.Vector2f;
import org.meteordev.starscript.Script;
import org.meteordev.starscript.Section;
import org.meteordev.starscript.compiler.Compiler;
import org.meteordev.starscript.compiler.Parser;
import org.meteordev.starscript.utils.Error;
import org.meteordev.starscript.utils.StarscriptError;

public class InteractionScreen extends class_437 {
   public static class_1297 interactionMenuEntity;
   private final class_1297 entity;
   private String focusedString;
   private int crosshairX;
   private int crosshairY;
   private int focusedDot;
   private float yaw;
   private float pitch;
   private final Map<String, Consumer<class_1297>> functions;
   private final Map<String, String> msgs;
   private final class_2960 GUI_ICONS_TEXTURE;
   private final StaticListener shiftListener;
   private final int selectedDotColor;
   private final int dotColor;
   private final int backgroundColor;
   private final int borderColor;
   private final int textColor;

   public InteractionScreen(class_1297 e) {
      this(e, (InteractionMenu)Modules.get().get(InteractionMenu.class));
   }

   public InteractionScreen(class_1297 entity, InteractionMenu module) {
      super(class_2561.method_43470("Menu Screen"));
      this.focusedString = null;
      this.focusedDot = -1;
      this.GUI_ICONS_TEXTURE = class_2960.method_60654("textures/gui/icons.png");
      this.shiftListener = new StaticListener();
      if (module == null) {
         this.closeScreen();
      }

      this.selectedDotColor = ((SettingColor)module.selectedDotColor.get()).getPacked();
      this.dotColor = ((SettingColor)module.dotColor.get()).getPacked();
      this.backgroundColor = ((SettingColor)module.backgroundColor.get()).getPacked();
      this.borderColor = ((SettingColor)module.borderColor.get()).getPacked();
      this.textColor = ((SettingColor)module.textColor.get()).getPacked();
      this.entity = entity;
      this.functions = new HashMap();
      this.functions.put("Stats", (Consumer)(e) -> {
         this.closeScreen();
         this.field_22787.method_1507(new StatsScreen(e));
      });
      byte var4 = 0;
      //$FF: var4->value
      //0->net/minecraft/class_1657
      //1->net/minecraft/class_1496
      //2->net/minecraft/class_1693
      switch (entity.typeSwitch<invokedynamic>(entity, var4)) {
         case -1:
         default:
            this.functions.put("Open Inventory", (Consumer)(e) -> {
               this.closeScreen();
               class_1799 container = new class_1799(class_1802.field_8106);
               container.method_57379(class_9334.field_49631, e.method_5477());
               this.field_22787.method_1507(new PeekScreen(container, this.getInventory(e)));
            });
            break;
         case 0:
            class_1657 playerEntity = (class_1657)entity;
            this.functions.put("Open Inventory", (Consumer)(e) -> {
               this.closeScreen();
               this.field_22787.method_1507(new class_490((class_1657)e));
            });
            break;
         case 1:
            class_1496 abstractHorseEntity = (class_1496)entity;
            this.functions.put("Open Inventory", (Consumer)(e) -> {
               this.closeScreen();
               if (this.field_22787.field_1724.method_3144()) {
                  this.field_22787.field_1724.field_3944.method_52787(new class_2851(new class_10185(false, false, false, false, false, true, false)));
               }

               this.field_22787.field_1724.field_3944.method_52787(class_2824.method_34207(entity, true, class_1268.field_5808));
               this.field_22787.field_1724.method_5660(false);
            });
            break;
         case 2:
            class_1693 storageMinecartEntity = (class_1693)entity;
            this.functions.put("Open Inventory", (Consumer)(e) -> {
               this.closeScreen();
               this.field_22787.field_1724.field_3944.method_52787(class_2824.method_34207(entity, true, class_1268.field_5808));
            });
      }

      this.functions.put("Spectate", (Consumer)(e) -> {
         class_310.method_1551().method_1504(e);
         this.field_22787.field_1724.method_7353(class_2561.method_43470("Sneak to un-spectate."), true);
         MeteorClient.EVENT_BUS.subscribe(this.shiftListener);
         this.closeScreen();
      });
      if (entity.method_5851()) {
         this.functions.put("Remove glow", (Consumer)(e) -> {
            e.method_5834(false);
            ((EntityAccessor)e).invokeSetFlag(6, false);
            this.closeScreen();
         });
      } else {
         this.functions.put("Glow", (Consumer)(e) -> {
            e.method_5834(true);
            ((EntityAccessor)e).invokeSetFlag(6, true);
            this.closeScreen();
         });
      }

      if (entity.field_5960) {
         this.functions.put("Disable NoClip", (Consumer)(e) -> {
            entity.field_5960 = false;
            this.closeScreen();
         });
      } else {
         this.functions.put("NoClip", (Consumer)(e) -> {
            entity.field_5960 = true;
            this.closeScreen();
         });
      }

      this.msgs = (Map)((InteractionMenu)Modules.get().get(InteractionMenu.class)).messages.get();
      this.msgs.keySet().forEach((key) -> this.functions.put(key, (Consumer)(e) -> {
            this.closeScreen();
            interactionMenuEntity = e;
            Parser.Result result = Parser.parse((String)this.msgs.get(key));
            if (!result.hasErrors()) {
               Script script = Compiler.compile(result);

               try {
                  Section section = MeteorStarscript.ss.run(script);
                  this.field_22787.method_1507(new class_408(section.text, false));
               } catch (StarscriptError err) {
                  MeteorStarscript.printChatError(err);
               }

            } else {
               for(Error error : result.errors) {
                  MeteorStarscript.printChatError(error);
               }

            }
         }));
      this.functions.put("Cancel", (Consumer)(e) -> this.closeScreen());
   }

   private class_1799[] getInventory(class_1297 e) {
      class_1799[] stack = new class_1799[27];
      int[] index = new int[]{0};
      if (e instanceof class_1560) {
         try {
            stack[index[0]] = ((class_1560)e).method_7027().method_26204().method_8389().method_7854();
            int var10002 = index[0]++;
         } catch (NullPointerException var11) {
         }
      }

      class_1309 a = (class_1309)e;
      class_1799 bodyStack = a.method_6118(class_1304.field_48824);
      if (bodyStack != null && !bodyStack.method_7960()) {
         stack[index[0]] = bodyStack;
         int var18 = index[0]++;
      }

      for(class_1304 slot : new class_1304[]{class_1304.field_6173, class_1304.field_6171}) {
         class_1799 itemStack = a.method_6118(slot);
         if (itemStack != null && !itemStack.method_7960()) {
            stack[index[0]] = itemStack;
            int var19 = index[0]++;
         }
      }

      for(class_1304 slot : new class_1304[]{class_1304.field_6166, class_1304.field_6172, class_1304.field_6174, class_1304.field_6169}) {
         class_1799 itemStack = a.method_6118(slot);
         if (itemStack != null && !itemStack.method_7960()) {
            stack[index[0]] = itemStack;
            int var20 = index[0]++;
         }
      }

      for(int i = index[0]; i < 27; ++i) {
         stack[i] = class_1802.field_8162.method_7854();
      }

      return stack;
   }

   public void method_25426() {
      super.method_25426();
      this.cursorMode(212994);
      this.yaw = this.field_22787.field_1724.method_36454();
      this.pitch = this.field_22787.field_1724.method_36455();
   }

   private void cursorMode(int mode) {
      class_304.method_1437();
      double x = (double)this.field_22787.method_22683().method_4480() / (double)2.0F;
      double y = (double)this.field_22787.method_22683().method_4507() / (double)2.0F;
      class_3675.method_15984(this.field_22787.method_22683(), mode, x, y);
   }

   public void method_25393() {
      if (((Keybind)((InteractionMenu)Modules.get().get(InteractionMenu.class)).keybind.get()).isPressed()) {
         this.method_25419();
      }

   }

   private void closeScreen() {
      this.field_22787.method_1507((class_437)null);
   }

   public void method_25419() {
      this.cursorMode(212993);
      if (this.focusedString != null) {
         ((Consumer)this.functions.get(this.focusedString)).accept(this.entity);
      } else {
         this.field_22787.method_1507((class_437)null);
      }

   }

   public boolean method_25421() {
      return false;
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      this.drawDots(context, (int)((double)(Math.min(this.field_22790, this.field_22789) / 2) * (double)0.75F), mouseX, mouseY);
      context.method_27534(this.field_22793, this.entity.method_5477(), this.field_22789 / 2, 12, -1);
      Vector2f mouse = this.getMouseVecs(mouseX, mouseY);
      this.crosshairX = (int)mouse.x + this.field_22789 / 2;
      this.crosshairY = (int)mouse.y + this.field_22790 / 2;
      this.field_22787.field_1724.method_36456(this.yaw + mouse.x / 3.0F);
      this.field_22787.field_1724.method_36457(class_3532.method_15363(this.pitch + mouse.y / 3.0F, -90.0F, 90.0F));
      super.method_25394(context, mouseX, mouseY, delta);
   }

   private Vector2f getMouseVecs(int mouseX, int mouseY) {
      int scale = (Integer)this.field_22787.field_1690.method_42474().method_41753();
      Vector2f mouse = new Vector2f((float)mouseX, (float)mouseY);
      Vector2f center = new Vector2f((float)(this.field_22789 / 2), (float)(this.field_22790 / 2));
      mouse.sub(center).normalize();
      if (scale == 0) {
         scale = 4;
      }

      if (Math.hypot((double)(this.field_22789 / 2 - mouseX), (double)(this.field_22790 / 2 - mouseY)) < (double)(1.0F / (float)scale * 200.0F)) {
         mouse.mul((float)Math.hypot((double)(this.field_22789 / 2 - mouseX), (double)(this.field_22790 / 2 - mouseY)));
      } else {
         mouse.mul(1.0F / (float)scale * 200.0F);
      }

      return mouse;
   }

   private void drawDots(class_332 context, int radius, int mouseX, int mouseY) {
      ArrayList<Point> pointList = new ArrayList();
      String[] cache = new String[this.functions.size()];
      double lowestDistance = Double.MAX_VALUE;
      int i = 0;

      for(String string : this.functions.keySet()) {
         double s = (double)i / (double)this.functions.size() * (double)2.0F * Math.PI;
         int x = (int)Math.round((double)radius * Math.cos(s) + (double)(this.field_22789 / 2));
         int y = (int)Math.round((double)radius * Math.sin(s) + (double)(this.field_22790 / 2));
         this.drawTextField(context, x, y, string);
         if (Math.hypot((double)(x - mouseX), (double)(y - mouseY)) < lowestDistance) {
            lowestDistance = Math.hypot((double)(x - mouseX), (double)(y - mouseY));
            this.focusedDot = i;
         }

         cache[i] = string;
         pointList.add(new Point(x, y));
         ++i;
      }

      for(int j = 0; j < this.functions.size(); ++j) {
         Point point = (Point)pointList.get(j);
         if (pointList.get(this.focusedDot) == point) {
            this.drawDot(context, point.x - 4, point.y - 4, this.selectedDotColor);
            this.focusedString = cache[this.focusedDot];
         } else {
            this.drawDot(context, point.x - 4, point.y - 4, this.dotColor);
         }
      }

   }

   private void drawRect(class_332 context, int startX, int startY, int width, int height, int colorInner, int colorOuter) {
      context.method_51738(startX, startX + width, startY, colorOuter);
      context.method_51738(startX, startX + width, startY + height, colorOuter);
      context.method_51742(startX, startY, startY + height, colorOuter);
      context.method_51742(startX + width, startY, startY + height, colorOuter);
      context.method_25294(startX + 1, startY + 1, startX + width, startY + height, colorInner);
   }

   private void drawTextField(class_332 context, int x, int y, String key) {
      if (x >= this.field_22789 / 2) {
         this.drawRect(context, x + 10, y - 8, this.field_22793.method_1727(key) + 3, 15, this.backgroundColor, this.borderColor);
         context.method_25303(this.field_22793, key, x + 12, y - 4, this.textColor);
      } else {
         this.drawRect(context, x - 14 - this.field_22793.method_1727(key), y - 8, this.field_22793.method_1727(key) + 3, 15, this.backgroundColor, this.borderColor);
         context.method_25303(this.field_22793, key, x - 12 - this.field_22793.method_1727(key), y - 4, this.textColor);
      }

   }

   private void drawDot(class_332 context, int startX, int startY, int colorInner) {
      context.method_51738(startX + 2, startX + 5, startY, this.borderColor);
      context.method_51738(startX + 1, startX + 6, startY + 1, this.borderColor);
      context.method_51738(startX + 2, startX + 5, startY + 1, colorInner);
      context.method_25294(startX, startY + 2, startX + 8, startY + 6, this.borderColor);
      context.method_25294(startX + 1, startY + 2, startX + 7, startY + 6, colorInner);
      context.method_51738(startX + 1, startX + 6, startY + 6, this.borderColor);
      context.method_51738(startX + 2, startX + 5, startY + 6, colorInner);
      context.method_51738(startX + 2, startX + 5, startY + 7, this.borderColor);
      context.method_51738(startX + 2, startX + 3, startY + 1, -2130706433);
      context.method_51738(startX + 1, startX + 1, startY + 2, -2130706433);
   }

   private class StaticListener {
      @EventHandler
      private void onKey(KeyEvent event) {
         if (event.key() == InteractionScreen.this.field_22787.field_1690.field_1832.method_1429().method_1444()) {
            InteractionScreen.this.field_22787.method_1504(InteractionScreen.this.field_22787.field_1724);
            event.cancel();
            MeteorClient.EVENT_BUS.unsubscribe(this);
         }

      }
   }
}
