package anticope.rejects.gui.hud;

import anticope.rejects.MeteorRejectsAddon;
import java.util.Set;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.renderer.Renderer2D;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.EntityTypeListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.hud.HudElement;
import meteordevelopment.meteorclient.systems.hud.HudElementInfo;
import meteordevelopment.meteorclient.systems.hud.HudRenderer;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.render.ESP;
import meteordevelopment.meteorclient.systems.waypoints.Waypoint;
import meteordevelopment.meteorclient.systems.waypoints.Waypoints;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_2338;
import net.minecraft.class_243;

public class RadarHud extends HudElement {
   public static final HudElementInfo<RadarHud> INFO;
   private final SettingGroup sgGeneral;
   private final Setting<SettingColor> backgroundColor;
   private final Setting<Set<class_1299<?>>> entities;
   private final Setting<Boolean> letters;
   private final Setting<Boolean> showWaypoints;
   private final Setting<Double> scale;
   private final Setting<Double> zoom;

   public RadarHud() {
      super(INFO);
      this.sgGeneral = this.settings.getDefaultGroup();
      this.backgroundColor = this.sgGeneral.add(((ColorSetting.Builder)((ColorSetting.Builder)(new ColorSetting.Builder()).name("background-color")).description("Color of background.")).defaultValue(new SettingColor(0, 0, 0, 64)).build());
      this.entities = this.sgGeneral.add(((EntityTypeListSetting.Builder)((EntityTypeListSetting.Builder)(new EntityTypeListSetting.Builder()).name("entities")).description("Select specific entities.")).defaultValue(new class_1299[]{class_1299.field_6097}).build());
      this.letters = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("letters")).description("Use entity's type first letter.")).defaultValue(true)).build());
      this.showWaypoints = this.sgGeneral.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("waypoints")).description("Show waypoints.")).defaultValue(false)).build());
      this.scale = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("scale")).description("The scale.")).defaultValue((double)1.0F).min((double)1.0F).sliderRange(0.01, (double)5.0F).onChanged((aDouble) -> this.calculateSize())).build());
      this.zoom = this.sgGeneral.add(((DoubleSetting.Builder)((DoubleSetting.Builder)(new DoubleSetting.Builder()).name("zoom")).description("Radar zoom.")).defaultValue((double)1.0F).min(0.01).sliderRange(0.01, (double)3.0F).build());
      this.calculateSize();
   }

   public void calculateSize() {
      this.setSize((double)200.0F * (Double)this.scale.get(), (double)200.0F * (Double)this.scale.get());
   }

   public void render(HudRenderer renderer) {
      ESP esp = (ESP)Modules.get().get(ESP.class);
      if (esp != null) {
         renderer.post(() -> {
            if (MeteorClient.mc.field_1724 != null) {
               double width = (double)this.getWidth();
               double height = (double)this.getHeight();
               Renderer2D.COLOR.begin();
               Renderer2D.COLOR.quad((double)this.x, (double)this.y, width, height, (Color)this.backgroundColor.get());
               Renderer2D.COLOR.render();
               if (MeteorClient.mc.field_1687 != null) {
                  for(class_1297 entity : MeteorClient.mc.field_1687.method_18112()) {
                     if (!((Set)this.entities.get()).contains(entity.method_5864())) {
                        return;
                     }

                     double xPos = (entity.method_23317() - MeteorClient.mc.field_1724.method_23317()) * (Double)this.scale.get() * (Double)this.zoom.get() + width / (double)2.0F;
                     double yPos = (entity.method_23321() - MeteorClient.mc.field_1724.method_23321()) * (Double)this.scale.get() * (Double)this.zoom.get() + height / (double)2.0F;
                     if (!(xPos < (double)0.0F) && !(yPos < (double)0.0F) && !(xPos > width - (Double)this.scale.get()) && !(yPos > height - (Double)this.scale.get())) {
                        String icon = "*";
                        if ((Boolean)this.letters.get()) {
                           icon = entity.method_5864().method_35050().substring(0, 1).toUpperCase();
                        }

                        Color c = esp.getColor(entity);
                        if (c == null) {
                           c = Color.WHITE;
                        }

                        renderer.text(icon, xPos + (double)this.x, yPos + (double)this.y, c, false);
                     }
                  }
               }

               if ((Boolean)this.showWaypoints.get()) {
                  for(Waypoint waypoint : Waypoints.get()) {
                     class_2338 blockPos = waypoint.getPos();
                     class_243 coords = new class_243((double)blockPos.method_10263() + (double)0.5F, (double)blockPos.method_10264(), (double)blockPos.method_10260() + (double)0.5F);
                     double xPos = (coords.method_10216() - MeteorClient.mc.field_1724.method_23317()) * (Double)this.scale.get() * (Double)this.zoom.get() + width / (double)2.0F;
                     double yPos = (coords.method_10215() - MeteorClient.mc.field_1724.method_23321()) * (Double)this.scale.get() * (Double)this.zoom.get() + height / (double)2.0F;
                     if (!(xPos < (double)0.0F) && !(yPos < (double)0.0F) && !(xPos > width - (Double)this.scale.get()) && !(yPos > height - (Double)this.scale.get())) {
                        String icon = "*";
                        if ((Boolean)this.letters.get() && !((String)waypoint.name.get()).isEmpty()) {
                           icon = ((String)waypoint.name.get()).substring(0, 1);
                        }

                        renderer.text(icon, xPos + (double)this.x, yPos + (double)this.y, (Color)waypoint.color.get(), false);
                     }
                  }
               }

               Renderer2D.COLOR.render();
            }
         });
      }
   }

   static {
      INFO = new HudElementInfo(MeteorRejectsAddon.HUD_GROUP, "radar", "Draws a Radar on your HUD telling you where entities are.", RadarHud::new);
   }
}
