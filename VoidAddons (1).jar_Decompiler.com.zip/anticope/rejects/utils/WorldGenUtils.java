package anticope.rejects.utils;

import anticope.rejects.utils.seeds.Seed;
import anticope.rejects.utils.seeds.Seeds;
import baritone.api.BaritoneAPI;
import com.seedfinding.mcbiome.source.BiomeSource;
import com.seedfinding.mccore.rand.ChunkRand;
import com.seedfinding.mccore.state.Dimension;
import com.seedfinding.mccore.util.data.SpiralIterator;
import com.seedfinding.mccore.util.pos.BPos;
import com.seedfinding.mccore.util.pos.CPos;
import com.seedfinding.mccore.util.pos.RPos;
import com.seedfinding.mccore.version.MCVersion;
import com.seedfinding.mcfeature.misc.SlimeChunk;
import com.seedfinding.mcfeature.structure.BastionRemnant;
import com.seedfinding.mcfeature.structure.BuriedTreasure;
import com.seedfinding.mcfeature.structure.DesertPyramid;
import com.seedfinding.mcfeature.structure.EndCity;
import com.seedfinding.mcfeature.structure.Fortress;
import com.seedfinding.mcfeature.structure.Mansion;
import com.seedfinding.mcfeature.structure.Mineshaft;
import com.seedfinding.mcfeature.structure.Monument;
import com.seedfinding.mcfeature.structure.RegionStructure;
import com.seedfinding.mcfeature.structure.Stronghold;
import com.seedfinding.mcfeature.structure.Structure;
import com.seedfinding.mcfeature.structure.Village;
import com.seedfinding.mcterrain.TerrainGenerator;
import cubitect.Cubiomes;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.stream.StreamSupport;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1439;
import net.minecraft.class_1545;
import net.minecraft.class_1550;
import net.minecraft.class_1564;
import net.minecraft.class_1577;
import net.minecraft.class_1606;
import net.minecraft.class_1621;
import net.minecraft.class_1639;
import net.minecraft.class_1646;
import net.minecraft.class_1694;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_5419;
import net.minecraft.class_9292;
import net.minecraft.class_9334;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class WorldGenUtils {
   private static final Logger LOG = LogManager.getLogger();
   private static final HashMap<Feature, List<class_2248>> FEATURE_BLOCKS = new HashMap<Feature, List<class_2248>>() {
      {
         this.put(WorldGenUtils.Feature.nether_fortress, Arrays.asList(class_2246.field_10266, class_2246.field_10364, class_2246.field_9974));
         this.put(WorldGenUtils.Feature.ocean_monument, Arrays.asList(class_2246.field_10006, class_2246.field_10174, class_2246.field_10297));
         this.put(WorldGenUtils.Feature.stronghold, Arrays.asList(class_2246.field_10398, class_2246.field_10027));
         this.put(WorldGenUtils.Feature.end_city, Arrays.asList(class_2246.field_10286, class_2246.field_10505, class_2246.field_9992, class_2246.field_10455));
         this.put(WorldGenUtils.Feature.village, Arrays.asList(class_2246.field_16332, class_2246.field_10333, class_2246.field_16334, class_2246.field_16333, class_2246.field_16331, class_2246.field_16335, class_2246.field_10083, class_2246.field_16337, class_2246.field_16330));
         this.put(WorldGenUtils.Feature.mineshaft, Collections.singletonList(class_2246.field_10167));
         this.put(WorldGenUtils.Feature.desert_pyramid, Arrays.asList(class_2246.field_10375, class_2246.field_10292, class_2246.field_10158));
      }
   };
   private static final HashMap<Feature, List<Class<? extends class_1297>>> FEATURE_ENTITIES = new HashMap<Feature, List<Class<? extends class_1297>>>() {
      {
         this.put(WorldGenUtils.Feature.ocean_monument, Arrays.asList(class_1550.class, class_1577.class));
         this.put(WorldGenUtils.Feature.nether_fortress, Arrays.asList(class_1545.class, class_1639.class));
         this.put(WorldGenUtils.Feature.mansion, Collections.singletonList(class_1564.class));
         this.put(WorldGenUtils.Feature.slime_chunk, Collections.singletonList(class_1621.class));
         this.put(WorldGenUtils.Feature.bastion_remnant, Collections.singletonList(class_5419.class));
         this.put(WorldGenUtils.Feature.end_city, Collections.singletonList(class_1606.class));
         this.put(WorldGenUtils.Feature.village, Arrays.asList(class_1646.class, class_1439.class));
         this.put(WorldGenUtils.Feature.mineshaft, Collections.singletonList(class_1694.class));
      }
   };

   public static class_2338 locateFeature(Cubiomes.StructureType cfeature, class_2338 center) {
      Feature var10000;
      switch (cfeature) {
         case Treasure -> var10000 = WorldGenUtils.Feature.buried_treasure;
         case Mansion -> var10000 = WorldGenUtils.Feature.mansion;
         case Stronghold -> var10000 = WorldGenUtils.Feature.stronghold;
         case Fortress -> var10000 = WorldGenUtils.Feature.nether_fortress;
         case Monument -> var10000 = WorldGenUtils.Feature.ocean_monument;
         case Bastion -> var10000 = WorldGenUtils.Feature.bastion_remnant;
         case End_City -> var10000 = WorldGenUtils.Feature.end_city;
         case Village -> var10000 = WorldGenUtils.Feature.village;
         case Mineshaft -> var10000 = WorldGenUtils.Feature.mineshaft;
         case Desert_Pyramid -> var10000 = WorldGenUtils.Feature.desert_pyramid;
         default -> var10000 = null;
      }

      Feature feature = var10000;
      Seed seed = Seeds.get().getSeed();
      class_2338 pos = null;
      if (!checkIfInDimension(getDimension(feature))) {
         return null;
      } else {
         if (seed != null) {
            try {
               pos = locateFeature(seed, feature, center);
            } catch (Error | Exception ex) {
               LOG.error(ex);
            }

            if (pos != null) {
               return pos;
            }
         }

         if (MeteorClient.mc.field_1724 != null) {
            class_1799 stack = MeteorClient.mc.field_1724.method_5998(class_1268.field_5808);
            if (stack.method_7909() != class_1802.field_8204) {
               stack = MeteorClient.mc.field_1724.method_5998(class_1268.field_5810);
            }

            if (stack.method_7909() == class_1802.field_8204) {
               try {
                  pos = locateFeatureMap(feature, stack);
               } catch (Error | Exception ex) {
                  LOG.error(ex);
               }

               if (pos != null) {
                  return pos;
               }
            }
         }

         try {
            pos = locateFeatureEntities(feature);
         } catch (Error | Exception ex) {
            LOG.error(ex);
         }

         if (pos != null) {
            return pos;
         } else {
            try {
               pos = locateFeatureBlocks(feature);
            } catch (Error | Exception ex) {
               LOG.error(ex);
            }

            return pos;
         }
      }
   }

   private static class_2338 locateFeatureMap(Feature feature, class_1799 stack) {
      return !isValidMap(feature, stack) ? null : getMapMarker(stack);
   }

   private static class_2338 locateFeatureBlocks(Feature feature) {
      List<class_2248> blocks = (List)FEATURE_BLOCKS.get(feature);
      if (blocks == null) {
         return null;
      } else {
         List<class_2338> posList = BaritoneAPI.getProvider().getWorldScanner().scanChunkRadius(BaritoneAPI.getProvider().getPrimaryBaritone().getPlayerContext(), blocks, 64, 10, 32);
         if (posList.isEmpty()) {
            return null;
         } else {
            if (posList.size() < 5) {
               ChatUtils.warningPrefix("Locate", "Only %d block(s) found. This search might be a false positive.", new Object[]{posList.size()});
            }

            return (class_2338)posList.get(0);
         }
      }
   }

   private static class_2338 locateFeatureEntities(Feature feature) {
      List<Class<? extends class_1297>> entities = (List)FEATURE_ENTITIES.get(feature);
      if (entities == null) {
         return null;
      } else if (MeteorClient.mc.field_1687 == null) {
         return null;
      } else {
         for(class_1297 e : MeteorClient.mc.field_1687.method_18112()) {
            for(Class<? extends class_1297> clazz : entities) {
               if (clazz.isInstance(e)) {
                  return e.method_24515();
               }
            }
         }

         return null;
      }
   }

   private static class_2338 locateFeature(Seed seed, Feature feature, class_2338 center) {
      return feature == WorldGenUtils.Feature.slime_chunk ? locateSlimeChunk(seed, center) : locateStructure(seed, feature, center);
   }

   private static class_2338 locateSlimeChunk(Seed seed, class_2338 center) {
      Dimension dimension = getDimension(WorldGenUtils.Feature.slime_chunk);
      MCVersion mcVersion = seed.version;
      CPos centerChunk = new CPos(center.method_10263() >> 4, center.method_10260() >> 4);
      CPos slimeChunkPos = locateSlimeChunk(new SlimeChunk(mcVersion), centerChunk, 6400, seed.seed, new ChunkRand(), dimension);
      return slimeChunkPos == null ? null : toBlockPos(slimeChunkPos.toBlockPos());
   }

   private static CPos locateSlimeChunk(SlimeChunk slimeChunk, CPos centerChunk, int radius, long seed, ChunkRand rand, Dimension dimension) {
      if (!slimeChunk.isValidDimension(dimension)) {
         return null;
      } else {
         for(CPos next : new SpiralIterator(centerChunk, new CPos(radius, radius), (x, y, z) -> new CPos(x, z))) {
            SlimeChunk.Data data = slimeChunk.at(next.getX(), next.getZ(), true);
            if (data.testStart(seed, rand)) {
               return next;
            }
         }

         return null;
      }
   }

   private static class_2338 locateStructure(Seed seed, Feature feature, class_2338 center) {
      Dimension dimension = getDimension(feature);
      if (dimension == Dimension.OVERWORLD && seed.version.isNewerThan(MCVersion.v1_18)) {
         return null;
      } else {
         MCVersion mcVersion = seed.version;
         Structure<?, ?> structure = getStructure(feature, mcVersion);
         if (structure == null) {
            return null;
         } else {
            BiomeSource biomeSource = BiomeSource.of(dimension, mcVersion, seed.seed);
            if (!structure.isValidDimension(biomeSource.getDimension())) {
               return null;
            } else {
               BPos structurePos = locateStructure(structure, new BPos(center.method_10263(), center.method_10264(), center.method_10260()), 6400, new ChunkRand(), biomeSource, TerrainGenerator.of(biomeSource));
               return structurePos == null ? null : toBlockPos(structurePos);
            }
         }
      }
   }

   private static BPos locateStructure(Structure<?, ?> structure, BPos center, int radius, ChunkRand chunkRand, BiomeSource source, TerrainGenerator terrainGenerator) {
      if (structure instanceof RegionStructure<?, ?> regionStructure) {
         int chunkInRegion = regionStructure.getSpacing();
         int regionSize = chunkInRegion * 16;
         int border = 30000000;
         SpiralIterator<RPos> spiralIterator = new SpiralIterator<RPos>(center.toRegionPos(regionSize), (new BPos(-30000000, 0, -30000000)).toRegionPos(regionSize), (new BPos(30000000, 0, 30000000)).toRegionPos(regionSize), 1, (x, y, z) -> new RPos(x, z, regionSize));
         return (BPos)StreamSupport.stream(spiralIterator.spliterator(), false).map((rPos) -> regionStructure.getInRegion(source.getWorldSeed(), rPos.getX(), rPos.getZ(), chunkRand)).filter(Objects::nonNull).filter((cPos) -> regionStructure.canSpawn(cPos, source) && (terrainGenerator == null || regionStructure.canGenerate(cPos, terrainGenerator))).findAny().map((cPos) -> cPos.toBlockPos().add(9, 0, 9)).orElse((Object)null);
      } else if (structure instanceof Stronghold strongholdStructure) {
         CPos currentChunkPos = center.toChunkPos();
         int squaredDistance = Integer.MAX_VALUE;
         CPos closest = new CPos(0, 0);

         for(CPos stronghold : strongholdStructure.getAllStarts(source, chunkRand)) {
            int newSquaredDistance = (currentChunkPos.getX() - stronghold.getX()) * (currentChunkPos.getX() - stronghold.getX()) + (currentChunkPos.getZ() - stronghold.getZ()) * (currentChunkPos.getZ() - stronghold.getZ());
            if (newSquaredDistance < squaredDistance) {
               squaredDistance = newSquaredDistance;
               closest = stronghold;
            }
         }

         BPos dimPos = closest.toBlockPos().add(9, 0, 9);
         return new BPos(dimPos.getX(), 0, dimPos.getZ());
      } else if (structure instanceof Mineshaft mineshaft) {
         SpiralIterator<CPos> spiralIterator = new SpiralIterator<CPos>(new CPos(center.getX() >> 4, center.getZ() >> 4), new CPos(radius, radius), (x, y, z) -> new CPos(x, z));
         return (BPos)StreamSupport.stream(spiralIterator.spliterator(), false).filter((cPos) -> {
            com.seedfinding.mcfeature.Feature.Data<Mineshaft> data = mineshaft.at(cPos.getX(), cPos.getZ());
            return data.testStart(source.getWorldSeed(), chunkRand) && data.testBiome(source) && data.testGenerate(terrainGenerator);
         }).findAny().map((cPos) -> cPos.toBlockPos().add(9, 0, 9)).orElse((Object)null);
      } else {
         return null;
      }
   }

   private static Dimension getDimension(Feature feature) {
      Dimension var10000;
      switch (feature.ordinal()) {
         case 0 -> var10000 = Dimension.OVERWORLD;
         case 1 -> var10000 = Dimension.OVERWORLD;
         case 2 -> var10000 = Dimension.OVERWORLD;
         case 3 -> var10000 = Dimension.NETHER;
         case 4 -> var10000 = Dimension.OVERWORLD;
         case 5 -> var10000 = Dimension.NETHER;
         case 6 -> var10000 = Dimension.END;
         case 7 -> var10000 = Dimension.OVERWORLD;
         case 8 -> var10000 = Dimension.OVERWORLD;
         case 9 -> var10000 = Dimension.OVERWORLD;
         case 10 -> var10000 = Dimension.OVERWORLD;
         default -> var10000 = Dimension.OVERWORLD;
      }

      return var10000;
   }

   private static boolean checkIfInDimension(Dimension dimension) {
      boolean var10000;
      switch (dimension) {
         case OVERWORLD -> var10000 = PlayerUtils.getDimension() == meteordevelopment.meteorclient.utils.world.Dimension.Overworld;
         case NETHER -> var10000 = PlayerUtils.getDimension() == meteordevelopment.meteorclient.utils.world.Dimension.Nether;
         case END -> var10000 = PlayerUtils.getDimension() == meteordevelopment.meteorclient.utils.world.Dimension.End;
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return var10000;
   }

   private static Structure<?, ?> getStructure(Feature feature, MCVersion version) {
      Object var10000;
      switch (feature.ordinal()) {
         case 0:
            var10000 = new BuriedTreasure(version);
            break;
         case 1:
            var10000 = new Mansion(version);
            break;
         case 2:
            var10000 = new Stronghold(version);
            break;
         case 3:
            var10000 = new Fortress(version);
            break;
         case 4:
            var10000 = new Monument(version);
            break;
         case 5:
            var10000 = new BastionRemnant(version);
            break;
         case 6:
            var10000 = new EndCity(version);
            break;
         case 7:
            var10000 = new Village(version);
            break;
         case 8:
            var10000 = new Mineshaft(version);
            break;
         case 9:
         default:
            var10000 = null;
            break;
         case 10:
            var10000 = new DesertPyramid(version);
      }

      return (Structure<?, ?>)var10000;
   }

   private static class_2338 toBlockPos(BPos pos) {
      return new class_2338(pos.getX(), pos.getY(), pos.getZ());
   }

   private static boolean isValidMap(Feature feature, class_1799 stack) {
      if (stack.method_57353().method_57837()) {
         return false;
      } else if (!stack.method_57353().method_57832(class_9334.field_49647)) {
         return false;
      } else {
         class_9292 displayTag = (class_9292)stack.method_58658().method_58694(class_9334.field_49647);
         if (!displayTag.toString().contains("Name")) {
            return false;
         } else {
            String nameTag = String.valueOf(displayTag.comp_2404().get("Name"));
            if (!nameTag.contains("translate")) {
               return false;
            } else if (feature == WorldGenUtils.Feature.buried_treasure) {
               return nameTag.contains("filled_map.buried_treasure");
            } else if (feature == WorldGenUtils.Feature.ocean_monument) {
               return nameTag.contains("filled_map.monument");
            } else {
               return feature == WorldGenUtils.Feature.mansion ? nameTag.contains("filled_map.mansion") : false;
            }
         }
      }
   }

   private static class_2338 getMapMarker(class_1799 stack) {
      if (stack.method_57353().method_57837()) {
         return null;
      } else if (!stack.method_58658().method_57832(class_9334.field_49647)) {
         return null;
      } else {
         class_9292 decorationsTag = (class_9292)stack.method_58694(class_9334.field_49647);
         if (decorationsTag.comp_2404().isEmpty()) {
            return null;
         } else {
            class_9292.class_9293 iconTag = (class_9292.class_9293)decorationsTag.comp_2404().get(0);
            return new class_2338((int)iconTag.comp_2406(), 0, (int)iconTag.comp_2407());
         }
      }
   }

   public static enum Feature {
      buried_treasure,
      mansion,
      stronghold,
      nether_fortress,
      ocean_monument,
      bastion_remnant,
      end_city,
      village,
      mineshaft,
      slime_chunk,
      desert_pyramid;

      // $FF: synthetic method
      private static Feature[] $values() {
         return new Feature[]{buried_treasure, mansion, stronghold, nether_fortress, ocean_monument, bastion_remnant, end_city, village, mineshaft, slime_chunk, desert_pyramid};
      }
   }
}
