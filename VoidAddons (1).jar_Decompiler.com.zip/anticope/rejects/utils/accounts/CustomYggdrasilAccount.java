package anticope.rejects.utils.accounts;

import anticope.rejects.MeteorRejectsAddon;
import com.mojang.authlib.exceptions.AuthenticationException;
import java.net.Proxy;
import meteordevelopment.meteorclient.systems.accounts.Account;
import meteordevelopment.meteorclient.systems.accounts.AccountType;
import meteordevelopment.meteorclient.utils.misc.NbtException;
import net.minecraft.class_2487;
import net.minecraft.class_320;

public class CustomYggdrasilAccount extends Account<CustomYggdrasilAccount> {
   private String password;
   private String server;

   public CustomYggdrasilAccount(String name, String password, String server) {
      super(AccountType.Cracked, name);
      this.password = password;
      this.server = server;
   }

   public boolean fetchInfo() {
      try {
         class_320 session = CustomYggdrasilLogin.login(this.name, this.password, this.server);
         this.cache.username = session.method_1676();
         this.cache.uuid = session.method_44717().toString();
         return true;
      } catch (AuthenticationException var2) {
         return false;
      }
   }

   public boolean login() {
      try {
         CustomYggdrasilLogin.LocalYggdrasilAuthenticationService service = new CustomYggdrasilLogin.LocalYggdrasilAuthenticationService(Proxy.NO_PROXY, this.server);
         new CustomYggdrasilLogin.LocalYggdrasilMinecraftSessionService(service, service.server);
         applyLoginEnvironment(service);
         class_320 session = CustomYggdrasilLogin.login(this.name, this.password, this.server);
         setSession(session);
         this.cache.username = session.method_1676();
         this.cache.loadHead();
         return true;
      } catch (AuthenticationException e) {
         if (!e.getMessage().contains("Invalid username or password") && !e.getMessage().contains("account migrated")) {
            MeteorRejectsAddon.LOG.error("Failed to contact the authentication server.");
         } else {
            MeteorRejectsAddon.LOG.error("Wrong password.");
         }

         return false;
      }
   }

   public class_2487 toTag() {
      class_2487 tag = super.toTag();
      tag.method_10582("password", this.password);
      tag.method_10582("server", this.server);
      return tag;
   }

   public CustomYggdrasilAccount fromTag(class_2487 tag) {
      super.fromTag(tag);
      if (!tag.method_10545("password")) {
         throw new NbtException();
      } else {
         this.password = (String)tag.method_10558("password").orElse("");
         this.server = (String)tag.method_10558("server").orElse("");
         return this;
      }
   }

   public boolean equals(Object o) {
      return !(o instanceof CustomYggdrasilAccount) ? false : ((CustomYggdrasilAccount)o).name.equals(this.name);
   }
}
