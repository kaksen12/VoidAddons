package anticope.rejects.utils;

import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.systems.System;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.render.prompts.OkPrompt;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;

public class RejectsConfig extends System<RejectsConfig> {
   private static final RejectsConfig INSTANCE = new RejectsConfig();
   public HttpAllowed httpAllowed;
   public String httpUserAgent;
   public Set<String> hiddenModules;
   public boolean loadSystemFonts;
   public boolean duplicateModuleNames;

   public RejectsConfig() {
      super("rejects-config");
      this.httpAllowed = RejectsConfig.HttpAllowed.Everything;
      this.httpUserAgent = "Meteor Client";
      this.hiddenModules = new HashSet();
      this.loadSystemFonts = true;
      this.duplicateModuleNames = false;
      this.init();
      this.load(MeteorClient.FOLDER);
   }

   public static RejectsConfig get() {
      return INSTANCE;
   }

   public void setHiddenModules(List<Module> newList) {
      if (newList.size() < this.hiddenModules.size()) {
         ((OkPrompt)((OkPrompt)((OkPrompt)OkPrompt.create().title("Hidden Modules")).message("In order to see the modules you have removed from the list you need to restart Minecraft.")).id("hidden-modules-unhide")).show();
      }

      this.hiddenModules.clear();

      for(Module module : newList) {
         if (module != null) {
            if (module.isActive()) {
               module.toggle();
            }

            this.hiddenModules.add(module.name);
         }
      }

   }

   public List<Module> getHiddenModules() {
      Modules modules = Modules.get();
      if (modules == null) {
         return List.of();
      } else {
         Stream var10000 = this.hiddenModules.stream();
         Objects.requireNonNull(modules);
         return (List)var10000.map(modules::get).collect(Collectors.toList());
      }
   }

   public class_2487 toTag() {
      class_2487 tag = new class_2487();
      tag.method_10582("httpAllowed", this.httpAllowed.toString());
      tag.method_10582("httpUserAgent", this.httpUserAgent);
      tag.method_10556("loadSystemFonts", this.loadSystemFonts);
      tag.method_10556("duplicateModuleNames", this.duplicateModuleNames);
      class_2499 modulesTag = new class_2499();

      for(String module : this.hiddenModules) {
         modulesTag.add(class_2519.method_23256(module));
      }

      tag.method_10566("hiddenModules", modulesTag);
      return tag;
   }

   public RejectsConfig fromTag(class_2487 tag) {
      tag.method_10558("httpAllowed").ifPresent((s) -> this.httpAllowed = RejectsConfig.HttpAllowed.valueOf(s));
      this.httpUserAgent = (String)tag.method_10558("httpUserAgent").orElse(this.httpUserAgent);
      this.loadSystemFonts = (Boolean)tag.method_10577("loadSystemFonts").orElse(this.loadSystemFonts);
      this.duplicateModuleNames = (Boolean)tag.method_10577("duplicateModuleNames").orElse(this.duplicateModuleNames);
      tag.method_10554("hiddenModules").ifPresent((valueTag) -> {
         for(class_2520 tagI : valueTag) {
            Optional var10000 = tagI.method_68658();
            Set var10001 = this.hiddenModules;
            Objects.requireNonNull(var10001);
            var10000.ifPresent(var10001::add);
         }

      });
      return this;
   }

   public static enum HttpAllowed {
      Everything,
      NotMeteorApi,
      NotMeteorPing,
      Nothing;

      // $FF: synthetic method
      private static HttpAllowed[] $values() {
         return new HttpAllowed[]{Everything, NotMeteorApi, NotMeteorPing, Nothing};
      }
   }
}
