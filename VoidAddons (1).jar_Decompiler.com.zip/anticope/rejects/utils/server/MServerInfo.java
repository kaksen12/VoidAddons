package anticope.rejects.utils.server;

import java.util.Collections;
import java.util.List;
import net.minecraft.class_155;
import net.minecraft.class_2561;
import org.jetbrains.annotations.Nullable;

public class MServerInfo {
   public String name;
   public String address;
   public String playerCountLabel;
   public int playerCount;
   public int playercountMax;
   public String label;
   public long ping;
   public int protocolVersion = class_155.method_16673().comp_4027();
   public String version = null;
   public List<class_2561> playerListSummary = Collections.emptyList();
   private byte @Nullable [] icon;

   public MServerInfo(String name, String address) {
      this.name = name;
      this.address = address;
   }

   public byte @Nullable [] getIcon() {
      return this.icon;
   }

   public void setIcon(byte @Nullable [] bytes) {
      this.icon = bytes;
   }
}
