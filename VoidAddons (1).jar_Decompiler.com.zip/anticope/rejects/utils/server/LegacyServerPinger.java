package anticope.rejects.utils.server;

import anticope.rejects.MeteorRejectsAddon;
import java.net.UnknownHostException;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.class_12239;
import net.minecraft.class_642;
import net.minecraft.class_644;
import net.minecraft.class_642.class_8678;

public class LegacyServerPinger {
   private static final AtomicInteger threadNumber = new AtomicInteger(0);
   private class_642 server;
   private boolean done = false;
   private boolean failed = false;

   public void ping(String ip) {
      this.ping(ip, 25565);
   }

   public void ping(String ip, int port) {
      this.server = new class_642("", ip + ":" + port, class_8678.field_45611);
      (new Thread(() -> this.pingInCurrentThread(ip, port), "Server Pinger #" + threadNumber.incrementAndGet())).start();
   }

   private void pingInCurrentThread(String ip, int port) {
      class_644 pinger = new class_644();
      MeteorRejectsAddon.LOG.info("Pinging {}:{}...", ip, port);

      try {
         pinger.method_3003(this.server, () -> {
         }, () -> {
         }, class_12239.method_75867(false));
         MeteorRejectsAddon.LOG.info("Ping successful: {}:{}", ip, port);
      } catch (UnknownHostException var5) {
         MeteorRejectsAddon.LOG.warn("Unknown host: {}:{}", ip, port);
         this.failed = true;
      } catch (Exception var6) {
         MeteorRejectsAddon.LOG.warn("Ping failed: {}:{}", ip, port);
         this.failed = true;
      }

      pinger.method_3004();
      this.done = true;
   }

   public boolean isStillPinging() {
      return !this.done;
   }

   public boolean isWorking() {
      return !this.failed;
   }

   public String getServerIP() {
      return this.server.field_3761;
   }
}
