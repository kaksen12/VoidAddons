package anticope.rejects.utils;

import anticope.rejects.MeteorRejectsAddon;
import anticope.rejects.utils.seeds.Seeds;
import java.util.Random;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.entity.player.PlayerMoveEvent;
import meteordevelopment.meteorclient.mixininterface.IVec3d;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.utils.PostInit;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.PlayerUtils;
import net.minecraft.class_1297;
import net.minecraft.class_3532;

public class RejectsUtils {
   @PostInit
   public static void init() {
      Runtime.getRuntime().addShutdownHook(new Thread(() -> {
         System.out.println("saving seeds...");
         RejectsConfig.get().save(MeteorClient.FOLDER);
         Seeds.get().save(MeteorClient.FOLDER);
      }));
   }

   public static String getModuleName(String name) {
      int dupe = 0;
      Modules modules = Modules.get();
      if (modules == null) {
         MeteorRejectsAddon.LOG.warn("Module instantiation before Modules initialized.");
         return name;
      } else {
         for(Module module : modules.getAll()) {
            if (module.name.equals(name)) {
               ++dupe;
               break;
            }
         }

         return dupe == 0 ? name : getModuleName(name + "*".repeat(dupe));
      }
   }

   public static String getRandomPassword(int num) {
      String str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_";
      Random random = new Random();
      StringBuilder sb = new StringBuilder();

      for(int i = 0; i < num; ++i) {
         int number = random.nextInt(63);
         sb.append(str.charAt(number));
      }

      return sb.toString();
   }

   public static boolean inFov(class_1297 entity, double fov) {
      if (fov >= (double)360.0F) {
         return true;
      } else {
         float[] angle = PlayerUtils.calculateAngle(entity.method_5829().method_1005());
         double xDist = (double)class_3532.method_15356(angle[0], MeteorClient.mc.field_1724.method_36454());
         double yDist = (double)class_3532.method_15356(angle[1], MeteorClient.mc.field_1724.method_36455());
         double angleDistance = Math.hypot(xDist, yDist);
         return angleDistance <= fov;
      }
   }

   public static float fullFlightMove(PlayerMoveEvent event, double speed, boolean verticalSpeedMatch) {
      if (PlayerUtils.isMoving()) {
         double dir = getDir();
         double xDir = Math.cos(Math.toRadians(dir + (double)90.0F));
         double zDir = Math.sin(Math.toRadians(dir + (double)90.0F));
         ((IVec3d)event.movement).meteor$setXZ(xDir * speed, zDir * speed);
      } else {
         ((IVec3d)event.movement).meteor$setXZ((double)0.0F, (double)0.0F);
      }

      float ySpeed = 0.0F;
      if (MeteorClient.mc.field_1690.field_1903.method_1434()) {
         ySpeed = (float)((double)ySpeed + speed);
      }

      if (MeteorClient.mc.field_1690.field_1832.method_1434()) {
         ySpeed = (float)((double)ySpeed - speed);
      }

      ((IVec3d)event.movement).meteor$setY(verticalSpeedMatch ? (double)ySpeed : (double)(ySpeed / 2.0F));
      return ySpeed;
   }

   private static double getDir() {
      double dir = (double)0.0F;
      if (Utils.canUpdate()) {
         dir = (double)(MeteorClient.mc.field_1724.method_36454() + (float)(MeteorClient.mc.field_1724.field_6250 < 0.0F ? 180 : 0));
         if (MeteorClient.mc.field_1724.field_6212 > 0.0F) {
            dir += (double)(-90.0F * (MeteorClient.mc.field_1724.field_6250 < 0.0F ? -0.5F : (MeteorClient.mc.field_1724.field_6250 > 0.0F ? 0.5F : 1.0F)));
         } else if (MeteorClient.mc.field_1724.field_6212 < 0.0F) {
            dir += (double)(90.0F * (MeteorClient.mc.field_1724.field_6250 < 0.0F ? -0.5F : (MeteorClient.mc.field_1724.field_6250 > 0.0F ? 0.5F : 1.0F)));
         }
      }

      return dir;
   }
}
