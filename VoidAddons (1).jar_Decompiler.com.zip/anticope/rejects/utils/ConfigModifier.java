package anticope.rejects.utils;

import java.util.List;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.EnumSetting;
import meteordevelopment.meteorclient.settings.ModuleListSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.settings.StringSetting;
import meteordevelopment.meteorclient.systems.config.Config;
import meteordevelopment.meteorclient.systems.modules.Module;

public class ConfigModifier {
   private static ConfigModifier INSTANCE;
   public final SettingGroup sgRejects;
   public final Setting<RejectsConfig.HttpAllowed> httpAllowed;
   public final Setting<String> httpUserAgent;
   public final Setting<List<Module>> hiddenModules;
   public final Setting<Boolean> loadSystemFonts;
   public final Setting<Boolean> duplicateModuleNames;

   public ConfigModifier() {
      this.sgRejects = Config.get().settings.createGroup("Rejects");
      this.httpAllowed = this.sgRejects.add(((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)((EnumSetting.Builder)(new EnumSetting.Builder()).name("http-allowed")).description("Changes what api endpoints can be reached.")).defaultValue(RejectsConfig.get().httpAllowed)).onChanged((v) -> RejectsConfig.get().httpAllowed = v)).build());
      this.httpUserAgent = this.sgRejects.add(((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)((StringSetting.Builder)(new StringSetting.Builder()).name("http-user-agent")).description("Changes the HTTP user agent. Empty for none.")).defaultValue(RejectsConfig.get().httpUserAgent)).onChanged((v) -> RejectsConfig.get().httpUserAgent = v)).build());
      this.hiddenModules = this.sgRejects.add(((ModuleListSetting.Builder)((ModuleListSetting.Builder)((ModuleListSetting.Builder)((ModuleListSetting.Builder)((ModuleListSetting.Builder)(new ModuleListSetting.Builder()).name("hidden-modules")).description("Which modules to hide.")).defaultValue(List.of())).defaultValue(RejectsConfig.get().getHiddenModules())).onChanged((v) -> RejectsConfig.get().setHiddenModules(v))).build());
      this.loadSystemFonts = this.sgRejects.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("load-system-fonts")).description("Disabling this for faster launch. You can put font into meteor-client/fonts folder. Restart to take effect.")).defaultValue(true)).defaultValue(RejectsConfig.get().loadSystemFonts)).onChanged((v) -> RejectsConfig.get().loadSystemFonts = v)).build());
      this.duplicateModuleNames = this.sgRejects.add(((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)((BoolSetting.Builder)(new BoolSetting.Builder()).name("duplicate-module-names")).description("Allow duplicate module names. Best for addon compatibility.")).defaultValue(false)).defaultValue(RejectsConfig.get().duplicateModuleNames)).onChanged((v) -> RejectsConfig.get().duplicateModuleNames = v)).build());
   }

   public static ConfigModifier get() {
      if (INSTANCE == null) {
         INSTANCE = new ConfigModifier();
      }

      return INSTANCE;
   }
}
