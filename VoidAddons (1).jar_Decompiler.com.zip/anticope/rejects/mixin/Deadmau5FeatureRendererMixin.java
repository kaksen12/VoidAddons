package anticope.rejects.mixin;

import anticope.rejects.modules.Rendering;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.class_10055;
import net.minecraft.class_11659;
import net.minecraft.class_4587;
import net.minecraft.class_978;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_978.class})
public class Deadmau5FeatureRendererMixin {
   @Inject(
      method = {"method_4181(Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;ILnet/minecraft/class_10055;FF)V"},
      at = {@At("HEAD")}
   )
   private void onRender(class_4587 poseStack, class_11659 collector, int light, class_10055 renderState, float f, float g, CallbackInfo ci) {
      if (Modules.get() != null) {
         Rendering renderingModule = (Rendering)Modules.get().get(Rendering.class);
         if (renderingModule != null && renderingModule.deadmau5EarsEnabled()) {
            renderState.field_62758 = true;
         }
      }

   }
}
