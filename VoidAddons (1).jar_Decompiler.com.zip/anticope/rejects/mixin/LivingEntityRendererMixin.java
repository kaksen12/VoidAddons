package anticope.rejects.mixin;

import anticope.rejects.modules.Rendering;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10042;
import net.minecraft.class_10055;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_583;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({class_922.class})
public class LivingEntityRendererMixin<T extends class_1309, S extends class_10042, M extends class_583<? super S>> {
   @Inject(
      method = {"method_4058"},
      at = {@At("HEAD")}
   )
   private void dinnerboneEntities(S state, class_4587 matrices, float animationProgress, float bodyYaw, CallbackInfo ci) {
      if (!(state instanceof class_10055)) {
         if (Modules.get() != null) {
            Rendering renderingModule = (Rendering)Modules.get().get(Rendering.class);
            if (renderingModule != null && renderingModule.dinnerboneEnabled()) {
               state.field_53455 = true;
            }

         }
      }
   }
}
