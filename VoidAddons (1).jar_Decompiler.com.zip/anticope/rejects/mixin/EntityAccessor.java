package anticope.rejects.mixin;

import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({class_1297.class})
public interface EntityAccessor {
   @Invoker("method_5729")
   void invokeSetFlag(int var1, boolean var2);
}
