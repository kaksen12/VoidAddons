package anticope.rejects.mixin;

import anticope.rejects.modules.DebugRender;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.class_4604;
import net.minecraft.class_863;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_863.class})
public class DebugRendererMixin {
   @Inject(
      method = {"method_23099"},
      at = {@At("HEAD")}
   )
   public void render(class_4604 frustum, double d, double e, double f, float g, CallbackInfo ci) {
      DebugRender debugRender = (DebugRender)Modules.get().get(DebugRender.class);
      if (debugRender != null && debugRender.isActive()) {
         debugRender.render(frustum, d, e, f, g);
      }

   }
}
