package anticope.rejects.mixin;

import net.minecraft.class_12027;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_12027.class})
public class ServerDebugSubscribersMixin {
   @Inject(
      method = {"method_74615"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void bypassPermissionCheck(class_3222 player, CallbackInfoReturnable<Boolean> cir) {
      cir.setReturnValue(true);
   }
}
