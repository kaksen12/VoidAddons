package anticope.rejects.mixin;

import anticope.rejects.events.OffGroundSpeedEvent;
import meteordevelopment.meteorclient.MeteorClient;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_1657.class})
public class PlayerEntityMixin {
   @Inject(
      method = {"method_49484"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void onGetOffGroundSpeed(CallbackInfoReturnable<Float> cir) {
      cir.setReturnValue(((OffGroundSpeedEvent)MeteorClient.EVENT_BUS.post(OffGroundSpeedEvent.get(cir.getReturnValueF()))).speed);
   }
}
