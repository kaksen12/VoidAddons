package anticope.rejects.mixin;

import anticope.rejects.modules.Rendering;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.class_826;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin({class_826.class})
public class TexturedRenderLayersMixin {
   @ModifyArg(
      method = {"method_74365"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/class_826;method_74366(Lnet/minecraft/class_2586;Z)Lnet/minecraft/class_11959$class_11960;"
),
      index = 1
   )
   private boolean modifyXmasTexturesArg(boolean original) {
      if (Modules.get() != null) {
         Rendering rendering = (Rendering)Modules.get().get(Rendering.class);
         if (rendering != null && rendering.chistmas()) {
            return true;
         }
      }

      return original;
   }
}
