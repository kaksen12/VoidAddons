package anticope.rejects.mixin.baritone;

import anticope.rejects.modules.OreSim;
import baritone.api.utils.BlockOptionalMetaLookup;
import baritone.pathing.movement.CalculationContext;
import baritone.process.MineProcess;
import java.util.List;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({MineProcess.class})
public class MineProcessMixin {
   @Shadow(
      remap = false
   )
   private List<class_2338> a;

   @Inject(
      method = {"a(Ljava/util/List;Lbaritone/pathing/movement/CalculationContext;)V"},
      at = {@At("HEAD")},
      cancellable = true,
      remap = false
   )
   private void onRescan(List<class_2338> already, CalculationContext context, CallbackInfo ci) {
      OreSim oreSim = (OreSim)Modules.get().get(OreSim.class);
      if (oreSim != null && oreSim.baritone()) {
         this.a = oreSim.oreGoals;
         ci.cancel();
      }
   }

   @Redirect(
      method = {"a(Lbaritone/pathing/movement/CalculationContext;Lbaritone/api/utils/BlockOptionalMetaLookup;Ljava/util/List;Lnet/minecraft/class_2338;)Z"},
      at = @At(
   value = "INVOKE",
   target = "Lbaritone/api/utils/BlockOptionalMetaLookup;has(Lnet/minecraft/class_2680;)Z"
)
   )
   private static boolean onPruneStream(BlockOptionalMetaLookup instance, class_2680 blockState) {
      OreSim oreSim = (OreSim)Modules.get().get(OreSim.class);
      if (oreSim != null && oreSim.baritone()) {
         return !blockState.method_26215();
      } else {
         return instance.has(blockState);
      }
   }
}
