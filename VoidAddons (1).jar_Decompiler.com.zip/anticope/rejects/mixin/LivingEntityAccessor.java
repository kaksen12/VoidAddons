package anticope.rejects.mixin;

import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_1309.class})
public interface LivingEntityAccessor {
   @Accessor("field_6228")
   void setJumpingCooldown(int var1);

   @Accessor("field_6228")
   int getJumpingCooldown();
}
