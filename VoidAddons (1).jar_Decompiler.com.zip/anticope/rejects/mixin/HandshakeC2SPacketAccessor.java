package anticope.rejects.mixin;

import net.minecraft.class_2889;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_2889.class})
public interface HandshakeC2SPacketAccessor {
   @Mutable
   @Accessor("comp_1564")
   void setHostName(String var1);
}
