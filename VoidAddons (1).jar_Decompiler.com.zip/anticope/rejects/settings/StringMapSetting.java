package anticope.rejects.settings;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.renderer.GuiRenderer;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.input.WTextBox;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;
import meteordevelopment.meteorclient.gui.widgets.pressable.WMinus;
import meteordevelopment.meteorclient.gui.widgets.pressable.WPlus;
import meteordevelopment.meteorclient.settings.IVisible;
import meteordevelopment.meteorclient.settings.Setting;
import net.minecraft.class_2487;
import net.minecraft.class_2519;

public class StringMapSetting extends Setting<Map<String, String>> {
   public final Class<? extends WTextBox.Renderer> renderer;

   public StringMapSetting(String name, String description, Map<String, String> defaultValue, Consumer<Map<String, String>> onChanged, Consumer<Setting<Map<String, String>>> onModuleActivated, IVisible visible, Class<? extends WTextBox.Renderer> renderer) {
      super(name, description, defaultValue, onChanged, onModuleActivated, visible);
      this.renderer = renderer;
   }

   protected Map<String, String> parseImpl(String str) {
      String[] values = str.split(",");
      Map<String, String> map = new LinkedHashMap(values.length / 2);

      try {
         String left = null;

         for(int i = 0; i < values.length; ++i) {
            if (i % 2 == 0) {
               left = values[i];
            } else {
               map.put(left, values[i]);
            }
         }
      } catch (Exception var6) {
      }

      return map;
   }

   protected boolean isValueValid(Map<String, String> value) {
      return true;
   }

   protected void resetImpl() {
      this.value = new LinkedHashMap((Map)this.defaultValue);
   }

   protected class_2487 save(class_2487 tag) {
      class_2487 valueTag = new class_2487();

      for(String key : ((Map)this.get()).keySet()) {
         valueTag.method_10566(key, class_2519.method_23256((String)((Map)this.get()).get(key)));
      }

      tag.method_10566("map", valueTag);
      return tag;
   }

   protected Map<String, String> load(class_2487 tag) {
      ((Map)this.get()).clear();
      tag.method_10562("map").ifPresent((valueTag) -> {
         for(String key : valueTag.method_10541()) {
            valueTag.method_10558(key).ifPresent((value) -> ((Map)this.get()).put(key, value));
         }

      });
      return (Map)this.get();
   }

   public static void fillTable(GuiTheme theme, WTable table, StringMapSetting setting) {
      table.clear();
      Map<String, String> map = (Map)setting.get();

      for(String key : map.keySet()) {
         AtomicReference<String> key2 = new AtomicReference(key);
         WTextBox textBoxK = (WTextBox)table.add(theme.textBox((String)key2.get())).minWidth((double)150.0F).expandX().widget();
         textBoxK.actionOnUnfocused = () -> {
            String text = textBoxK.get();
            if (map.containsKey(text)) {
               textBoxK.set((String)key2.get());
            } else {
               String value = (String)map.remove(key2.get());
               key2.set(text);
               map.put(text, value);
            }
         };
         WTextBox textBoxV = (WTextBox)table.add(theme.textBox((String)map.get(key2.get()), (text1, c) -> true, setting.renderer)).minWidth((double)150.0F).expandX().widget();
         textBoxV.actionOnUnfocused = () -> map.replace((String)key2.get(), textBoxV.get());
         WMinus delete = (WMinus)table.add(theme.minus()).widget();
         delete.action = () -> {
            map.remove(key2.get());
            fillTable(theme, table, setting);
         };
         table.row();
      }

      if (!map.isEmpty()) {
         table.add(theme.horizontalSeparator()).expandX();
         table.row();
      }

      WButton reset = (WButton)table.add(theme.button(GuiRenderer.RESET)).widget();
      reset.action = () -> {
         setting.reset();
         fillTable(theme, table, setting);
      };
      WPlus add = (WPlus)table.add(theme.plus()).widget();
      add.action = () -> {
         map.put("", "");
         fillTable(theme, table, setting);
      };
      table.row();
   }

   public static class Builder extends Setting.SettingBuilder<Builder, Map<String, String>, StringMapSetting> {
      private Class<? extends WTextBox.Renderer> renderer;

      public Builder() {
         super(new LinkedHashMap(0));
      }

      public Builder defaultValue(Map<String, String> map) {
         this.defaultValue = map;
         return this;
      }

      public Builder renderer(Class<? extends WTextBox.Renderer> renderer) {
         this.renderer = renderer;
         return this;
      }

      public StringMapSetting build() {
         return new StringMapSetting(this.name, this.description, (Map)this.defaultValue, this.onChanged, this.onModuleActivated, this.visible, this.renderer);
      }
   }
}
