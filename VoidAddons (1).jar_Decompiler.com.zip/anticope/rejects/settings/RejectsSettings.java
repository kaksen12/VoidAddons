package anticope.rejects.settings;

import java.util.Map;
import java.util.Objects;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.gui.GuiTheme;
import meteordevelopment.meteorclient.gui.renderer.GuiRenderer;
import meteordevelopment.meteorclient.gui.utils.SettingsWidgetFactory;
import meteordevelopment.meteorclient.gui.widgets.containers.WTable;
import meteordevelopment.meteorclient.gui.widgets.pressable.WButton;

public class RejectsSettings {
   private final Map<Class<?>, SettingsWidgetFactory.Factory> factories;
   private final GuiTheme theme;

   public RejectsSettings(Map<Class<?>, SettingsWidgetFactory.Factory> factories, GuiTheme theme) {
      this.factories = factories;
      this.theme = theme;
   }

   public void addSettings() {
      this.factories.put(StringMapSetting.class, (SettingsWidgetFactory.Factory)(table, setting) -> this.stringMapW(table, (StringMapSetting)setting));
      this.factories.put(GameModeListSetting.class, (SettingsWidgetFactory.Factory)(table, setting) -> this.gameModeListW(table, (GameModeListSetting)setting));
   }

   private void stringMapW(WTable table, StringMapSetting setting) {
      WTable wtable = (WTable)table.add(this.theme.table()).expandX().widget();
      StringMapSetting.fillTable(this.theme, wtable, setting);
   }

   private void gameModeListW(WTable table, GameModeListSetting setting) {
      WButton button = (WButton)table.add(this.theme.button("Select")).expandCellX().widget();
      button.action = () -> MeteorClient.mc.method_1507(new GameModeListSettingScreen(this.theme, setting));
      WButton reset = (WButton)table.add(this.theme.button(GuiRenderer.RESET)).widget();
      Objects.requireNonNull(setting);
      reset.action = setting::reset;
   }
}
