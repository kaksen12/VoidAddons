package anticope.rejects.commands;

import anticope.rejects.arguments.ClientPosArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.commands.Command;
import net.minecraft.class_2172;
import net.minecraft.class_2247;
import net.minecraft.class_2257;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;

public class FillCommand extends Command {
   public FillCommand() {
      super("fill", "Fills a specified area with a block", new String[0]);
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(argument("from-pos", ClientPosArgumentType.pos()).then(argument("to-pos", ClientPosArgumentType.pos()).then(argument("block", class_2257.method_9653(REGISTRY_ACCESS)).executes((ctx) -> {
         class_243 fromPos = ClientPosArgumentType.getPos(ctx, "from-pos");
         class_243 toPos = ClientPosArgumentType.getPos(ctx, "to-pos");
         class_2680 blockState = ((class_2247)ctx.getArgument("block", class_2247.class)).method_9494();
         this.fillArea(fromPos, toPos, blockState, (class_2680)null);
         return 1;
      }))));
      builder.then(argument("from-pos", ClientPosArgumentType.pos()).then(argument("to-pos", ClientPosArgumentType.pos()).then(argument("block", class_2257.method_9653(REGISTRY_ACCESS)).then(literal("replace").then(argument("filter", class_2257.method_9653(REGISTRY_ACCESS)).executes((ctx) -> {
         class_243 fromPos = ClientPosArgumentType.getPos(ctx, "from-pos");
         class_243 toPos = ClientPosArgumentType.getPos(ctx, "to-pos");
         class_2680 blockState = ((class_2247)ctx.getArgument("block", class_2247.class)).method_9494();
         class_2680 filterBlock = ((class_2247)ctx.getArgument("filter", class_2247.class)).method_9494();
         this.fillArea(fromPos, toPos, blockState, filterBlock);
         return 1;
      }))))));
   }

   private void fillArea(class_243 fromPos, class_243 toPos, class_2680 blockState, class_2680 filterBlock) {
      MinMaxCoords coords = this.getMinMaxCoords(fromPos, toPos);

      for(int x = coords.minX; x <= coords.maxX; ++x) {
         for(int y = coords.minY; y <= coords.maxY; ++y) {
            for(int z = coords.minZ; z <= coords.maxZ; ++z) {
               class_2338 pos = new class_2338(x, y, z);
               if (filterBlock == null || mc.field_1687.method_8320(pos).equals(filterBlock)) {
                  mc.field_1687.method_8501(pos, blockState);
               }
            }
         }
      }

   }

   private MinMaxCoords getMinMaxCoords(class_243 fromPos, class_243 toPos) {
      int minX = Math.min((int)fromPos.method_10216(), (int)toPos.method_10216());
      int maxX = Math.max((int)fromPos.method_10216(), (int)toPos.method_10216());
      int minY = Math.min((int)fromPos.method_10214(), (int)toPos.method_10214());
      int maxY = Math.max((int)fromPos.method_10214(), (int)toPos.method_10214());
      int minZ = Math.min((int)fromPos.method_10215(), (int)toPos.method_10215());
      int maxZ = Math.max((int)fromPos.method_10215(), (int)toPos.method_10215());
      return new MinMaxCoords(minX, maxX, minY, maxY, minZ, maxZ);
   }

   private static class MinMaxCoords {
      public final int minX;
      public final int maxX;
      public final int minY;
      public final int maxY;
      public final int minZ;
      public final int maxZ;

      public MinMaxCoords(int minX, int maxX, int minY, int maxY, int minZ, int maxZ) {
         this.minX = minX;
         this.maxX = maxX;
         this.minY = minY;
         this.maxY = maxY;
         this.minZ = minZ;
         this.maxZ = maxZ;
      }
   }
}
