package anticope.rejects.commands;

import anticope.rejects.arguments.EnumArgumentType;
import anticope.rejects.utils.WorldGenUtils;
import anticope.rejects.utils.seeds.Seeds;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.seedfinding.mccore.version.MCVersion;
import cubitect.Cubiomes;
import meteordevelopment.meteorclient.commands.Command;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import net.minecraft.class_2172;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class LocateCommand extends Command {
   private static final DynamicCommandExceptionType NOT_FOUND = new DynamicCommandExceptionType((o) -> o instanceof Cubiomes.StructureType ? class_2561.method_43470(String.format("%s not found.", Utils.nameToTitle(o.toString().replaceAll("_", "-")))) : class_2561.method_43470("Not found."));

   public LocateCommand() {
      super("locate", "Locates structures.", new String[]{"loc"});
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(literal("feature").then(argument("feature", EnumArgumentType.enumArgument(Cubiomes.StructureType.Village)).executes((ctx) -> {
         Cubiomes.StructureType feature = (Cubiomes.StructureType)EnumArgumentType.getEnum(ctx, "feature", Cubiomes.StructureType.Village);
         class_2338 playerPos = mc.field_1724.method_24515();
         long seed = Seeds.get().getSeed().seed;
         MCVersion version = Seeds.get().getSeed().version;
         Cubiomes.MCVersion cubiomesVersion = null;
         if (version.isNewerOrEqualTo(MCVersion.v1_20)) {
            cubiomesVersion = Cubiomes.MCVersion.MC_1_20;
         } else if (version.isNewerOrEqualTo(MCVersion.v1_19)) {
            switch (version) {
               case v1_19:
               case v1_19_1:
                  cubiomesVersion = Cubiomes.MCVersion.MC_1_19;
                  break;
               case v1_19_2:
               case v1_19_3:
               case v1_19_4:
                  cubiomesVersion = Cubiomes.MCVersion.MC_1_19_2;
                  break;
               default:
                  throw new IllegalStateException("Unexpected value: " + String.valueOf(version));
            }
         } else if (version.isNewerOrEqualTo(MCVersion.v1_18)) {
            cubiomesVersion = Cubiomes.MCVersion.MC_1_18;
         }

         Cubiomes.Pos pos = null;
         if (cubiomesVersion != null) {
            pos = Cubiomes.GetNearestStructure(feature, playerPos.method_10263(), playerPos.method_10260(), seed, cubiomesVersion);
         } else {
            class_2338 bpos = WorldGenUtils.locateFeature(feature, playerPos);
            pos = new Cubiomes.Pos();
            pos.x = bpos.method_10263();
            pos.z = bpos.method_10260();
         }

         if (pos != null) {
            int distance = (int)Math.hypot((double)(pos.x - playerPos.method_10263()), (double)(pos.z - playerPos.method_10260()));
            class_5250 text = class_2561.method_43470(String.format("%s located at ", Utils.nameToTitle(feature.toString().replaceAll("_", "-"))));
            class_243 coords = new class_243((double)pos.x, (double)0.0F, (double)pos.z);
            text.method_10852(ChatUtils.formatCoords(coords));
            text.method_27693(".");
            if (distance > 0) {
               text.method_27693(String.format(" (%d blocks away)", distance));
            }

            this.info(text);
            return 1;
         } else {
            throw NOT_FOUND.create(feature);
         }
      })));
   }
}
