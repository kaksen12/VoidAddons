package anticope.rejects.commands;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.commands.Command;
import net.minecraft.class_2172;
import net.minecraft.class_243;

public class SetVelocityCommand extends Command {
   public SetVelocityCommand() {
      super("set-velocity", "Sets player velocity", new String[]{"velocity", "vel"});
   }

   public void build(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(argument("y", DoubleArgumentType.doubleArg()).executes((ctx) -> {
         class_243 currentVelocity = mc.field_1724.method_18798();
         mc.field_1724.method_18800(currentVelocity.field_1352, DoubleArgumentType.getDouble(ctx, "y"), currentVelocity.field_1350);
         return 1;
      }));
      builder.then(argument("x", DoubleArgumentType.doubleArg()).then(argument("z", DoubleArgumentType.doubleArg()).executes((ctx) -> {
         double x = DoubleArgumentType.getDouble(ctx, "x");
         double z = DoubleArgumentType.getDouble(ctx, "z");
         mc.field_1724.method_18800(x, mc.field_1724.method_18798().field_1351, z);
         return 1;
      })));
      builder.then(argument("x", DoubleArgumentType.doubleArg()).then(argument("y", DoubleArgumentType.doubleArg()).then(argument("z", DoubleArgumentType.doubleArg()).executes((ctx) -> {
         double x = DoubleArgumentType.getDouble(ctx, "x");
         double y = DoubleArgumentType.getDouble(ctx, "y");
         double z = DoubleArgumentType.getDouble(ctx, "z");
         mc.field_1724.method_18800(x, y, z);
         return 1;
      }))));
   }
}
